export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    console.info(JSON.stringify({ level: "info", event: "web.instrumentation.registered", service: "llinen-earth-web" }));
  }
}
