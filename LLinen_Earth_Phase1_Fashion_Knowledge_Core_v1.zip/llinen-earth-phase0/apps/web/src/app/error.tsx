"use client";

import { useEffect } from "react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("[llinen-earth:web-error]", { message: error.message, digest: error.digest });
  }, [error]);

  return (
    <section className="placeholder-page">
      <p className="eyebrow">SOMETHING WENT WRONG</p>
      <h1>The atelier hit a temporary problem.</h1>
      <p>Your design state should remain intact. Please retry this step.</p>
      <button className="button button--light" onClick={reset}>Try again</button>
    </section>
  );
}
