import { AppShell } from "@/components/AppShell";
import { aesthetics, contexts, fabrics, garments, knowledgeSummary } from "@llinen-earth/fashion-knowledge";

const groups = [
  { label: "Garments", items: garments.slice(0, 8).map((x) => ({ id: x.id, name: x.name, meta: `${x.family} · ${x.archetype}` })) },
  { label: "Fabrics", items: fabrics.slice(0, 8).map((x) => ({ id: x.id, name: x.name, meta: `${x.fiberFamily} · ${x.weave}` })) },
  { label: "Contexts", items: contexts.map((x) => ({ id: x.id, name: x.name, meta: `${x.category} · ${x.formality}` })) },
  { label: "Aesthetics", items: aesthetics.map((x) => ({ id: x.id, name: x.name, meta: x.summary })) },
];

export default function KnowledgePage() {
  return (
    <AppShell>
      <section className="knowledge-hero">
        <p className="eyebrow">PHASE 1 · FASHION KNOWLEDGE CORE</p>
        <h1>The atelier now has a vocabulary.</h1>
        <p>Structured garment, fabric, context and aesthetic records are now machine-readable and versioned as <strong>{knowledgeSummary.version}</strong>.</p>
      </section>
      <section className="knowledge-groups">
        {groups.map((group) => (
          <article className="knowledge-group" key={group.label}>
            <div className="knowledge-group__head"><h2>{group.label}</h2><span>{group.items.length} shown</span></div>
            <div className="knowledge-list">
              {group.items.map((item) => (
                <div className="knowledge-item" key={item.id}>
                  <span>{item.id}</span><h3>{item.name}</h3><p>{item.meta}</p>
                </div>
              ))}
            </div>
          </article>
        ))}
      </section>
    </AppShell>
  );
}
