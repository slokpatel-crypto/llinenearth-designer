import { NextResponse } from "next/server";
import { knowledgeSummary, pairingRelations } from "@llinen-earth/fashion-knowledge";
export function GET() { return NextResponse.json({ version: knowledgeSummary.version, count: pairingRelations.length, data: pairingRelations }); }
