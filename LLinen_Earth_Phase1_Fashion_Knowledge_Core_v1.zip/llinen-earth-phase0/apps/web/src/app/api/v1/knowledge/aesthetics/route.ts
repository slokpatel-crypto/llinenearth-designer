import { NextResponse } from "next/server";
import { aesthetics, knowledgeSummary } from "@llinen-earth/fashion-knowledge";
export function GET() { return NextResponse.json({ version: knowledgeSummary.version, count: aesthetics.length, data: aesthetics }); }
