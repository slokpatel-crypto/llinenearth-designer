import { NextResponse } from "next/server";
import { fabrics, knowledgeSummary } from "@llinen-earth/fashion-knowledge";
export function GET() { return NextResponse.json({ version: knowledgeSummary.version, count: fabrics.length, data: fabrics }); }
