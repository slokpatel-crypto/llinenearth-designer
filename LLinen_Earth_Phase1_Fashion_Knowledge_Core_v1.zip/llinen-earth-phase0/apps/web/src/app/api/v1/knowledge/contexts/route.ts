import { NextResponse } from "next/server";
import { contexts, knowledgeSummary } from "@llinen-earth/fashion-knowledge";
export function GET() { return NextResponse.json({ version: knowledgeSummary.version, count: contexts.length, data: contexts }); }
