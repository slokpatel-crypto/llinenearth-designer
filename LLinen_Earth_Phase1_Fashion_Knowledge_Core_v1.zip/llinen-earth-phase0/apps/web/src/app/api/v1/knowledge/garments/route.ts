import { NextRequest, NextResponse } from "next/server";
import { findGarments, knowledgeSummary } from "@llinen-earth/fashion-knowledge";

export function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const data = findGarments({
    family: searchParams.get("family") ?? undefined,
    formality: searchParams.get("formality") ?? undefined,
    climate: searchParams.get("climate") ?? undefined,
  });
  return NextResponse.json({ version: knowledgeSummary.version, count: data.length, data });
}
