import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { getServerEnv } from "@/lib/env";
import { createS3PrivateAssetStore } from "@llinen-earth/storage";
import { canCreatePrivateUpload } from "@llinen-earth/domain";

const MAX_BYTES = 10 * 1024 * 1024;
const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp"]);

type UploadRequest = { filename?: string; contentType?: string; sizeBytes?: number };

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    if (!canCreatePrivateUpload(user)) {
      return NextResponse.json({ error: "Upload not permitted for this role" }, { status: 403 });
    }
    const body = (await request.json()) as UploadRequest;

    if (!body.filename || !body.contentType || typeof body.sizeBytes !== "number") {
      return NextResponse.json({ error: "filename, contentType and sizeBytes are required" }, { status: 400 });
    }
    if (!ALLOWED.has(body.contentType)) {
      return NextResponse.json({ error: "Unsupported image type" }, { status: 415 });
    }
    if (body.sizeBytes <= 0 || body.sizeBytes > MAX_BYTES) {
      return NextResponse.json({ error: "File must be between 1 byte and 10 MB" }, { status: 413 });
    }

    const env = getServerEnv();
    const store = createS3PrivateAssetStore({
      endpoint: env.S3_ENDPOINT,
      region: env.S3_REGION,
      bucket: env.S3_BUCKET,
      accessKeyId: env.S3_ACCESS_KEY_ID,
      secretAccessKey: env.S3_SECRET_ACCESS_KEY,
      forcePathStyle: env.S3_FORCE_PATH_STYLE,
    });

    const intent = await store.createUploadIntent({
      ownerId: user.id,
      filename: body.filename,
      contentType: body.contentType,
      sizeBytes: body.sizeBytes,
    });

    return NextResponse.json(intent, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "UNAUTHORIZED") {
      return NextResponse.json({ error: "Authentication required" }, { status: 401 });
    }
    console.error("[upload-intent-error]", error);
    return NextResponse.json({ error: "Could not create private upload intent" }, { status: 500 });
  }
}
