import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { knowledgeSummary } from "@llinen-earth/fashion-knowledge";

const paths = [
  { eyebrow: "01", title: "I have a fabric", copy: "Begin with the material in your hand." },
  { eyebrow: "02", title: "I have an occasion", copy: "Design around place, time and impression." },
  { eyebrow: "03", title: "I have a reference", copy: "Translate inspiration into your own direction." },
];

const references = [
  {
    className: "reference-card reference-card--wide",
    image: "https://images.pexels.com/photos/6766385/pexels-photo-6766385.jpeg?cs=srgb&dl=pexels-tima-miroshnichenko-6766385.jpg&fm=jpg",
    title: "The atelier",
    copy: "Construction, proportion and material should read as one system.",
    source: "https://www.pexels.com/photo/black-suit-jacket-and-brown-coat-6766385/",
  },
  {
    className: "reference-card",
    image: "https://images.pexels.com/photos/6766382/pexels-photo-6766382.jpeg?cs=srgb&dl=pexels-tima-miroshnichenko-6766382.jpg&fm=jpg",
    title: "Measured, not generic",
    copy: "The digital experience should still feel rooted in tailoring craft.",
    source: "https://www.pexels.com/photo/a-tailor-measuring-a-client-using-a-tape-measure-6766382/",
  },
  {
    className: "reference-card",
    image: "https://images.pexels.com/photos/6764999/pexels-photo-6764999.jpeg?cs=srgb&dl=pexels-tima-miroshnichenko-6764999.jpg&fm=jpg",
    title: "A modern menswear world",
    copy: "Quiet confidence rather than an AI-dashboard aesthetic.",
    source: "https://www.pexels.com/photo/a-tailor-and-a-client-in-a-workshop-6764999/",
  },
];

export default function HomePage() {
  return (
    <AppShell>
      <section className="hero hero--editorial">
        <div className="hero__copy">
          <p className="eyebrow">LLINEN EARTH · THE DIGITAL ATELIER</p>
          <h1>Begin with fabric. End with a point of view.</h1>
          <p className="hero__lede">A premium menswear design experience that understands material, context and style before it recommends.</p>
          <div className="hero__actions">
            <Link className="button button--light" href="/designer">Start designing</Link>
            <Link className="button button--ghost" href="/knowledge">Explore the Fashion Brain</Link>
          </div>
          <div className="hero__meta"><span>Fabric-aware</span><span>Context-aware</span><span>Versioned knowledge</span></div>
        </div>
        <div className="hero-photo-stack" aria-label="Tailoring reference imagery">
          <div className="hero-photo hero-photo--main" style={{ backgroundImage: `linear-gradient(180deg, rgba(5,9,17,.02), rgba(5,9,17,.72)), url('${references[0].image}')` }} />
          <div className="hero-photo hero-photo--detail" style={{ backgroundImage: `linear-gradient(180deg, rgba(5,9,17,.04), rgba(5,9,17,.62)), url('${references[1].image}')` }} />
          <div className="hero-insight"><span>PHASE 1</span><strong>{knowledgeSummary.garments + knowledgeSummary.fabrics + knowledgeSummary.contexts + knowledgeSummary.aesthetics}</strong><p>curated knowledge records now form the first Fashion Brain.</p></div>
        </div>
      </section>

      <section className="fashion-brain" id="garments">
        <div className="section-heading"><p className="eyebrow">FASHION BRAIN · V1</p><h2>Not a list of outfits. A system that understands why they work.</h2></div>
        <div className="knowledge-stat-grid">
          <Link href="/knowledge" className="knowledge-stat"><span>GARMENTS</span><strong>{knowledgeSummary.garments}</strong><p>Structured archetypes and construction signals.</p></Link>
          <Link href="/knowledge" className="knowledge-stat" id="fabrics"><span>FABRICS</span><strong>{knowledgeSummary.fabrics}</strong><p>Material behavior, climate and garment suitability.</p></Link>
          <Link href="/knowledge" className="knowledge-stat"><span>CONTEXTS</span><strong>{knowledgeSummary.contexts}</strong><p>Occasion, venue, time and formality logic.</p></Link>
          <Link href="/knowledge" className="knowledge-stat"><span>AESTHETICS</span><strong>{knowledgeSummary.aesthetics}</strong><p>Designer identities encoded as measurable signals.</p></Link>
        </div>
      </section>

      <section className="reference-world">
        <div className="section-heading"><p className="eyebrow">VISUAL WORLD</p><h2>Tailoring craft, translated into a darker digital language.</h2></div>
        <div className="reference-grid">
          {references.map((ref) => (
            <article className={ref.className} key={ref.title} style={{ backgroundImage: `linear-gradient(180deg, rgba(6,11,20,.08), rgba(6,11,20,.88)), url('${ref.image}')` }}>
              <div><span>REFERENCE</span><h3>{ref.title}</h3><p>{ref.copy}</p><a href={ref.source} target="_blank" rel="noreferrer">Photo source · Pexels</a></div>
            </article>
          ))}
        </div>
        <p className="reference-note">Reference photography is used to establish visual direction; production brand imagery should later use LLinen Earth-owned or specifically licensed assets.</p>
      </section>

      <section className="experience" id="experience">
        <div className="section-heading"><p className="eyebrow">BEGIN YOUR WAY</p><h2>A designer should understand before it recommends.</h2></div>
        <div className="path-grid">
          {paths.map((path) => (
            <Link className="path-card" href="/designer" key={path.eyebrow}><span>{path.eyebrow}</span><h3>{path.title}</h3><p>{path.copy}</p><b>Begin →</b></Link>
          ))}
        </div>
      </section>

      <section className="foundation-note" id="atelier">
        <p className="eyebrow">PHASE 1 · FASHION KNOWLEDGE CORE</p>
        <h2>The website now has the beginning of its fashion intelligence.</h2>
        <p>Garments, fabrics, contexts, aesthetics and compatibility relationships are structured, versioned and exposed through read APIs. The next implementation phase connects customer fabric analysis to this knowledge.</p>
      </section>
    </AppShell>
  );
}
