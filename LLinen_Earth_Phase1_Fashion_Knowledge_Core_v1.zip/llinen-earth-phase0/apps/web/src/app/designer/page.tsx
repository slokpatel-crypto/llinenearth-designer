import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { knowledgeSummary } from "@llinen-earth/fashion-knowledge";

export default function DesignerPage() {
  return (
    <AppShell>
      <section className="placeholder-page designer-preview">
        <p className="eyebrow">AI DESIGNER · FOUNDATION</p>
        <h1>The Fashion Brain is now connected.</h1>
        <p>Phase 1 provides {knowledgeSummary.garments} garment definitions, {knowledgeSummary.fabrics} fabric profiles, {knowledgeSummary.contexts} contexts and {knowledgeSummary.aesthetics} aesthetics. Fabric-photo analysis begins in the next implementation phase.</p>
        <div className="hero__actions"><Link className="button button--light" href="/knowledge">Explore knowledge</Link><Link className="button button--ghost" href="/">Return home</Link></div>
      </section>
    </AppShell>
  );
}
