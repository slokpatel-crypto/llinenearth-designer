type ServerEnv = {
  DATABASE_URL: string;
  AUTH_MODE: "dev" | "managed";
  DEV_AUTH_USER_ID?: string;
  DEV_AUTH_USER_ROLE?: string;
  S3_ENDPOINT?: string;
  S3_REGION: string;
  S3_BUCKET: string;
  S3_ACCESS_KEY_ID: string;
  S3_SECRET_ACCESS_KEY: string;
  S3_FORCE_PATH_STYLE: boolean;
  APP_BASE_URL: string;
  LOG_LEVEL: string;
};

function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required server environment variable: ${name}`);
  return value;
}

export function getServerEnv(): ServerEnv {
  const authMode = (process.env.AUTH_MODE ?? "dev") as ServerEnv["AUTH_MODE"];
  if (!(["dev", "managed"] as const).includes(authMode)) {
    throw new Error("AUTH_MODE must be dev or managed");
  }

  if (process.env.NODE_ENV === "production" && authMode === "dev") {
    throw new Error("Development authentication cannot be used in production");
  }

  return {
    DATABASE_URL: required("DATABASE_URL"),
    AUTH_MODE: authMode,
    DEV_AUTH_USER_ID: process.env.DEV_AUTH_USER_ID,
    DEV_AUTH_USER_ROLE: process.env.DEV_AUTH_USER_ROLE,
    S3_ENDPOINT: process.env.S3_ENDPOINT,
    S3_REGION: process.env.S3_REGION ?? "us-east-1",
    S3_BUCKET: required("S3_BUCKET"),
    S3_ACCESS_KEY_ID: required("S3_ACCESS_KEY_ID"),
    S3_SECRET_ACCESS_KEY: required("S3_SECRET_ACCESS_KEY"),
    S3_FORCE_PATH_STYLE: process.env.S3_FORCE_PATH_STYLE === "true",
    APP_BASE_URL: process.env.APP_BASE_URL ?? "http://localhost:3000",
    LOG_LEVEL: process.env.LOG_LEVEL ?? "info",
  };
}
