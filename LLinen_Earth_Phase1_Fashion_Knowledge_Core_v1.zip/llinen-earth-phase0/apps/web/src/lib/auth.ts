import { type AppUser, type UserRole, isUserRole } from "@llinen-earth/domain";
import { getServerEnv } from "./env";

export interface AuthAdapter {
  currentUser(): Promise<AppUser | null>;
}

class DevelopmentAuthAdapter implements AuthAdapter {
  async currentUser(): Promise<AppUser | null> {
    const env = getServerEnv();
    if (env.AUTH_MODE !== "dev" || process.env.NODE_ENV === "production") return null;
    if (!env.DEV_AUTH_USER_ID) return null;

    const role: UserRole = isUserRole(env.DEV_AUTH_USER_ROLE) ? env.DEV_AUTH_USER_ROLE : "CUSTOMER";
    return { id: env.DEV_AUTH_USER_ID, role };
  }
}

class ManagedAuthPlaceholder implements AuthAdapter {
  async currentUser(): Promise<AppUser | null> {
    // Provider choice is intentionally deferred. Phase 0 defines the boundary,
    // not a vendor lock-in. Replace this class when managed auth is selected.
    return null;
  }
}

function getAuthAdapter(): AuthAdapter {
  const env = getServerEnv();
  return env.AUTH_MODE === "dev" ? new DevelopmentAuthAdapter() : new ManagedAuthPlaceholder();
}

export async function getCurrentUser(): Promise<AppUser | null> {
  return getAuthAdapter().currentUser();
}

export async function requireUser(): Promise<AppUser> {
  const user = await getCurrentUser();
  if (!user) throw new Error("UNAUTHORIZED");
  return user;
}
