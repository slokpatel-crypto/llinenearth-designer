import Image from "next/image";
import Link from "next/link";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="site-shell">
      <header className="topbar">
        <Link className="brand-lockup" href="/" aria-label="LLinen Earth home">
          <Image src="/brand/llinen-earth-logo-official.png" alt="LLinen Earth" width={1273} height={531} priority />
        </Link>
        <nav className="nav" aria-label="Primary navigation">
          <Link href="/designer">Designer</Link>
          <Link href="/knowledge">Fashion Brain</Link>
          <a href="/#garments">Garments</a>
          <a href="/#fabrics">Fabrics</a>
          <a href="/#atelier">Atelier</a>
        </nav>
        <Link className="nav-cta" href="/designer">Start designing</Link>
      </header>
      <main>{children}</main>
      <footer className="footer">
        <span>LLinen Earth</span>
        <span>Premium fabric. Considered design.</span>
      </footer>
    </div>
  );
}
