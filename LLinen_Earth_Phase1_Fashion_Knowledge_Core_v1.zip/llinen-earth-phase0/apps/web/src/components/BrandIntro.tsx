"use client";

import Image from "next/image";
import { useLayoutEffect, useState } from "react";

const SESSION_KEY = "llinen-earth:intro-v3-seen";
const INTRO_MS = 4300;

export function BrandIntro() {
  const [show, setShow] = useState(false);

  useLayoutEffect(() => {
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const alreadySeen = window.sessionStorage.getItem(SESSION_KEY) === "1";
    if (alreadySeen || reducedMotion) {
      window.sessionStorage.setItem(SESSION_KEY, "1");
      return;
    }
    setShow(true);
    const timer = window.setTimeout(() => {
      window.sessionStorage.setItem(SESSION_KEY, "1");
      setShow(false);
    }, INTRO_MS);
    return () => window.clearTimeout(timer);
  }, []);

  if (!show) return null;

  return (
    <div className="brand-intro" aria-hidden="true">
      <div className="brand-intro__navy" />
      <div className="brand-intro__halo" />
      <div className="brand-intro__line brand-intro__line--a" />
      <div className="brand-intro__line brand-intro__line--b" />
      <div className="brand-intro__logo-stage">
        <Image
          className="brand-intro__official-logo"
          src="/brand/llinen-earth-logo-official.png"
          alt=""
          width={1273}
          height={531}
          priority
        />
      </div>
      <p className="brand-intro__caption">FABRIC · DESIGN · CRAFT</p>
      <div className="brand-intro__finish" />
    </div>
  );
}
