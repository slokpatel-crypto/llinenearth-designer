import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  transpilePackages: [
    "@llinen-earth/domain",
    "@llinen-earth/fashion-knowledge",
    "@llinen-earth/storage",
    "@llinen-earth/observability",
  ],
  experimental: { typedRoutes: true },
};

export default nextConfig;
