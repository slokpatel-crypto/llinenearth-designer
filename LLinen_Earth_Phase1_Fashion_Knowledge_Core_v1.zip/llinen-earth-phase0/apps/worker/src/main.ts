import { InMemoryJobQueue } from "@llinen-earth/jobs";
import { logger } from "@llinen-earth/observability";

const queue = new InMemoryJobQueue();
logger.info("worker.started", { phase: 0, adapter: "in-memory" });

// Phase 0 proves the worker boundary only. Persistent queue selection is deferred
// until long-running AI workloads exist and can be measured.
void queue;
