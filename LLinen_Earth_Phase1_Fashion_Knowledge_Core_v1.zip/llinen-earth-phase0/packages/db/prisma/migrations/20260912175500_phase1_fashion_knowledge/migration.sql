CREATE TABLE "GarmentDefinition" (
  "id" TEXT NOT NULL,
  "family" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "archetype" TEXT NOT NULL,
  "taxonomyVersion" TEXT NOT NULL,
  "attributes" JSONB NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "GarmentDefinition_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "GarmentDefinition_family_status_idx" ON "GarmentDefinition"("family", "status");

CREATE TABLE "FabricDefinition" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "fiberFamily" TEXT NOT NULL,
  "knowledgeVersion" TEXT NOT NULL,
  "properties" JSONB NOT NULL,
  "confidenceDefault" TEXT NOT NULL,
  "provenance" JSONB NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "FabricDefinition_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "FabricDefinition_fiberFamily_status_idx" ON "FabricDefinition"("fiberFamily", "status");

CREATE TABLE "ContextDefinition" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "category" TEXT NOT NULL,
  "knowledgeVersion" TEXT NOT NULL,
  "attributes" JSONB NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "ContextDefinition_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "ContextDefinition_category_status_idx" ON "ContextDefinition"("category", "status");

CREATE TABLE "AestheticDefinition" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "knowledgeVersion" TEXT NOT NULL,
  "dimensions" JSONB NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'ACTIVE',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "AestheticDefinition_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "AestheticDefinition_status_idx" ON "AestheticDefinition"("status");

CREATE TABLE "KnowledgeRelation" (
  "id" TEXT NOT NULL,
  "sourceType" TEXT NOT NULL,
  "sourceId" TEXT NOT NULL,
  "targetType" TEXT NOT NULL,
  "targetId" TEXT NOT NULL,
  "relation" TEXT NOT NULL,
  "strength" DOUBLE PRECISION NOT NULL,
  "conditions" JSONB,
  "exceptions" JSONB,
  "evidence" TEXT NOT NULL,
  "knowledgeVersion" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "KnowledgeRelation_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "KnowledgeRelation_sourceType_sourceId_idx" ON "KnowledgeRelation"("sourceType", "sourceId");
CREATE INDEX "KnowledgeRelation_targetType_targetId_idx" ON "KnowledgeRelation"("targetType", "targetId");
CREATE INDEX "KnowledgeRelation_relation_idx" ON "KnowledgeRelation"("relation");
