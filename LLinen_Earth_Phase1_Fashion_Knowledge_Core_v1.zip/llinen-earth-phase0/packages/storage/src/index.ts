import { randomUUID } from "node:crypto";
import { PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

export type PrivateUploadRequest = {
  ownerId: string;
  filename: string;
  contentType: string;
  sizeBytes: number;
};

export type PrivateUploadIntent = {
  assetId: string;
  objectKey: string;
  uploadUrl: string;
  expiresInSeconds: number;
  requiredHeaders: Record<string, string>;
};

export interface PrivateAssetStore {
  createUploadIntent(request: PrivateUploadRequest): Promise<PrivateUploadIntent>;
}

type S3PrivateAssetStoreConfig = {
  endpoint?: string;
  region: string;
  bucket: string;
  accessKeyId: string;
  secretAccessKey: string;
  forcePathStyle?: boolean;
};

function safeFilename(filename: string): string {
  return filename.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(0, 120) || "upload";
}

export function createS3PrivateAssetStore(config: S3PrivateAssetStoreConfig): PrivateAssetStore {
  const client = new S3Client({
    endpoint: config.endpoint,
    region: config.region,
    forcePathStyle: config.forcePathStyle,
    credentials: {
      accessKeyId: config.accessKeyId,
      secretAccessKey: config.secretAccessKey,
    },
  });

  return {
    async createUploadIntent(request) {
      if (!request.ownerId) throw new Error("ownerId is required for private upload");
      const assetId = randomUUID();
      const objectKey = `private/${request.ownerId}/${assetId}/${safeFilename(request.filename)}`;
      const expiresInSeconds = 300;
      const command = new PutObjectCommand({
        Bucket: config.bucket,
        Key: objectKey,
        ContentType: request.contentType,
        Metadata: {
          ownerid: request.ownerId,
          assetid: assetId,
        },
      });
      const uploadUrl = await getSignedUrl(client, command, { expiresIn: expiresInSeconds });
      return {
        assetId,
        objectKey,
        uploadUrl,
        expiresInSeconds,
        requiredHeaders: { "content-type": request.contentType },
      };
    },
  };
}
