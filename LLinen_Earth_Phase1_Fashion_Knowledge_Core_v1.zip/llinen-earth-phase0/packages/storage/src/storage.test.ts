import { describe, expect, it } from "vitest";

describe("private asset contract", () => {
  it("requires owner-scoped keys by design", () => {
    const ownerId = "customer-42";
    const expectedPrefix = `private/${ownerId}/`;
    expect(expectedPrefix.startsWith("private/customer-42/")).toBe(true);
  });
});
