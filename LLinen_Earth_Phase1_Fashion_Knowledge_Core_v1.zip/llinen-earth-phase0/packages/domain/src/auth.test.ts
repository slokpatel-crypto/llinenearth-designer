import { describe, expect, it } from "vitest";
import { canCreatePrivateUpload, isUserRole } from "./auth";

describe("auth domain", () => {
  it("recognizes known roles", () => {
    expect(isUserRole("CUSTOMER")).toBe(true);
    expect(isUserRole("ROOT")).toBe(false);
  });

  it("prevents worker identities from customer uploads", () => {
    expect(canCreatePrivateUpload({ id: "worker-1", role: "SYSTEM_WORKER" })).toBe(false);
    expect(canCreatePrivateUpload({ id: "customer-1", role: "CUSTOMER" })).toBe(true);
  });
});
