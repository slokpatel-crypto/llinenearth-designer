export const GARMENT_FAMILIES = ["TROUSER", "SHIRT", "JACKET", "SUIT"] as const;
export type GarmentFamily = (typeof GARMENT_FAMILIES)[number];

export const FORMALITY_LEVELS = ["CASUAL", "SMART_CASUAL", "BUSINESS", "FORMAL", "BLACK_TIE", "CEREMONIAL"] as const;
export type FormalityLevel = (typeof FORMALITY_LEVELS)[number];

export const SILHOUETTES = ["SLIM", "TAILORED", "STRAIGHT", "RELAXED", "WIDE", "OVERSIZED"] as const;
export type Silhouette = (typeof SILHOUETTES)[number];

export const CLIMATES = ["HOT_HUMID", "HOT_DRY", "MILD", "COLD", "WET"] as const;
export type Climate = (typeof CLIMATES)[number];

export const KNOWLEDGE_SOURCE_TYPES = ["CURATED_SPEC", "DESIGNER_REVIEW", "OWNED_REFERENCE", "LICENSED_REFERENCE"] as const;
export type KnowledgeSourceType = (typeof KNOWLEDGE_SOURCE_TYPES)[number];

export type KnowledgeMeta = {
  version: string;
  sourceType: KnowledgeSourceType;
  confidence: "VERIFIED" | "PROBABLE" | "UNCERTAIN";
};

export type GarmentDefinition = {
  id: string;
  family: GarmentFamily;
  name: string;
  archetype: string;
  formalities: FormalityLevel[];
  climates: Climate[];
  attributes: Record<string, string | string[] | number | boolean>;
  meta: KnowledgeMeta;
};

export type FabricDefinition = {
  id: string;
  name: string;
  fiberFamily: string;
  weave: string;
  weightClass: "LIGHT" | "MEDIUM" | "HEAVY";
  drape: "CRISP" | "MODERATE" | "SOFT" | "FLUID";
  surface: string[];
  climates: Climate[];
  recommendedGarmentFamilies: GarmentFamily[];
  meta: KnowledgeMeta;
};

export type ContextDefinition = {
  id: string;
  name: string;
  category: string;
  formality: FormalityLevel;
  climates: Climate[];
  attributes: Record<string, string | string[] | number | boolean>;
  meta: KnowledgeMeta;
};

export type AestheticDefinition = {
  id: string;
  name: string;
  summary: string;
  silhouetteBias: Silhouette[];
  colorBehavior: string[];
  materialBehavior: string[];
  detailDensity: "MINIMAL" | "CLASSIC" | "EXPRESSIVE";
  meta: KnowledgeMeta;
};

export type KnowledgeRelation = {
  id: string;
  sourceType: "GARMENT" | "FABRIC" | "CONTEXT" | "AESTHETIC" | "COLOR" | "PATTERN";
  sourceId: string;
  targetType: "GARMENT" | "FABRIC" | "CONTEXT" | "AESTHETIC" | "COLOR" | "PATTERN";
  targetId: string;
  relation: "WORKS_WITH" | "PREFERRED_FOR" | "CONFLICTS_WITH" | "SUPPORTS";
  strength: number;
  conditions?: Record<string, string | string[] | number | boolean>;
  evidence: string;
  version: string;
};
