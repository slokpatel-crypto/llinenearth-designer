export const USER_ROLES = ["CUSTOMER", "STORE_STAFF", "DESIGNER", "ADMIN", "SYSTEM_WORKER"] as const;
export type UserRole = (typeof USER_ROLES)[number];
export type AppUser = { id: string; role: UserRole };

export function isUserRole(value: unknown): value is UserRole {
  return typeof value === "string" && USER_ROLES.includes(value as UserRole);
}

export function canCreatePrivateUpload(user: AppUser): boolean {
  return user.role !== "SYSTEM_WORKER";
}
