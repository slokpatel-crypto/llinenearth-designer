export const JOB_STATUSES = ["QUEUED", "RUNNING", "SUCCEEDED", "FAILED"] as const;
export type JobStatus = (typeof JOB_STATUSES)[number];

export type JobEnvelope<TPayload = unknown> = {
  id: string;
  type: string;
  ownerId?: string;
  payload: TPayload;
  status: JobStatus;
  createdAt: string;
};
