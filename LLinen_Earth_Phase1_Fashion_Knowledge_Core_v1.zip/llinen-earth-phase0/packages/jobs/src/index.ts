import { randomUUID } from "node:crypto";
import type { JobEnvelope } from "@llinen-earth/domain";

export interface JobQueue {
  enqueue<T>(type: string, payload: T, ownerId?: string): Promise<JobEnvelope<T>>;
  claim(): Promise<JobEnvelope | null>;
}

export class InMemoryJobQueue implements JobQueue {
  private jobs: JobEnvelope[] = [];

  async enqueue<T>(type: string, payload: T, ownerId?: string): Promise<JobEnvelope<T>> {
    const job: JobEnvelope<T> = { id: randomUUID(), type, payload, ownerId, status: "QUEUED", createdAt: new Date().toISOString() };
    this.jobs.push(job as JobEnvelope);
    return job;
  }

  async claim(): Promise<JobEnvelope | null> {
    return this.jobs.shift() ?? null;
  }
}
