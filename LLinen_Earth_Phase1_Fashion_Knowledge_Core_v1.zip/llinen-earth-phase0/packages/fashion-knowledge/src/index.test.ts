import { describe, expect, it } from "vitest";
import { aesthetics, contexts, fabrics, findGarments, garments, knowledgeSummary, pairingRelations, validateKnowledgeSeed } from ".";

describe("Phase 1 Fashion Knowledge Core", () => {
  it("ships a representative curated knowledge set", () => {
    expect(garments.length).toBeGreaterThanOrEqual(12);
    expect(fabrics.length).toBeGreaterThanOrEqual(8);
    expect(contexts.length).toBeGreaterThanOrEqual(6);
    expect(aesthetics.length).toBeGreaterThanOrEqual(7);
    expect(pairingRelations.length).toBeGreaterThanOrEqual(8);
    expect(knowledgeSummary.version).toMatch(/^LE-KB-/);
  });

  it("has unique stable IDs and valid relation targets", () => {
    expect(validateKnowledgeSeed()).toEqual({ ok: true, duplicateIds: [], relationErrors: [] });
  });

  it("can filter garments by structured knowledge", () => {
    const warmSmartCasual = findGarments({ family: "TROUSER", formality: "SMART_CASUAL", climate: "HOT_HUMID" });
    expect(warmSmartCasual.some((item) => item.id === "TR-DRAWSTRING-LINEN-001")).toBe(true);
  });
});
