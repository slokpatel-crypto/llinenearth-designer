import type {
  AestheticDefinition,
  ContextDefinition,
  FabricDefinition,
  GarmentDefinition,
  KnowledgeRelation,
} from "@llinen-earth/domain";

export const KNOWLEDGE_VERSION = "LE-KB-1.0.0";
const verified = { version: KNOWLEDGE_VERSION, sourceType: "CURATED_SPEC" as const, confidence: "VERIFIED" as const };

export const garments: GarmentDefinition[] = [
  {
    id: "TR-PLEATED-TAILORED-001",
    family: "TROUSER",
    name: "Tailored Pleated Trouser",
    archetype: "pleated tailored trouser",
    formalities: ["SMART_CASUAL", "BUSINESS", "FORMAL"],
    climates: ["HOT_HUMID", "HOT_DRY", "MILD", "COLD"],
    attributes: { silhouette: "TAILORED", rise: "HIGH", pleat: ["SINGLE", "DOUBLE"], waistband: "EXTENDED_TAB", hem: ["PLAIN", "CUFFED"], break: ["NO_BREAK", "SLIGHT_BREAK"] },
    meta: verified,
  },
  {
    id: "TR-FLAT-FRONT-001",
    family: "TROUSER",
    name: "Flat-Front Tailored Trouser",
    archetype: "flat-front trouser",
    formalities: ["SMART_CASUAL", "BUSINESS", "FORMAL"],
    climates: ["HOT_HUMID", "HOT_DRY", "MILD", "COLD"],
    attributes: { silhouette: "TAILORED", rise: "MID", pleat: "NONE", waistband: "CLEAN", hem: "PLAIN", break: "SLIGHT_BREAK" },
    meta: verified,
  },
  {
    id: "TR-WIDE-LEG-001",
    family: "TROUSER",
    name: "Wide-Leg Trouser",
    archetype: "wide-leg trouser",
    formalities: ["SMART_CASUAL", "BUSINESS", "FORMAL"],
    climates: ["HOT_DRY", "MILD", "COLD"],
    attributes: { silhouette: "WIDE", rise: "HIGH", legLine: "FULL", drapePriority: true, break: ["NO_BREAK", "FULL_BREAK"] },
    meta: verified,
  },
  {
    id: "TR-DRAWSTRING-LINEN-001",
    family: "TROUSER",
    name: "Drawstring Linen Trouser",
    archetype: "drawstring tailored trouser",
    formalities: ["CASUAL", "SMART_CASUAL"],
    climates: ["HOT_HUMID", "HOT_DRY", "MILD"],
    attributes: { silhouette: "RELAXED", rise: "MID", waistband: "DRAWSTRING", legLine: "STRAIGHT", surfacePreference: "NATURAL" },
    meta: verified,
  },
  {
    id: "SH-DRESS-SPREAD-001",
    family: "SHIRT",
    name: "Spread-Collar Dress Shirt",
    archetype: "dress shirt",
    formalities: ["BUSINESS", "FORMAL", "BLACK_TIE"],
    climates: ["HOT_HUMID", "HOT_DRY", "MILD", "COLD"],
    attributes: { silhouette: "TAILORED", collar: "SPREAD", placket: "FRENCH_FRONT", cuff: ["BARREL", "DOUBLE"], hem: "SHIRTTAIL" },
    meta: verified,
  },
  {
    id: "SH-OXFORD-BD-001",
    family: "SHIRT",
    name: "Oxford Button-Down Shirt",
    archetype: "oxford cloth button-down",
    formalities: ["CASUAL", "SMART_CASUAL", "BUSINESS"],
    climates: ["MILD", "COLD", "HOT_DRY"],
    attributes: { silhouette: "STRAIGHT", collar: "BUTTON_DOWN", placket: "FRONT_PLACKET", cuff: "BARREL", yoke: "SPLIT_OPTIONAL" },
    meta: verified,
  },
  {
    id: "SH-CAMP-001",
    family: "SHIRT",
    name: "Camp-Collar Shirt",
    archetype: "camp shirt",
    formalities: ["CASUAL", "SMART_CASUAL"],
    climates: ["HOT_HUMID", "HOT_DRY", "MILD"],
    attributes: { silhouette: "RELAXED", collar: "CAMP", hem: "STRAIGHT", sleeve: ["SHORT", "LONG"], structure: "SOFT" },
    meta: verified,
  },
  {
    id: "SH-BAND-COLLAR-001",
    family: "SHIRT",
    name: "Band-Collar Shirt",
    archetype: "band collar shirt",
    formalities: ["CASUAL", "SMART_CASUAL"],
    climates: ["HOT_HUMID", "HOT_DRY", "MILD"],
    attributes: { silhouette: "TAILORED", collar: "BAND", placket: "CLEAN", cuff: "BARREL", aestheticSignal: "MINIMAL" },
    meta: verified,
  },
  {
    id: "JK-SOFT-SB-001",
    family: "JACKET",
    name: "Soft Single-Breasted Blazer",
    archetype: "soft blazer",
    formalities: ["SMART_CASUAL", "BUSINESS", "FORMAL"],
    climates: ["HOT_HUMID", "HOT_DRY", "MILD"],
    attributes: { silhouette: "TAILORED", breast: "SINGLE", buttons: 2, lapel: "NOTCH", shoulder: "NATURAL", canvas: "LIGHT", vent: "DOUBLE" },
    meta: verified,
  },
  {
    id: "JK-STRUCTURED-DB-001",
    family: "JACKET",
    name: "Structured Double-Breasted Blazer",
    archetype: "double-breasted blazer",
    formalities: ["BUSINESS", "FORMAL"],
    climates: ["MILD", "COLD"],
    attributes: { silhouette: "TAILORED", breast: "DOUBLE", buttonConfiguration: "6x2", lapel: "PEAK", shoulder: "STRUCTURED", vent: "DOUBLE" },
    meta: verified,
  },
  {
    id: "SU-SB-2PC-001",
    family: "SUIT",
    name: "Single-Breasted Two-Piece Suit",
    archetype: "two-piece suit",
    formalities: ["BUSINESS", "FORMAL"],
    climates: ["HOT_DRY", "MILD", "COLD"],
    attributes: { jacket: "SINGLE_BREASTED", pieces: 2, lapel: ["NOTCH", "PEAK"], trouser: ["FLAT_FRONT", "PLEATED"], construction: ["HALF_CANVAS", "FULL_CANVAS"] },
    meta: verified,
  },
  {
    id: "SU-TUXEDO-001",
    family: "SUIT",
    name: "Dinner Suit / Tuxedo",
    archetype: "dinner suit",
    formalities: ["BLACK_TIE"],
    climates: ["MILD", "COLD"],
    attributes: { lapel: ["PEAK", "SHAWL"], facing: "SILK", trouserSeam: "BRAID_OPTIONAL", shirtPairing: "FORMAL_EVENING" },
    meta: verified,
  },
];

export const fabrics: FabricDefinition[] = [
  { id: "FB-LINEN-PLAIN-LIGHT-001", name: "Light Plain-Weave Linen", fiberFamily: "LINEN", weave: "PLAIN", weightClass: "LIGHT", drape: "MODERATE", surface: ["DRY", "SLUBBY", "MATTE"], climates: ["HOT_HUMID", "HOT_DRY", "MILD"], recommendedGarmentFamilies: ["TROUSER", "SHIRT", "JACKET", "SUIT"], meta: verified },
  { id: "FB-LINEN-COTTON-001", name: "Linen-Cotton Blend", fiberFamily: "LINEN_COTTON", weave: "PLAIN", weightClass: "LIGHT", drape: "MODERATE", surface: ["NATURAL", "MATTE"], climates: ["HOT_HUMID", "HOT_DRY", "MILD"], recommendedGarmentFamilies: ["TROUSER", "SHIRT", "JACKET"], meta: verified },
  { id: "FB-COTTON-POPLIN-001", name: "Cotton Poplin", fiberFamily: "COTTON", weave: "POPLIN", weightClass: "LIGHT", drape: "CRISP", surface: ["SMOOTH", "MATTE"], climates: ["HOT_HUMID", "HOT_DRY", "MILD"], recommendedGarmentFamilies: ["SHIRT"], meta: verified },
  { id: "FB-COTTON-OXFORD-001", name: "Oxford Cloth", fiberFamily: "COTTON", weave: "BASKET", weightClass: "MEDIUM", drape: "MODERATE", surface: ["TEXTURED", "MATTE"], climates: ["MILD", "COLD"], recommendedGarmentFamilies: ["SHIRT"], meta: verified },
  { id: "FB-WOOL-TROPICAL-001", name: "Tropical Wool", fiberFamily: "WOOL", weave: "OPEN_WORSTED", weightClass: "LIGHT", drape: "MODERATE", surface: ["DRY", "REFINED"], climates: ["HOT_DRY", "MILD"], recommendedGarmentFamilies: ["TROUSER", "JACKET", "SUIT"], meta: verified },
  { id: "FB-WOOL-HOPSACK-001", name: "Hopsack Wool", fiberFamily: "WOOL", weave: "HOPSACK", weightClass: "MEDIUM", drape: "MODERATE", surface: ["OPEN_TEXTURE", "MATTE"], climates: ["MILD", "HOT_DRY"], recommendedGarmentFamilies: ["JACKET", "SUIT"], meta: verified },
  { id: "FB-WOOL-FLANNEL-001", name: "Wool Flannel", fiberFamily: "WOOL", weave: "FLANNEL", weightClass: "MEDIUM", drape: "SOFT", surface: ["BRUSHED", "MATTE"], climates: ["COLD", "MILD"], recommendedGarmentFamilies: ["TROUSER", "JACKET", "SUIT"], meta: verified },
  { id: "FB-SEERSUCKER-001", name: "Cotton Seersucker", fiberFamily: "COTTON", weave: "SEERSUCKER", weightClass: "LIGHT", drape: "MODERATE", surface: ["PUCKERED", "MATTE"], climates: ["HOT_HUMID", "HOT_DRY"], recommendedGarmentFamilies: ["SHIRT", "JACKET", "SUIT"], meta: verified },
];

export const contexts: ContextDefinition[] = [
  { id: "CTX-BUSINESS-OFFICE-001", name: "Business Office", category: "BUSINESS", formality: "BUSINESS", climates: ["HOT_HUMID", "HOT_DRY", "MILD", "COLD"], attributes: { venue: "OFFICE", time: ["MORNING", "DAYTIME"], desiredImpression: ["REFINED", "CAPABLE"], noveltyTolerance: "LOW_TO_MEDIUM" }, meta: verified },
  { id: "CTX-BEACH-WEDDING-DAY-001", name: "Daytime Beach Wedding", category: "WEDDING", formality: "SMART_CASUAL", climates: ["HOT_HUMID", "HOT_DRY"], attributes: { venue: "BEACH", time: ["DAYTIME", "SUNSET"], structureBias: "SOFT", breathabilityPriority: "HIGH" }, meta: verified },
  { id: "CTX-HOTEL-WEDDING-EVE-001", name: "Luxury Hotel Evening Wedding", category: "WEDDING", formality: "FORMAL", climates: ["MILD", "HOT_HUMID"], attributes: { venue: "LUXURY_HOTEL", time: "EVENING", desiredImpression: ["ELEGANT", "REFINED"], polishPriority: "HIGH" }, meta: verified },
  { id: "CTX-RESORT-DINNER-001", name: "Resort Dinner", category: "RESORT", formality: "SMART_CASUAL", climates: ["HOT_HUMID", "HOT_DRY", "MILD"], attributes: { venue: "RESORT", time: ["SUNSET", "EVENING"], desiredImpression: ["RELAXED", "ELEGANT"] }, meta: verified },
  { id: "CTX-CITY-SMART-CASUAL-001", name: "Urban Smart Casual", category: "SOCIAL", formality: "SMART_CASUAL", climates: ["MILD", "COLD", "HOT_DRY"], attributes: { venue: "CITY", time: ["DAYTIME", "EVENING"], versatilityPriority: "HIGH" }, meta: verified },
  { id: "CTX-INDIA-FESTIVE-DAY-001", name: "Indian Festive Daytime", category: "FESTIVE", formality: "FORMAL", climates: ["HOT_HUMID", "HOT_DRY", "MILD"], attributes: { venue: ["HOME", "HOTEL", "LAWN"], time: "DAYTIME", culturalSensitivity: "HIGH", colorTolerance: "MEDIUM_TO_HIGH" }, meta: verified },
];

export const aesthetics: AestheticDefinition[] = [
  { id: "AE-QUIET-LUXURY", name: "Quiet Luxury", summary: "Material, proportion and restraint lead; visibility stays controlled.", silhouetteBias: ["TAILORED", "RELAXED"], colorBehavior: ["TONAL", "NEUTRAL", "LOW_CHROMA"], materialBehavior: ["TACTILE", "MATTE", "REFINED"], detailDensity: "MINIMAL", meta: verified },
  { id: "AE-MODERN-CLASSIC", name: "Modern Classic", summary: "Classic menswear vocabulary corrected for contemporary proportion.", silhouetteBias: ["TAILORED", "STRAIGHT"], colorBehavior: ["NEUTRAL", "BALANCED"], materialBehavior: ["REFINED", "VERSATILE"], detailDensity: "CLASSIC", meta: verified },
  { id: "AE-ITALIAN", name: "Italian-Inspired", summary: "Soft tailoring, ease and elegant nonchalance without caricature.", silhouetteBias: ["TAILORED", "RELAXED"], colorBehavior: ["WARM_NEUTRAL", "EARTH", "MUTED_COLOR"], materialBehavior: ["SOFT", "BREATHABLE", "TACTILE"], detailDensity: "CLASSIC", meta: verified },
  { id: "AE-BRITISH", name: "British-Inspired", summary: "Defined structure, heritage cloth and disciplined proportions.", silhouetteBias: ["TAILORED", "STRAIGHT"], colorBehavior: ["DEEP_NEUTRAL", "HERITAGE"], materialBehavior: ["STRUCTURED", "TEXTURED"], detailDensity: "CLASSIC", meta: verified },
  { id: "AE-RESORT-LUXURY", name: "Resort Luxury", summary: "Climate-led relaxed sophistication using breathable natural texture.", silhouetteBias: ["RELAXED", "STRAIGHT"], colorBehavior: ["LIGHT_NEUTRAL", "EARTH", "COASTAL_MUTED"], materialBehavior: ["LINEN", "OPEN_TEXTURE", "SOFT"], detailDensity: "MINIMAL", meta: verified },
  { id: "AE-CONTEMP-INDIAN", name: "Contemporary Indian", summary: "Modern premium dressing informed by climate, event and cultural setting.", silhouetteBias: ["TAILORED", "RELAXED"], colorBehavior: ["NEUTRAL_TO_RICH", "CONTEXTUAL"], materialBehavior: ["BREATHABLE", "TACTILE", "CRAFT_AWARE"], detailDensity: "CLASSIC", meta: verified },
  { id: "AE-MINIMAL", name: "Minimal", summary: "Fewer components with higher precision in material, fit and line.", silhouetteBias: ["TAILORED", "STRAIGHT"], colorBehavior: ["LIMITED_PALETTE", "TONAL"], materialBehavior: ["CLEAN", "REFINED"], detailDensity: "MINIMAL", meta: verified },
];

export const pairingRelations: KnowledgeRelation[] = [
  { id: "REL-LINEN-CAMP", sourceType: "FABRIC", sourceId: "FB-LINEN-PLAIN-LIGHT-001", targetType: "GARMENT", targetId: "SH-CAMP-001", relation: "PREFERRED_FOR", strength: 0.94, conditions: { climate: ["HOT_HUMID", "HOT_DRY"] }, evidence: "Part 2 fabric suitability + Part 5 resort profile", version: KNOWLEDGE_VERSION },
  { id: "REL-LINEN-DRAWSTRING", sourceType: "FABRIC", sourceId: "FB-LINEN-PLAIN-LIGHT-001", targetType: "GARMENT", targetId: "TR-DRAWSTRING-LINEN-001", relation: "PREFERRED_FOR", strength: 0.96, evidence: "Material/silhouette compatibility", version: KNOWLEDGE_VERSION },
  { id: "REL-TROPICAL-SUIT", sourceType: "FABRIC", sourceId: "FB-WOOL-TROPICAL-001", targetType: "GARMENT", targetId: "SU-SB-2PC-001", relation: "WORKS_WITH", strength: 0.92, conditions: { context: ["BUSINESS", "FORMAL"] }, evidence: "Warm-weather tailoring logic", version: KNOWLEDGE_VERSION },
  { id: "REL-RESORT-LINEN", sourceType: "AESTHETIC", sourceId: "AE-RESORT-LUXURY", targetType: "FABRIC", targetId: "FB-LINEN-PLAIN-LIGHT-001", relation: "PREFERRED_FOR", strength: 0.97, evidence: "Part 5 resort luxury profile", version: KNOWLEDGE_VERSION },
  { id: "REL-BRITISH-FLANNEL", sourceType: "AESTHETIC", sourceId: "AE-BRITISH", targetType: "FABRIC", targetId: "FB-WOOL-FLANNEL-001", relation: "PREFERRED_FOR", strength: 0.91, evidence: "Part 5 British tailoring profile", version: KNOWLEDGE_VERSION },
  { id: "REL-BEACH-SOFT-BLAZER", sourceType: "CONTEXT", sourceId: "CTX-BEACH-WEDDING-DAY-001", targetType: "GARMENT", targetId: "JK-SOFT-SB-001", relation: "SUPPORTS", strength: 0.86, conditions: { material: ["LINEN", "LINEN_COTTON", "OPEN_WEAVE"] }, evidence: "Context + climate rule", version: KNOWLEDGE_VERSION },
  { id: "REL-HOT-FLANNEL-CONFLICT", sourceType: "CONTEXT", sourceId: "CTX-BEACH-WEDDING-DAY-001", targetType: "FABRIC", targetId: "FB-WOOL-FLANNEL-001", relation: "CONFLICTS_WITH", strength: 0.98, evidence: "Heat/weight conflict rule", version: KNOWLEDGE_VERSION },
  { id: "REL-BLACKTIE-LINEN-CONFLICT", sourceType: "GARMENT", sourceId: "SU-TUXEDO-001", targetType: "FABRIC", targetId: "FB-LINEN-PLAIN-LIGHT-001", relation: "CONFLICTS_WITH", strength: 0.90, evidence: "Formality/material mismatch for default black-tie execution", version: KNOWLEDGE_VERSION },
];

export const knowledgeSummary = {
  version: KNOWLEDGE_VERSION,
  garments: garments.length,
  fabrics: fabrics.length,
  contexts: contexts.length,
  aesthetics: aesthetics.length,
  relations: pairingRelations.length,
};

export function findGarments(params: { family?: string; formality?: string; climate?: string } = {}) {
  return garments.filter((item) => {
    if (params.family && item.family !== params.family) return false;
    if (params.formality && !item.formalities.includes(params.formality as never)) return false;
    if (params.climate && !item.climates.includes(params.climate as never)) return false;
    return true;
  });
}

export function validateKnowledgeSeed() {
  const all = [...garments, ...fabrics, ...contexts, ...aesthetics];
  const ids = all.map((item) => item.id);
  const duplicateIds = ids.filter((id, index) => ids.indexOf(id) !== index);
  const knownIds = new Set(ids);
  const relationErrors = pairingRelations.filter((rel) => {
    const sourceNeedsRecord = rel.sourceType !== "COLOR" && rel.sourceType !== "PATTERN";
    const targetNeedsRecord = rel.targetType !== "COLOR" && rel.targetType !== "PATTERN";
    return (sourceNeedsRecord && !knownIds.has(rel.sourceId)) || (targetNeedsRecord && !knownIds.has(rel.targetId)) || rel.strength < 0 || rel.strength > 1;
  });
  return { ok: duplicateIds.length === 0 && relationErrors.length === 0, duplicateIds, relationErrors };
}
