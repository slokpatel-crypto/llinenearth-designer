# Architecture Decisions — Phase 0

## ADR-001 — Modular monorepo
**Status:** Accepted  
**Decision:** Use npm workspaces with `apps/web`, `apps/worker`, and focused packages.  
**Why:** Matches Part 9's modular-monolith direction while allowing the worker to scale independently later.  
**Consequence:** Shared types/rules live in packages; no microservices are introduced in Phase 0.

## ADR-002 — Next.js + TypeScript shell
**Status:** Accepted  
**Decision:** App Router, TypeScript, server-side APIs, CSS design tokens.  
**Why:** Matches the technical specification and supports a premium responsive UI with a small early operational surface.

## ADR-003 — PostgreSQL + Prisma
**Status:** Accepted  
**Decision:** PostgreSQL is canonical relational storage; Prisma provides typed client + migrations.  
**Why:** Strong schema/migration ergonomics and room for JSON/vector additions later.

## ADR-004 — S3-compatible private assets
**Status:** Accepted  
**Decision:** Server-authorized presigned PUT URLs; MinIO is the local S3-compatible service.  
**Why:** Browser never receives storage credentials; assets are owner-scoped and private by default.

## ADR-005 — Authentication boundary before vendor
**Status:** Accepted with known limitation  
**Decision:** Define `AuthAdapter`; use a development-only identity adapter locally and a managed-auth placeholder for production.  
**Why:** No identity vendor is specified yet. This avoids accidental lock-in while keeping authorization checks mandatory.  
**Consequence:** Production login is not yet enabled and must be selected before public deployment.

## ADR-006 — Queue abstraction before queue vendor
**Status:** Accepted  
**Decision:** Define a typed `JobQueue`; Phase 0 includes an in-memory development adapter.  
**Why:** Actual AI workload/throughput does not exist yet, so a persistent queue vendor would be premature.

## ADR-007 — Brand intro is session-scoped
**Status:** Accepted  
**Decision:** Full black→logo→navy intro plays once per browser session and is skipped for reduced-motion users.  
**Why:** Preserves premium motion without repeatedly blocking navigation.
