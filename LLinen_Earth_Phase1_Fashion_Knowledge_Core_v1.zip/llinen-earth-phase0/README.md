# LLinen Earth — AI Designer

Current implementation: **Phase 1 — Fashion Knowledge Core**.

## What is included
- Next.js + TypeScript customer web foundation
- Official LLinen Earth logo asset supplied by the brand owner
- Cinematic black -> logo -> deep navy opening sequence
- Premium dark editorial homepage using temporary Pexels tailoring references
- PostgreSQL / Prisma foundation
- Private S3-compatible asset abstraction and job architecture from Phase 0
- Versioned Fashion Brain seed data: garments, fabrics, contexts, aesthetics and pairing relations
- Knowledge inspection page at `/knowledge`
- Read APIs at `/api/v1/knowledge/*`
- Phase 1 schema migration and regression checks

## Knowledge version
`LE-KB-1.0.0`

## Local checks available
```bash
npm run phase0:check
npm run phase1:check
```

After dependencies are installed, run the normal workspace typecheck/tests/build as described in the specs.

## Reference imagery
The homepage currently uses free-to-use Pexels reference photographs by Tima Miroshnichenko to establish visual direction. These should be replaced or formally approved for the final brand production asset set.

## Specs
The complete product specifications (Parts 1-9 and Master Build Specification) live under `/specs`.
