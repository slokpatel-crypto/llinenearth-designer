**LLINEN EARTH**

**Technical Architecture, Database, APIs & Implementation Plan**

*Product Engineering Specification - Part 9, v1.0*

A provider-flexible architecture for turning the LLinen Earth Fashion
Brain, Designer Engine and visualization system into a production web
application.

**WEB APP -\> API -\> DESIGN ORCHESTRATOR -\> KNOWLEDGE / RULES -\> AI
SERVICES -\> DATABASE / STORAGE -\> JOBS -\> QA / OBSERVABILITY**

# 1. Engineering Goal

The implementation should preserve the structured intelligence defined
in Parts 1-8. The product must not become a thin chatbot that sends one
giant prompt to an AI model. Core fashion data, rules, design versions,
scoring, provenance and render specifications should exist as durable
application data.

- Use AI models as replaceable capabilities, not as the database.

- Keep deterministic rules and scoring testable in code/configuration.

- Store structured design state independently from generated prose and
  images.

- Make expensive image generation asynchronous.

- Build an MVP that can evolve without rewriting the Fashion Brain.

# 2. Recommended System Shape

| **Layer**                | **Recommended responsibility**                                                             |
|--------------------------|--------------------------------------------------------------------------------------------|
| Frontend                 | Responsive premium web experience, upload, consultation, compare/refine, multi-view viewer |
| Backend API              | Authentication, sessions, designs, fabrics, garments, business rules                       |
| Designer Orchestrator    | Coordinates analysis, retrieval, constraints, candidate generation, scoring and refinement |
| Knowledge Layer          | Garment ontology, fabric intelligence, contexts, aesthetics, pairing rules                 |
| AI Gateway               | Provider-neutral interface for language/vision/image models                                |
| Relational Database      | Users, sessions, designs, versions, taxonomy, scores, metadata                             |
| Object Storage           | Fabric uploads, references, generated renders, thumbnails                                  |
| Vector / Retrieval Layer | Semantic retrieval over curated fashion knowledge and approved references                  |
| Job Queue                | Long-running analysis, generation, validation and repair jobs                              |
| Observability            | Logs, traces, metrics, model/provider cost and quality monitoring                          |

# 3. Suggested Technology Stack

Use mature, mainstream components and keep provider-specific code behind
adapters. Exact vendors can be changed during implementation.

| **Area**         | **Practical default**                                                          | **Reason**                                                        |
|------------------|--------------------------------------------------------------------------------|-------------------------------------------------------------------|
| Frontend         | React + Next.js + TypeScript                                                   | Strong production web ecosystem, routing, server/client rendering |
| UI styling       | CSS variables/tokens + Tailwind CSS or equivalent                              | Fast implementation of a controlled design system                 |
| Backend          | TypeScript service layer; Next.js server APIs for MVP, separable service later | Reduces early operational complexity                              |
| Database         | PostgreSQL                                                                     | Reliable relational core + JSON support                           |
| ORM              | Prisma / Drizzle / equivalent typed ORM                                        | Schema safety and migrations                                      |
| Object storage   | S3-compatible object storage                                                   | Large image/file storage independent of DB                        |
| Queue            | Managed queue or Redis-backed worker system                                    | Asynchronous AI/image jobs                                        |
| Vector search    | Postgres vector extension initially; dedicated vector service only if needed   | Avoid premature infrastructure                                    |
| Authentication   | Managed auth or standards-based OAuth/email login                              | Security and faster launch                                        |
| Deployment       | Managed frontend + managed Postgres/object storage/workers                     | Small-team operational simplicity                                 |
| Analytics        | Privacy-conscious product analytics                                            | Funnel and quality measurement                                    |
| Error monitoring | Centralized error + performance monitoring                                     | Production debugging                                              |

# 4. Monolith First, Services Later

- Start as a modular monolith: one repository, clear internal modules,
  one relational database.

- Do not create microservices for every Fashion Brain module at MVP.

- Separate boundaries in code: garments, fabrics, context, pairing,
  aesthetics, designer, visualization, users.

- Extract a service only when scale, ownership or reliability actually
  requires it.

- Image workers can be operationally separate early because they are
  long-running and resource-intensive.

# 5. Core Domain Modules

| **Module**    | **Owns**                                                  |
|---------------|-----------------------------------------------------------|
| identity      | Users, roles, consent, preferences                        |
| garments      | Taxonomy, attributes, garment variants, visual references |
| fabrics       | Fabric assets, analyses, technical properties, confidence |
| contexts      | Occasion, destination, climate/formality profiles         |
| aesthetics    | Aesthetic profiles, dimensions, compatibility             |
| pairing       | Color/pattern/material compatibility graph                |
| designer      | Briefs, candidates, scoring, refinement, design versions  |
| visualization | Render specs, views, validation, repairs                  |
| catalogue     | Published garment/fabric educational content              |
| inventory     | Optional LLinen Earth fabric/product availability         |
| consultation  | Store/designer handoff                                    |
| analytics     | Events and quality metrics                                |

# 6. Database Principles

- Stable IDs for every garment, fabric, context, aesthetic and design
  version.

- Normalize identity and relationships; use JSON fields for evolving
  attribute payloads where appropriate.

- Never overwrite a finalized design version; create a new version.

- Keep user-uploaded assets separate from public catalogue assets.

- Store confidence and provenance with inferred data.

- Use soft deletion/retention rules for user content where product
  policy requires it.

# 7. Primary Database Entities

| **Entity**          | **Key fields**                                                           |
|---------------------|--------------------------------------------------------------------------|
| users               | id, role, profile, preferences, created_at                               |
| design_sessions     | id, user_id, entry_mode, status, current_state                           |
| garment_definitions | id, family, name, taxonomy_version, attributes_schema                    |
| garment_variants    | id, definition_id, attributes, status                                    |
| fabric_assets       | id, owner/source, object_key, rights_class, metadata                     |
| fabric_profiles     | id, asset_id, fiber/weave/color/pattern/drape properties, confidence     |
| context_profiles    | id, occasion, venue, time, climate, formality, preferences               |
| aesthetic_profiles  | id, primary, secondary, dimensions, weights                              |
| pairing_rules       | id, source_node, target_node, strength, conditions, exceptions           |
| design_candidates   | id, session_id, hypothesis, garments, scores, rationale                  |
| design_versions     | id, parent_id, candidate_id, locked_spec, change_delta                   |
| render_sets         | id, design_version_id, model_id, status, consistency_score               |
| renders             | id, render_set_id, view, provider, model_version, object_key, validation |
| reference_assets    | id, rights_class, provenance, annotations                                |
| consultations       | id, user_id, design_version_id, status, store_notes                      |

# 8. Knowledge Graph Representation

Do not require a graph database at launch. Store graph-like
relationships in relational tables with typed nodes and edges. Move to a
dedicated graph system only if traversal complexity justifies it.

| **Edge field**        | **Meaning**                                                  |
|-----------------------|--------------------------------------------------------------|
| source_type/source_id | Fabric, color, garment, aesthetic, context, etc.             |
| target_type/target_id | Related node                                                 |
| relation              | works_with, conflicts_with, preferred_for, inspired_by, etc. |
| strength              | 0-1 compatibility                                            |
| conditions            | Season, climate, formality, garment role                     |
| exceptions            | Known conflict cases                                         |
| evidence              | Designer rule, curated source, learned signal                |
| version               | Rule-set version                                             |
| active_from/to        | Useful for time-sensitive trend signals                      |

# 9. Asset Storage Model

| **Bucket/prefix**  | **Content**                               |
|--------------------|-------------------------------------------|
| user/fabrics       | Original customer fabric uploads          |
| user/references    | Customer inspiration images               |
| catalogue/garments | Approved garment reference renders/photos |
| catalogue/fabrics  | Owned/licensed material references        |
| renders/previews   | Temporary lower-cost concept images       |
| renders/final      | Approved premium renders                  |
| renders/details    | Construction/detail crops                 |
| system/thumbnails  | Optimized UI derivatives                  |

- Use signed/expiring URLs for private assets.

- Keep original upload immutable; derivatives get new asset IDs.

- Store content type, dimensions, checksum and provenance.

- Apply lifecycle policies to temporary previews.

# 10. API Design

Use versioned JSON APIs internally. The frontend should never directly
call model providers.

| **Endpoint family** | **Examples**                                                 |
|---------------------|--------------------------------------------------------------|
| Sessions            | POST /api/v1/design-sessions; GET/PATCH /design-sessions/:id |
| Uploads             | POST /api/v1/assets/upload-url; POST /assets/:id/complete    |
| Fabric analysis     | POST /api/v1/fabrics/:id/analyze                             |
| Context             | POST/PATCH /api/v1/contexts/:id                              |
| Candidates          | POST /api/v1/design-sessions/:id/generate-candidates         |
| Refinement          | POST /api/v1/designs/:id/refine                              |
| Lock design         | POST /api/v1/designs/:id/finalize                            |
| Visualization       | POST /api/v1/designs/:id/render                              |
| Render status       | GET /api/v1/render-sets/:id                                  |
| Catalogue           | GET /api/v1/garments; GET /api/v1/fabrics                    |
| Consultation        | POST /api/v1/consultations                                   |

# 11. Asynchronous Job Architecture

Long AI operations should return a job ID quickly and continue in a
worker.

1\. Frontend requests analysis/render.

2\. API validates permissions and design state.

3\. API creates a job record and enqueues work.

4\. Worker claims job and calls the appropriate AI/provider adapter.

5\. Worker stores structured output/assets.

6\. Validator checks output.

7\. Repair job runs if needed.

8\. Job status becomes completed/failed.

9\. Frontend receives progress via polling, server-sent events or
websocket where justified.

# 12. AI Gateway

Create one internal interface for all AI capabilities so the product is
not locked to one provider.

| **Capability**     | **Interface behavior**                                           |
|--------------------|------------------------------------------------------------------|
| Vision analysis    | image + schema -\> structured observations/confidence            |
| Language reasoning | structured brief + retrieved knowledge -\> structured candidates |
| Embedding          | text/image representation -\> vector                             |
| Image generation   | visualization spec + references -\> render                       |
| Image editing      | image + mask + locked constraints -\> repaired image             |
| Moderation/safety  | input/output -\> policy result where required                    |

- Record provider, model/version, latency, cost and request ID.

- Validate structured responses against schemas.

- Retry transient failures with bounded backoff.

- Never place secret API keys in frontend code.

# 13. Fashion Brain Retrieval

- Retrieve only the relevant garment/fabric/aesthetic/context knowledge
  for each decision.

- Use structured filters before semantic similarity where possible.

- Prefer curated internal knowledge over arbitrary live-web content in
  the design path.

- Attach source/provenance IDs to retrieved references.

- Version the knowledge corpus so recommendation changes can be
  reproduced.

# 14. Designer Engine Runtime

1\. Load session, fabric profile, context and user preferences.

2\. Run constraint evaluation.

3\. Retrieve relevant garment/aesthetic/pairing knowledge.

4\. Generate design hypotheses.

5\. Construct structured candidates.

6\. Run deterministic feasibility filters.

7\. Calculate explicit scores.

8\. Apply diversity penalty.

9\. Generate user-facing rationale from final structured candidates.

10\. Persist all candidates and score components.

# 15. Rules Engine

Keep high-value rules outside prompts in editable configuration or code.

| **Rule class** | **Example**                                                |
|----------------|------------------------------------------------------------|
| Hard rejection | Heavy structured wool for extreme hot outdoor context      |
| Compatibility  | Pattern density conflict                                   |
| Scoring        | Increase climate weight for outdoor summer event           |
| Aesthetic      | Quiet luxury penalizes excessive detail density            |
| Production     | Construction not supported by current tailoring capability |
| Visualization  | Back view must preserve specified vent type                |

# 16. Structured Output Validation

- Define JSON Schema or equivalent typed validation for every
  AI-produced object.

- Reject unknown garment attribute values unless an extension workflow
  exists.

- Validate references to stable IDs.

- Clamp scores to expected ranges.

- Require confidence for inferred fabric properties.

- Never save malformed model output as canonical design state.

# 17. Design Versioning

| **Field**         | **Purpose**                    |
|-------------------|--------------------------------|
| version_id        | Immutable design state         |
| parent_version_id | Branch/refinement lineage      |
| change_delta      | Exactly what changed           |
| locked_attributes | Fields refinement cannot alter |
| created_by        | User, AI, staff/designer       |
| reason            | Natural-language summary       |
| spec_hash         | Detect accidental mutation     |
| created_at        | Audit chronology               |

# 18. Visualization Pipeline

1\. Load finalized design version.

2\. Compile visualization object.

3\. Choose provider/model based on required capability.

4\. Generate low-cost preview where appropriate.

5\. Validate identity, garment, fabric and view.

6\. Run targeted repairs.

7\. Create optimized web derivatives.

8\. Store final render set and validation scores.

9\. Expose only approved/threshold-passing renders as premium final
output.

# 19. Provider Routing

| **Decision signal**    | **Routing use**                                           |
|------------------------|-----------------------------------------------------------|
| Reference fidelity     | Choose model strong at conditioning/editing               |
| Multi-view consistency | Prefer provider with strongest identity/structure control |
| Latency                | Use faster model for previews                             |
| Cost                   | Keep premium model for final render                       |
| Resolution             | Use suitable final/upscale pipeline                       |
| Availability           | Fail over to approved secondary provider                  |
| Region/privacy         | Route only where data policy permits                      |

# 20. Authentication & Roles

| **Role**      | **Capabilities**                                         |
|---------------|----------------------------------------------------------|
| Guest         | Explore catalogue; temporary design session if allowed   |
| Customer      | Upload, design, save, refine, share/request consultation |
| Store staff   | Open customer-approved design, inventory mapping         |
| Designer      | Override/pin attributes, approve concepts/renders        |
| Admin         | Manage taxonomy, rules, references, users, providers     |
| System worker | Scoped machine permissions only                          |

# 21. Privacy & Security

- Encrypt data in transit and at rest using managed platform controls.

- Use least-privilege service credentials and role-based access.

- Keep private user assets behind authorization checks/signed URLs.

- Do not log raw sensitive user images unnecessarily.

- Define retention/deletion behavior for user uploads and generated
  assets.

- Separate public catalogue assets from private customer assets.

- Protect upload endpoints with file type/size validation and malware
  scanning where appropriate.

- Rate-limit expensive AI endpoints and abuse-prone public routes.

- Store secrets in server-side secret management, never source control.

# 22. Rights & Provenance Controls

| **Rights class**        | **Allowed use**                                                         |
|-------------------------|-------------------------------------------------------------------------|
| owned                   | Training/retrieval/render/reference according to internal policy        |
| licensed                | Only uses permitted by license                                          |
| public_domain           | Permitted uses with provenance retained                                 |
| user_provided           | Use for that user's requested workflow under product terms              |
| external_reference_only | Research/reference; not assumed reusable for training/commercial assets |

Every asset should carry provenance and rights metadata before entering
a training, retrieval or public catalogue pipeline.

# 23. Observability

| **Signal**    | **Track**                                                             |
|---------------|-----------------------------------------------------------------------|
| API           | Latency, errors, rate limits                                          |
| AI calls      | Provider/model, tokens/units, latency, cost, schema failures          |
| Designer      | Candidate scores, rejection reasons, refinement stability             |
| Visualization | First-pass success, repairs, consistency scores                       |
| Jobs          | Queue time, run time, retry/failure rate                              |
| UX            | Funnel events from Part 8                                             |
| Business      | Design saves, consultation requests, store conversion where available |

# 24. Cost Controls

- Do not generate premium images before a direction is selected.

- Cache fabric analysis and embeddings.

- Cache immutable garment/reference retrieval data.

- Use smaller/faster language models for classification/extraction where
  quality is sufficient.

- Use higher-capability models for designer synthesis only where needed.

- Set per-session image-generation budgets.

- Repair local regions rather than regenerate full render sets.

- Track cost per successful finalized design, not only cost per API
  call.

# 25. Performance Targets

| **Interaction**     | **Target behavior**                                                         |
|---------------------|-----------------------------------------------------------------------------|
| Navigation/UI       | Feels immediate; skeletons only where necessary                             |
| Upload              | Direct-to-object-storage where possible                                     |
| Fabric analysis     | Progress shown; result returned asynchronously if slow                      |
| Designer candidates | First useful result prioritized over waiting for every optional enhancement |
| Preview render      | Asynchronous with meaningful progress                                       |
| Saved design        | Immediate DB write; image processing can follow                             |
| Catalogue           | CDN/cache optimized                                                         |

# 26. Caching Strategy

- CDN-cache public catalogue images and static pages.

- Cache garment/fabric taxonomy reads aggressively with version keys.

- Cache embeddings by content hash.

- Cache fabric analysis by asset checksum unless user corrects it.

- Do not cache private responses across users.

- Invalidate design-derived caches when design_version_id changes.

# 27. Search & Retrieval

- Use relational filters for garment family, fabric, formality, climate
  and aesthetic.

- Add semantic search for natural-language queries such as 'relaxed
  wedding trousers for humid weather'.

- Use hybrid ranking: filters + semantic relevance + curated priority.

- Keep catalogue search separate from Designer candidate ranking.

# 28. Admin / Knowledge Studio

A production system needs an internal interface for fashion experts;
otherwise every knowledge change becomes a developer task.

- Create/edit garment definitions and attributes.

- Upload/annotate approved reference images.

- Edit fabric and aesthetic profiles.

- Create pairing/constraint rules with conditions.

- Review AI failures and designer overrides.

- Approve render examples.

- Version and publish knowledge changes.

- View quality metrics and regression alerts.

# 29. Inventory Integration

Keep inventory optional in the first design pass. When enabled, map
ideal recommendations to actual LLinen Earth stock.

| **Entity**        | **Fields**                                                        |
|-------------------|-------------------------------------------------------------------|
| inventory_fabrics | SKU, fabric_profile_id, colorway, stock, location, price metadata |
| availability      | store/location, quantity/status, updated_at                       |
| substitutions     | ideal fabric/profile -\> nearest stocked alternatives             |
| reservations      | Optional future hold/consultation workflow                        |

# 30. Consultation Integration

- A finalized design passes design_version_id, fabric IDs and render set
  to staff.

- Customer controls when a private design is shared with staff.

- Staff changes create a new version rather than modifying the
  customer's approved version.

- Consultation status can move through requested, scheduled, in-progress
  and completed.

- Future integrations can connect calendar/CRM without changing the
  design domain model.

# 31. Testing Pyramid

| **Test type**     | **Examples**                                                       |
|-------------------|--------------------------------------------------------------------|
| Unit              | Scoring weights, constraints, compatibility rules                  |
| Schema            | AI outputs conform to types/IDs                                    |
| Integration       | Upload -\> analysis -\> candidate persistence                      |
| Contract          | Provider adapters return normalized outputs                        |
| Golden dataset    | Known fashion briefs produce acceptable structured recommendations |
| Visual regression | UI pages/components                                                |
| Render QA         | Garment/fabric/identity consistency benchmarks                     |
| End-to-end        | Fabric upload -\> final saved design                               |
| Security          | Authorization, upload validation, rate limits                      |

# 32. Fashion Quality Regression Suite

- Maintain fixed benchmark briefs across business, wedding, resort,
  travel, formal and cultural contexts.

- Include difficult fabric/context conflicts.

- Score candidate quality using explicit expected constraints rather
  than exact wording.

- Have expert-reviewed gold examples for critical cases.

- Run the suite before changing models, prompts, rules or scoring
  weights.

- Track quality by garment family and aesthetic, not only one global
  score.

# 33. CI/CD

1\. Every pull request runs type checks, linting, unit tests and schema
tests.

2\. Database migrations are reviewed and tested against staging.

3\. Critical Fashion Brain regression tests run before production
release.

4\. Deploy to staging automatically.

5\. Run smoke tests including one AI-provider path.

6\. Production deploy uses controlled rollout.

7\. Monitor errors/quality after release and support rollback.

# 34. Environments

| **Environment**  | **Purpose**                                                               |
|------------------|---------------------------------------------------------------------------|
| local            | Developer work with mocked/limited AI calls                               |
| test             | Automated tests                                                           |
| staging          | Real integrations, non-production data, QA                                |
| production       | Customer system                                                           |
| optional sandbox | Fashion-team experimentation with prompts/rules without production impact |

# 35. Repository Structure

/apps  
/web \# Next.js customer/admin UI  
/worker \# async AI/image jobs  
/packages  
/domain \# garment/fabric/context/design types  
/fashion-rules \# deterministic constraints/scoring  
/ai-gateway \# provider adapters  
/db \# schema, migrations, repositories  
/ui \# shared design system  
/schemas \# JSON/validation schemas  
/testing \# fixtures + golden scenarios  
/specs  
/part-01-garments  
/part-02-fabrics  
/part-03-context  
/part-04-pairing  
/part-05-aesthetics  
/part-06-designer  
/part-07-visualization  
/part-08-ux  
/part-09-architecture

# 36. Configuration & Feature Flags

- Keep scoring weights and thresholds versioned.

- Feature-flag new aesthetics, garment families and providers.

- Allow provider/model routing changes without frontend deployment.

- Store prompt/compiler versions with generated outputs.

- Support kill switches for costly or unstable generation features.

# 37. MVP Build Phases

| **Phase**             | **Deliverable**                                                           |
|-----------------------|---------------------------------------------------------------------------|
| 0 - Foundation        | Repository, CI/CD, auth, database, object storage, design tokens          |
| 1 - Knowledge Core    | Garment/fabric/context/aesthetic schemas + seeded catalogue               |
| 2 - Designer MVP      | Fabric upload, context intake, candidate engine, scoring, 3 directions    |
| 3 - UX Product        | Premium homepage, consultation, compare/refine, saved designs             |
| 4 - Visualization MVP | Front/back/detail generation with locked design spec                      |
| 5 - Store Handoff     | Consultation + inventory mapping                                          |
| 6 - Quality           | Admin knowledge studio, regression suite, observability, repair workflows |

# 38. What NOT to Build First

- Do not begin with a huge 3D virtual try-on system.

- Do not build microservices before the domain is stable.

- Do not train a custom foundation model before proving value with
  existing models + structured knowledge.

- Do not populate thousands of low-quality garment/reference images.

- Do not automate learning from every click before human-reviewed
  quality data exists.

- Do not make the homepage the priority while the core Designer flow is
  still undefined.

- Do not make one AI provider a permanent architectural dependency.

# 39. First Production Milestone

A meaningful first release should prove the core promise rather than
every future feature.

- Customer uploads one fabric photo.

- System returns a structured fabric profile with editable assumptions.

- Customer answers a short occasion/context flow.

- Designer Engine returns 3 genuinely distinct, scored directions.

- Customer selects and refines one direction.

- System creates at least front/back/detail visualizations tied to one
  locked design version.

- Customer saves the design and can request a LLinen Earth consultation.

# 40. Data Needed Before Build

- Approved LLinen Earth logo and brand assets.

- Initial garment taxonomy/attributes from Part 1 converted to
  structured seed data.

- Initial fabric profiles and material references.

- Curated aesthetic definitions and pairing rules.

- A small licensed/owned reference image set.

- At least 20-50 expert-reviewed design scenarios for testing.

- Store/consultation details and initial inventory integration decision.

- Privacy/retention policy for customer uploads.

# 41. Coding-Agent Handoff Rules

When Claude Code, Codex or another coding agent is used, the
specifications should be committed into the repository and treated as
authoritative product requirements.

1\. Read the Master Build Specification and referenced part documents
before implementation.

2\. Implement only the requested phase/issue, not the entire roadmap in
one pass.

3\. Do not replace structured Fashion Brain logic with a single prompt.

4\. Write tests for acceptance criteria before marking a phase complete.

5\. Document architectural deviations and why they were necessary.

6\. Keep secrets and provider credentials outside the repository.

7\. Run the full relevant test suite before creating a pull request.

8\. Do not change locked schemas or IDs casually; use
migrations/versioning.

# 42. Example Agent Task - Phase 0

Read /specs/MASTER_BUILD_SPEC.md and Parts 1-9.  
Implement Phase 0 only.  
  
Deliver:  
- Next.js + TypeScript application shell  
- LLinen Earth design tokens and black-to-navy brand intro  
- PostgreSQL schema/migrations  
- authentication foundation  
- S3-compatible upload abstraction  
- typed domain packages  
- test/CI setup  
- environment configuration  
- README with local setup  
  
Do not implement AI generation yet.  
Do not invent new domain fields without documenting them.  
All acceptance tests for Phase 0 must pass before proceeding.

# 43. Scale Evolution

| **Trigger**                         | **Evolution**                                                       |
|-------------------------------------|---------------------------------------------------------------------|
| Image jobs dominate runtime         | Scale worker pool independently                                     |
| Vector corpus becomes large/complex | Evaluate dedicated retrieval service                                |
| Designer traffic grows              | Separate orchestration service                                      |
| Global users                        | Regional storage/compute strategy                                   |
| Large inventory                     | Dedicated inventory/search integration                              |
| Multiple stores/designers           | Role/tenant and workflow expansion                                  |
| Custom models become valuable       | Introduce model training/evaluation pipeline behind same AI Gateway |

# 44. Technical Acceptance Criteria

- All core domain objects have stable typed schemas.

- AI providers can be swapped through adapters.

- User files are stored privately with provenance.

- Designer candidates and scores are persisted and reproducible by
  version.

- Refinement creates immutable design versions.

- Image generation is asynchronous and tied to design_version_id.

- The system has tests for fashion constraints and end-to-end design
  flow.

- Model/API costs and failures are observable.

- Admin fashion knowledge can evolve without rewriting the entire
  application.

- The MVP can be deployed and operated by a small team.

# 45. Parts 1-9 System Map

| **Part** | **System role**                         |
|----------|-----------------------------------------|
| 1        | Garment Design System                   |
| 2        | Fabric Intelligence                     |
| 3        | Occasion / Destination / Context        |
| 4        | Color / Pattern / Material Pairing      |
| 5        | Style & Aesthetic Intelligence          |
| 6        | AI Designer Logic & Decision Engine     |
| 7        | AI Image & Model Generation             |
| 8        | Website UX/UI & Premium Experience      |
| 9        | Technical Architecture & Implementation |

Together these form the product specification. The next document should
not introduce another subsystem. It should consolidate Parts 1-9 into
one MASTER BUILD SPECIFICATION with implementation order,
source-of-truth rules, acceptance gates and coding-agent instructions.

# 46. Next Deliverable

Next: LLinen Earth MASTER BUILD SPECIFICATION. This will be the primary
file placed at the root of the project/specs folder and handed to a
coding agent. It will reference Parts 1-9, define the exact phased build
sequence, specify what the agent must and must not change, and provide
phase-by-phase completion tests.
