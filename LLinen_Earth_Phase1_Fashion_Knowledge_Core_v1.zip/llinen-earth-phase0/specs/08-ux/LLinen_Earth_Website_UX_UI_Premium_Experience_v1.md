**LLINEN EARTH**

**Website UX/UI & Premium Experience**

*Product Experience Specification - Part 8, v1.0*

A premium digital experience that turns the LLinen Earth Fashion Brain
and AI Designer into a clear, elegant, high-trust customer journey.

**BRAND ENTRY -\> EXPLORE -\> UPLOAD -\> CONSULT -\> DESIGN -\> COMPARE
-\> REFINE -\> VISUALIZE -\> SAVE / SHARE / VISIT STORE**

# 1. Product Experience Goal

The website should feel closer to a premium fashion atelier than an AI
utility. AI is the intelligence underneath the experience, not the
visual theme. The interface should be calm, cinematic, precise and easy
enough for a customer who knows nothing about tailoring terminology.

- Make complex fashion decisions feel simple.

- Show expertise without overwhelming the customer.

- Use progressive disclosure instead of long forms.

- Prioritize fabric, garment and final look imagery over UI decoration.

- Maintain trust by explaining recommendations and uncertainty clearly.

- Preserve a luxury brand atmosphere from first second to final design.

# 2. Opening Brand Experience

The initial experience should follow the brand direction already
defined: begin on pure black, introduce the LLinen Earth logo, then
transition smoothly into the deep navy brand environment.

1\. 0.0-0.5 sec: pitch-black screen, no visible chrome.

2\. 0.5-1.4 sec: LLinen Earth logo fades in softly at center.

3\. 1.4-2.2 sec: a subtle glow or material-like light movement can
appear behind the logo.

4\. 2.2-3.0 sec: background transitions from black to the primary navy
tone.

5\. 3.0 sec onward: navigation and first content enter with restrained
motion.

- Do not use a loud loading animation.

- Do not replay the full intro on every internal navigation.

- Respect reduced-motion accessibility settings.

- Mobile version should be shorter and lighter to avoid perceived delay.

# 3. Visual Design Direction

| **Element**        | **Direction**                                                                |
|--------------------|------------------------------------------------------------------------------|
| Primary background | Deep navy / near-black                                                       |
| Secondary surfaces | Slightly lighter navy, warm off-white, muted neutrals                        |
| Accent             | Use sparingly; fabric and garments should provide most color                 |
| Typography         | Editorial serif or refined display face paired with clean sans-serif UI font |
| Spacing            | Generous whitespace; premium rhythm; avoid dense dashboards                  |
| Corners            | Subtle, not overly rounded app-style cards                                   |
| Borders            | Fine, low-contrast lines                                                     |
| Shadows            | Minimal and soft                                                             |
| Motion             | Slow, intentional, fabric-like easing rather than bouncy app motion          |
| Photography        | Large, high-quality, material-first imagery                                  |

# 4. Core Information Architecture

| **Primary area** | **Purpose**                                                                 |
|------------------|-----------------------------------------------------------------------------|
| Home             | Brand story + immediate entry into AI Designer                              |
| AI Designer      | Fabric/reference upload and conversational design process                   |
| Garment Library  | Explore shirts, trousers, jackets, suits and their construction differences |
| Fabric Library   | Explore fabric families, textures, behavior and suitability                 |
| Designs          | Saved concepts and finalized looks                                          |
| About / Atelier  | Brand philosophy, tailoring expertise and process                           |
| Visit / Contact  | Store location, appointment/contact actions                                 |
| Account          | Preferences, saved fabrics, designs and privacy controls                    |

# 5. Homepage Structure

1\. Cinematic brand entry.

2\. Hero statement with one clear primary action: Start Designing.

3\. Interactive fabric-to-outfit demonstration.

4\. Three-step explanation: Upload fabric -\> Tell us the occasion -\>
Receive designer directions.

5\. Selected garment/fabric knowledge preview to establish expertise.

6\. Premium visual examples of designer outcomes.

7\. Why LLinen Earth AI Designer is different: fabric-aware,
context-aware, explainable, tailored.

8\. Atelier/store section connecting digital design to real tailoring
and fabric purchase.

9\. Minimal footer with contact, legal and social links.

# 6. Hero Section

Avoid generic AI marketing language. The hero should communicate the
customer's outcome: turning fabric into a considered look.

| **Element**   | **Recommendation**                                                                 |
|---------------|------------------------------------------------------------------------------------|
| Headline      | Short, fashion-led, not technology-led                                             |
| Subheadline   | Explain that the system designs around fabric, occasion and personal style         |
| Primary CTA   | Start Designing                                                                    |
| Secondary CTA | Explore Garments / See How It Works                                                |
| Visual        | Premium fabric transforming into a completed outfit or controlled multi-view model |
| AI wording    | Secondary; do not lead with 'powered by AI'                                        |

# 7. AI Designer Entry Screen

The first interaction should ask what the customer wants to begin with,
not immediately display a complex upload panel.

| **Starting path**  | **Action**                       |
|--------------------|----------------------------------|
| I have a fabric    | Upload fabric photo              |
| I have a reference | Upload inspiration image         |
| I have an occasion | Start from event/context         |
| I want to explore  | Browse curated design directions |

- Each path ultimately enters the same structured Designer Engine.

- Allow users to change the starting path without losing previous input.

- Use one strong sentence explaining each path.

# 8. Fabric Upload Experience

1\. Large drag/drop or camera/upload area.

2\. Show a short capture guide before or immediately after upload.

3\. Display the uploaded fabric as the main visual object.

4\. Run analysis and show only useful observations first: likely color,
texture, pattern, fabric family estimate.

5\. Mark uncertain technical properties clearly rather than presenting
guesses as facts.

6\. Allow quick correction: color is warmer/cooler, pure linen vs blend,
etc.

The analysis screen should feel like a designer examining the fabric,
not a technical diagnostic console.

# 9. Progressive AI Consultation

The consultation behaves conversationally but should use structured UI
controls whenever they reduce effort. Avoid a full-screen chatbot as the
entire product.

| **Question type**   | **Best interface**              |
|---------------------|---------------------------------|
| Occasion            | Visual chips / cards            |
| Destination / venue | Search + suggested chips        |
| Time                | Simple segmented choices        |
| Formality           | Visual scale with examples      |
| Desired impression  | Multi-select style words        |
| Fit                 | Illustrated silhouette cards    |
| Aesthetic           | Image-led cards                 |
| Open nuance         | Short conversational text input |

- Ask 1-2 high-value questions at a time.

- Show a small progress indicator such as 'Understanding your occasion'.

- Do not force the customer to answer irrelevant questions.

- Make assumptions editable from a compact summary.

# 10. Designer Thinking State

When the system is generating directions, avoid generic spinning
loaders. Use a short premium progress sequence that describes useful
stages without exposing hidden reasoning.

| **Stage label**           | **Example**                               |
|---------------------------|-------------------------------------------|
| Reading the fabric        | Analyzing color, texture and drape cues   |
| Understanding the setting | Balancing climate, occasion and formality |
| Building directions       | Exploring silhouette and pairing options  |
| Refining the shortlist    | Selecting the strongest concepts          |

# 11. Design Direction Results

Present 3 strong directions by default: Safe, Elevated and Statement,
with Elevated visually emphasized as the premium recommendation.

| **Card content** | **Requirement**                          |
|------------------|------------------------------------------|
| Direction name   | Short memorable name                     |
| Hero render      | Full look                                |
| One-line concept | What makes the direction different       |
| Garments         | Shirt/trouser/jacket/suit summary        |
| Palette          | Small swatches                           |
| Why it works     | 2-3 concise reasons                      |
| Best for         | Event/venue fit                          |
| Tradeoff         | One honest caution if relevant           |
| Actions          | View details, Compare, Refine, Visualize |

# 12. Compare Experience

- Allow 2-3 directions side-by-side on desktop; stacked comparison on
  mobile.

- Keep garment model, pose and background consistent when comparing
  silhouette/design.

- Highlight differences in silhouette, formality, material and
  aesthetic.

- Provide 'Why this is different' instead of forcing users to inspect
  visually.

- Allow pinning one element from a concept, e.g. 'Keep these trousers,
  try the other jacket'.

# 13. Refinement Experience

Refinement should feel controlled, not like rolling the dice again.

| **Quick refinement** | **Expected system behavior**                      |
|----------------------|---------------------------------------------------|
| More formal          | Adjust construction, styling and footwear         |
| More relaxed         | Soften structure, increase ease                   |
| More premium         | Improve material/detail restraint, not decoration |
| More unique          | Increase controlled novelty                       |
| More classic         | Reduce trend signals                              |
| Change trousers only | Keep all unrelated elements locked                |
| Try another color    | Preserve design and swap compatible palette       |
| Use this reference   | Extract relevant attributes and adapt             |

- Show locked vs editable elements.

- Maintain version history with before/after comparison.

- Allow Undo.

# 14. Garment Detail View

Customers should be able to understand why a garment is different
without knowing tailoring terminology.

| **Layer**                  | **Experience**                                          |
|----------------------------|---------------------------------------------------------|
| Visual                     | Large front/side/back/detail model                      |
| Hotspots                   | Tap lapel, collar, pleat, waistband, cuff, vent, pocket |
| Plain-language explanation | What this detail changes visually or functionally       |
| Technical label            | Shown secondarily for interested users                  |
| Alternatives               | Compare 2-4 nearby options                              |
| Apply                      | Swap detail while preserving other locked attributes    |

# 15. Garment Library

- Organize by trousers, shirts, jackets/blazers and suits.

- Start with visual families, not a 100-item alphabetical list.

- Use consistent mannequin views to isolate garment differences.

- Allow filters by silhouette, formality, climate, aesthetic and
  construction detail.

- Each garment page should show where it is commonly worn, trend
  relevance, construction anatomy and compatible fabrics.

- The library should feed directly into the AI Designer via 'Use this
  style'.

# 16. Fabric Library

- Organize by fiber family, weave/construction, weight, surface and
  use-case.

- Show macro texture + draped view + garment examples.

- Explain breathability, structure, wrinkle character and climate
  suitability in plain language.

- Allow side-by-side fabric comparison.

- Link each fabric type to recommended garments and aesthetics.

- Clearly distinguish educational references from fabrics actually
  available in LLinen Earth inventory.

# 17. Final Design Presentation

After selection, the final design page becomes a premium presentation
rather than another result card.

1\. Large hero view.

2\. Front / 45-degree / side / back / detail selector.

3\. Fabric swatch and palette.

4\. Garment specification summary.

5\. Designer rationale.

6\. Occasion/context summary.

7\. Construction details expandable on demand.

8\. Save, share, book consultation / visit store, and optionally request
tailoring.

# 18. Multi-View Interaction

- Views must switch instantly or with subtle crossfade.

- Keep model scale and frame position stable.

- Allow zoom into fabric and construction details.

- Do not place decorative UI over important garment areas.

- On mobile, use swipe between views with explicit labels.

# 19. Saved Designs

| **Feature**  | **Behavior**                                        |
|--------------|-----------------------------------------------------|
| Design cards | Thumbnail, design name, fabric, event, version      |
| Versions     | Compare previous refinements                        |
| Duplicate    | Branch a concept without destroying original        |
| Notes        | Customer or designer notes                          |
| Share        | Private share link / export later if implemented    |
| Status       | Concept, refined, finalized, tailoring consultation |

# 20. Human Designer / Store Handoff

The digital experience should strengthen the physical LLinen Earth
business. A finalized design should be easy to continue with a human
designer or tailor.

- Book or request consultation from the design page.

- Share the structured design ID with store staff.

- Store view can open the same garment/fabric specification.

- Staff can override or pin design attributes and create a new approved
  version.

- If exact fabric is stocked, connect it to the design; otherwise show
  nearest alternatives clearly.

# 21. Premium Navigation

- Keep the top navigation small: Designer, Garments, Fabrics, Designs,
  About.

- Use logo/home at left and Account/Start Designing at right.

- Avoid mega-menu overload at launch.

- When inside Designer flow, reduce navigation distractions and preserve
  progress.

- Use a persistent but understated way to return to the current design
  session.

# 22. Desktop Layout Principles

- Use wide imagery and split-screen layouts for fabric + consultation or
  model + specification.

- Keep content width controlled for text.

- Use sticky context panels during compare/refine flows.

- Allow 2-3 concept cards across without shrinking imagery excessively.

- Prioritize large visual canvas over sidebar-heavy application layouts.

# 23. Mobile Experience

- Mobile must be a first-class design experience, not a compressed
  desktop site.

- Use bottom-sheet controls for filters and refinement options.

- Keep one dominant action visible at a time.

- Use swipeable design directions and view sets.

- Compress the opening animation and heavy media intelligently.

- Camera upload should be frictionless because fabric photos are likely
  to originate on phones.

# 24. Micro-Interactions

| **Interaction** | **Behavior**                           |
|-----------------|----------------------------------------|
| Hover garment   | Subtle elevation / alternate detail    |
| Select fabric   | Soft border/glow, no loud color change |
| Lock attribute  | Small lock transition                  |
| Compare         | Cards align smoothly                   |
| Refine          | Changed fields briefly highlight       |
| Save            | Quiet confirmation, no intrusive modal |
| View switch     | Crossfade or controlled slide          |

# 25. Trust & Explainability

- Use 'Estimated from your photo' for uncertain fabric properties.

- Explain why the top recommendation fits the event and fabric.

- Expose one tradeoff where relevant.

- Never pretend visualization is guaranteed tailoring fit.

- Allow the user to correct AI assumptions easily.

- Show when a recommendation is ideal vs when it is constrained by
  available inventory.

# 26. Accessibility

- Sufficient text/background contrast even within dark luxury theme.

- Keyboard navigation for core web flows.

- Alt text for garment/fabric imagery.

- Reduced-motion behavior for opening and transitions.

- Do not rely on color alone to show selection or warnings.

- Touch targets sized for mobile usability.

- Plain-language alternatives to specialist tailoring terms.

# 27. Performance

- Opening animation must not block content for slow connections.

- Lazy-load heavy garment imagery outside the initial viewport.

- Use progressive image quality for AI renders.

- Cache fabric analysis and approved render sets.

- Avoid autoplay video on mobile unless optimized and muted.

- Show useful content while premium final visualization is still
  processing.

# 28. Page / Route Map

| **Route**             | **Purpose**                         |
|-----------------------|-------------------------------------|
| /                     | Home                                |
| /designer             | AI Designer entry                   |
| /designer/session/:id | Active design consultation          |
| /design/:id           | Design direction/final presentation |
| /compare/:session     | Concept comparison                  |
| /garments             | Garment library                     |
| /garments/:id         | Garment detail                      |
| /fabrics              | Fabric library                      |
| /fabrics/:id          | Fabric detail                       |
| /designs              | Saved designs                       |
| /about                | Brand/atelier story                 |
| /visit                | Store/contact/consultation          |
| /account              | Preferences/privacy                 |

# 29. Component Architecture

| **Component**       | **Role**                         |
|---------------------|----------------------------------|
| BrandIntro          | Black-to-navy logo entry         |
| HeroDesignerCTA     | Primary homepage entry           |
| FabricUploader      | Photo/camera upload              |
| FabricAnalysisCard  | Analysis + corrections           |
| ContextQuestion     | Progressive question renderer    |
| DesignDirectionCard | Safe/Elevated/Statement concept  |
| CompareBoard        | Side-by-side comparison          |
| RefinementPanel     | Controlled design deltas         |
| GarmentViewer       | Front/side/back/detail           |
| GarmentHotspot      | Explain/edit construction detail |
| PaletteStrip        | Colors/material roles            |
| DesignerRationale   | Why-it-works explanation         |
| VersionHistory      | Compare/restore design versions  |
| ConsultationCTA     | Store/designer handoff           |

# 30. Session State

{  
"session_id": "SESSION-...",  
"entry_mode": "fabric_first",  
"fabric_id": "FAB-...",  
"context_id": "CTX-...",  
"current_question": "occasion",  
"assumptions": \[\],  
"candidate_ids": \["DES-1", "DES-2", "DES-3"\],  
"selected_candidate_id": "DES-2",  
"locked_attributes": \[\],  
"active_version_id": "DES-V3",  
"visualization_set_id": "SET-...",  
"status": "refining"  
}

# 31. Design System Tokens

| **Token family** | **Examples**                                                           |
|------------------|------------------------------------------------------------------------|
| Color            | black, navy-950, navy-900, navy-800, ivory, stone, muted-gold optional |
| Spacing          | 4/8/12/16/24/32/48/64/96 scale                                         |
| Typography       | display, heading, body, caption, technical                             |
| Radius           | small/subtle; avoid excessively rounded interface                      |
| Motion           | fast feedback, standard transition, cinematic intro                    |
| Grid             | mobile 4-col; tablet 8-col; desktop 12-col                             |
| Elevation        | mostly flat, selected floating surfaces only                           |

# 32. Tone of Voice

- Concise, assured, refined.

- Explain fashion without sounding academic.

- Avoid chatbot filler.

- Avoid aggressive sales language inside the Designer flow.

- Use specific terms when they help, followed by plain-language
  explanation.

- Recommendations should sound like a designer, not a search engine.

# 33. Empty / Error States

| **State**           | **Response**                                     |
|---------------------|--------------------------------------------------|
| No fabric uploaded  | Show one clear upload action and a sample path   |
| Poor fabric image   | Explain exactly how to retake; do not blame user |
| Analysis uncertain  | Ask one high-value clarification                 |
| No viable design    | Explain conflict and propose closest routes      |
| Render delayed      | Keep design spec visible; show progress          |
| Render failed       | Retry/repair without losing design               |
| Session interrupted | Resume from saved state                          |

# 34. Conversion Without Damaging Premium Feel

- Primary conversion is Start Designing, not constant 'Buy Now'.

- After design confidence increases, surface relevant commercial
  actions.

- Use 'Available at LLinen Earth' or 'Book tailoring consultation'
  contextually.

- Do not place price/discount language throughout the designer
  experience unless business strategy specifically requires it.

- Connect digital design to in-store tailoring as a service benefit, not
  a hard sell.

# 35. Analytics Events

| **Event**               | **Why track**              |
|-------------------------|----------------------------|
| designer_started        | Top-level product adoption |
| fabric_uploaded         | Upload funnel              |
| analysis_corrected      | Model quality / user trust |
| context_completed       | Consultation completion    |
| direction_viewed        | Concept engagement         |
| direction_selected      | Ranking usefulness         |
| refinement_applied      | Most valuable controls     |
| visualization_completed | Pipeline success           |
| design_saved            | Intent                     |
| consultation_requested  | Store conversion           |

# 36. MVP Experience

1\. Black-to-navy brand opening.

2\. Homepage + Start Designing.

3\. Fabric upload and basic analysis.

4\. Progressive context questions.

5\. Three design directions.

6\. Single concept detail/refinement page.

7\. Front/back/detail visualization set.

8\. Save design.

9\. Contact / consultation handoff.

10\. Basic garment/fabric library.

# 37. Premium Evolution

| **MVP**                 | **Premium evolution**                                    |
|-------------------------|----------------------------------------------------------|
| Basic analysis          | Guided fabric capture + high-confidence material profile |
| 3 design cards          | Adaptive designer conversation and deeper portfolio      |
| Front/back/detail       | Full consistent multi-view system                        |
| Quick refinements       | Natural-language controlled editing                      |
| Static garment library  | Interactive construction explorer                        |
| Saved designs           | Versioning, sharing, collaborative designer review       |
| Contact form            | Integrated appointment / store workflow                  |
| Single-user preferences | Persistent style profile and wardrobe context            |

# 38. UX Acceptance Criteria

- A first-time user can start designing without understanding tailoring
  terminology.

- The user can reach first design directions without completing a long
  questionnaire.

- Every AI assumption that matters can be corrected.

- Safe/Elevated/Statement concepts are visibly different.

- Changing one garment does not randomly change the rest of the design.

- The final design is understandable from multi-view imagery and concise
  rationale.

- Mobile fabric upload and consultation are frictionless.

- The product feels fashion-first and premium, not like a generic
  chatbot wrapper.

# 39. Recommended Homepage Copy Principles

- Lead with transformation: fabric -\> considered design.

- Use short statements and large imagery.

- Keep technology claims secondary to fashion outcome.

- Avoid overpromising exact fit from visualization.

- Make the atelier/tailoring connection part of the brand story.

# 40. Part 8 Completion Criteria

- Core site map and customer journey are defined.

- Opening brand animation is specified.

- Fabric-first, occasion-first and reference-first entry paths exist.

- Progressive consultation behavior is defined.

- Design comparison/refinement and final visualization flows are
  defined.

- Garment/fabric libraries connect directly to AI Designer.

- Desktop/mobile, accessibility, performance and analytics requirements
  are documented.

- Developer-ready routes, components and session state are defined.

# 41. Next Specification

Next: Part 9 - Technical Architecture, Database, APIs & Implementation
Plan. This final system specification will define the actual software
stack, database schema, services, AI orchestration, storage,
authentication, vector/reference retrieval, image pipeline,
observability, deployment, security, cost controls, testing strategy and
phased build plan.
