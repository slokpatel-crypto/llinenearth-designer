**LLINEN EARTH**

**Color, Pattern & Material Pairing System**

*Fashion Brain Specification — v1.0*

A designer-grade compatibility engine for turning one fabric into a
coherent full outfit—not merely matching colors.

**COLOR HARMONY + UNDERTONE + VALUE + SATURATION + PATTERN + TEXTURE +
MATERIAL + CONTEXT → OUTFIT COHERENCE**

# 1. Purpose

This layer decides what should accompany a selected fabric or garment.
It treats pairing as a multi-variable design problem. A technically
matching color can still produce a weak outfit if the texture, pattern
scale, formality, fabric weight or visual hierarchy is wrong.

- Create complete shirt–trouser–jacket–suit–shoe–accessory palettes.

- Preserve the uploaded fabric as the visual anchor when appropriate.

- Separate safe combinations from distinctive designer combinations.

- Adapt pairings to occasion, destination, time, climate and aesthetic.

- Provide explainable compatibility scores rather than opaque AI
  guesses.

# 2. Color Representation

Store more than a simple color name. The system should retain
machine-readable color values plus designer-facing descriptors.
Photo-derived color must carry confidence because lighting, white
balance and camera processing can alter appearance.

| **Attribute**            | **Examples / use**                                              |
|--------------------------|-----------------------------------------------------------------|
| Color family             | Blue, green, red, brown, beige, grey, white, black              |
| Hue                      | Position on color wheel                                         |
| Value / lightness        | Light, mid, dark; controls contrast                             |
| Saturation / chroma      | Muted, moderate, vivid                                          |
| Undertone                | Warm, cool, neutral, olive/earth-biased where relevant          |
| Temperature relationship | Warmer/cooler than companion pieces                             |
| Digital values           | HEX/RGB for UI; Lab/OKLCH recommended for perceptual comparison |
| Observed vs confirmed    | Distinguish image estimate from verified swatch/product data    |

# 3. Core Color Harmony Engine

| **Harmony**         | **Use**                                    | **Designer caution**                                     |
|---------------------|--------------------------------------------|----------------------------------------------------------|
| Monochromatic       | One hue across different values/textures   | Needs texture/value separation to avoid flatness         |
| Analogous           | Neighboring hues                           | Keep one dominant color                                  |
| Complementary       | Opposing hue families                      | Usually mute one side for premium menswear               |
| Split complementary | Contrast with more control                 | Useful for accents                                       |
| Neutral + accent    | Neutral base with one intentional color    | Strong default for premium styling                       |
| Tonal neutral       | Cream–stone–taupe–brown or grey families   | Material quality becomes critical                        |
| Dark tonal          | Navy–charcoal–black variations             | Ensure visible separation in low light                   |
| Earth harmony       | Olive, tobacco, sand, rust, cream families | Excellent with natural textures when context supports it |

# 4. Contrast Engine

| **Contrast type** | **Low**           | **Medium**             | **High**                    |
|-------------------|-------------------|------------------------|-----------------------------|
| Value             | Similar lightness | Clear separation       | Light vs very dark          |
| Hue               | Same/near hue     | Related colors         | Opposing color families     |
| Saturation        | Muted together    | One stronger element   | Vivid vs muted              |
| Texture           | Similar surfaces  | Subtle material change | Smooth vs strongly textured |
| Pattern           | Solid/very subtle | One visible pattern    | Multiple assertive patterns |

The AI should control total visual contrast. If color contrast is high,
pattern and texture may need restraint. If the palette is quiet, texture
and construction can carry the interest.

# 5. Undertone Compatibility

- Warm neutrals: cream, camel, tobacco, warm taupe and many earthy
  browns generally coordinate naturally.

- Cool neutrals: crisp grey, blue-grey, cool navy and optic white create
  a cleaner visual temperature.

- Mixed-temperature outfits are allowed when intentional; the system
  should not enforce simplistic warm-with-warm rules.

- Near-neutrals such as olive, denim blue, burgundy and muted teal can
  function as flexible anchors.

- When image lighting makes undertone uncertain, present alternatives
  rather than pretending precision.

# 6. Neutral Architecture

| **Neutral**     | **Typical role**           | **Strong companions**                          |
|-----------------|----------------------------|------------------------------------------------|
| Navy            | Primary tailored anchor    | White, blue, grey, stone, brown, muted earths  |
| Charcoal        | Formal/city anchor         | White, pale blue, black, burgundy accents      |
| Mid grey        | Versatile bridge           | Navy, blue, white, black, brown, muted colors  |
| Black           | High contrast/evening      | White, grey, black tonal, selected deep colors |
| Cream / ecru    | Soft luxury anchor         | Navy, brown, olive, blue, tobacco              |
| Stone / beige   | Warm-weather neutral       | White, blue, navy, olive, brown                |
| Brown / tobacco | Textural heritage anchor   | Cream, blue, denim, olive, warm neutrals       |
| Olive           | Near-neutral casual anchor | Cream, white, brown, navy, light blue          |

# 7. Pattern Taxonomy

| **Pattern family**    | **Examples**                                         | **Key variables**                        |
|-----------------------|------------------------------------------------------|------------------------------------------|
| Solid                 | Plain, melange, heathered                            | Surface variation                        |
| Stripe                | Pinstripe, Bengal, awning, chalk, candy              | Width, spacing, direction, contrast      |
| Check                 | Gingham, windowpane, tattersall, glen/plaid families | Scale, density, contrast                 |
| Herringbone / chevron | Tailoring and textured shirting                      | Scale and visibility                     |
| Houndstooth           | Micro to bold                                        | Scale and contrast                       |
| Dots / micro motifs   | Pin dot, geometric microprint                        | Density and formality                    |
| Floral / botanical    | Printed or woven                                     | Scale, color count, realism              |
| Paisley / ornamental  | Printed/woven motifs                                 | Density and cultural/formality context   |
| Abstract / geometric  | Contemporary prints                                  | Scale, rhythm, palette                   |
| Textural pattern      | Slub, dobby, jacquard-like surface                   | Whether pattern is structural or printed |

# 8. Pattern Scale & Mixing Rules

- Store pattern scale numerically where possible: micro, small, medium,
  large, oversized.

- When mixing the same pattern family, separate the scales clearly—for
  example, a narrow stripe with a much broader stripe.

- When mixing different pattern families, maintain a shared color
  relationship or hierarchy.

- One pattern should normally dominate; supporting patterns should not
  compete at equal visual strength.

- High-formality contexts reduce tolerance for large, loud or numerous
  patterns.

- Pattern density must be considered separately from pattern scale.

- The visualization engine must preserve pattern scale relative to the
  body; it must not stretch a fabric motif unrealistically.

# 9. Texture & Surface Pairing

| **Surface**   | **Pairs well with**                     | **Watch for**                                  |
|---------------|-----------------------------------------|------------------------------------------------|
| Crisp/smooth  | Fine wool, poplin, polished tailoring   | Too many smooth pieces can feel corporate/flat |
| Dry/natural   | Linen, hopsack, matte cotton, suede     | Can become overly rustic without refinement    |
| Brushed/soft  | Flannel, cashmere-like surfaces, suede  | Climate and seasonal heaviness                 |
| Slubby        | Linen and artisanal casual fabrics      | Formal context may require cleaner companions  |
| Lustrous      | Silk-like, satin accents, polished wool | Use controlled quantities                      |
| Corded/ribbed | Corduroy, rib textures                  | Visual weight and season                       |
| Open weave    | Summer tailoring                        | Opacity and structural limitations             |

# 10. Material Compatibility Logic

| **Anchor material**     | **Strong directions**                                   | **Context notes**                                 |
|-------------------------|---------------------------------------------------------|---------------------------------------------------|
| Linen                   | Cotton, linen, tropical wool, suede/leather accents     | Excellent warm-weather and relaxed tailoring base |
| Cotton shirting         | Wool, linen, cotton trousers, denim depending formality | Highly versatile                                  |
| Fine wool               | Dress cotton, fine knit, silk accents, refined leather  | Business/formal strength                          |
| Flannel                 | Oxford, twill, knitwear, suede/leather                  | Cool-weather, softer tailoring                    |
| Denim                   | Oxford, linen, cotton, knitwear, casual suede/leather   | Keep formality coherent                           |
| Corduroy                | Oxford, denim, wool, knitwear                           | Texture-rich; avoid excessive competing texture   |
| Velvet                  | Fine shirting and restrained companions                 | Evening/statement; should usually dominate        |
| Silk / silk-like accent | Fine wool, refined cotton, formal tailoring             | Control sheen                                     |

# 11. Fabric Weight & Drape Compatibility

Pieces do not need identical weight, but they should form a believable
hierarchy. A very airy shirt can work under a structured jacket;
however, a heavy winter trouser with an extremely tropical top may look
seasonally incoherent unless the context explains it.

| **Factor**        | **Rule**                                                                     |
|-------------------|------------------------------------------------------------------------------|
| Weight            | Check seasonal and visual balance across layers                              |
| Drape             | Soft anchor fabrics favor silhouettes that allow movement                    |
| Structure         | Structured jackets need compatible trouser/shirt visual discipline           |
| Thickness         | Prevent bulky layer combinations                                             |
| Opacity           | Account for underlayers and shirt transparency                               |
| Wrinkle character | Natural wrinkles can be intentional; mixed levels should still look coherent |

# 12. Garment-to-Garment Pairing Logic

| **Anchor**                | **AI evaluates**                                                          |
|---------------------------|---------------------------------------------------------------------------|
| Shirt → trousers          | Color/value, pattern, texture, formality, tuck/untucked silhouette        |
| Trousers → shirt          | Contrast, trouser rise/volume, occasion, footwear bridge                  |
| Jacket → shirt            | Lapel/structure, shirt collar, color, pattern scale, texture              |
| Jacket → trousers         | Suit vs separates logic, value separation, texture and season             |
| Suit → shirt              | Formality, collar, pattern, color temperature                             |
| Full outfit → shoes       | Formality, trouser hem, palette, venue and time                           |
| Full outfit → accessories | Accent hierarchy; accessories should complete rather than rescue the look |

# 13. Outfit Visual Hierarchy

- Determine the hero: uploaded fabric, jacket, suit, shirt, or statement
  accessory.

- Give the hero the highest visual priority; reduce competition
  elsewhere.

- Use supporting pieces to create frame, contrast and continuity.

- A premium outfit may be memorable because of proportion and
  material—not because every component is distinctive.

- Default to one primary statement, with a second only when the
  aesthetic explicitly supports more complexity.

# 14. Shirt–Trouser–Jacket Coordination Examples

| **Anchor**            | **Direction A**                      | **Direction B**                    | **Direction C**                    |
|-----------------------|--------------------------------------|------------------------------------|------------------------------------|
| Pale blue linen shirt | Stone tailored trouser               | Cream trouser                      | Tobacco/brown trouser              |
| Navy jacket           | Grey trouser + pale blue/white shirt | Stone trouser + white/ecru shirt   | Tonal navy with controlled texture |
| Cream jacket          | Navy trouser + light shirt           | Brown/tobacco trouser + blue shirt | Tonal ecru/stone resort direction  |
| Olive trouser         | White/ecru shirt                     | Light blue shirt                   | Muted stripe with controlled scale |
| Charcoal suit         | White shirt                          | Pale blue shirt                    | Subtle stripe if occasion permits  |

These are seed directions, not fixed rules. Context and the exact fabric
attributes must override generic pairing tables.

# 15. Footwear Integration

| **Footwear family**       | **Typical compatibility**                                    |
|---------------------------|--------------------------------------------------------------|
| Black dress shoe          | Formal charcoal/black/navy contexts; high polish             |
| Dark brown leather        | Navy, grey, brown and many business/semi-formal outfits      |
| Tan/cognac leather        | Lighter warm palettes and less formal tailoring              |
| Suede loafer              | Linen, resort, soft tailoring, textured separates            |
| Minimal sneaker           | Contemporary casual/elevated casual where dress code permits |
| Sandals / resort footwear | Only venue-appropriate relaxed contexts                      |

Footwear color should be evaluated with both trousers and belt/accessory
strategy; rigid same-color matching is not always necessary.

# 16. Accessory Color Logic

- Pocket square: complement the outfit; do not simply duplicate the tie.

- Tie: evaluate shirt pattern scale, jacket pattern, formality and
  lighting.

- Belt: coordinate with footwear/material family when appropriate, but
  allow modern tonal variation.

- Watch/metal: treat metal tone as a subtle temperature/accent input,
  not a dominant rule.

- Socks: choose continuity, controlled contrast or intentional accent
  according to formality.

- Avoid adding accessories merely to increase visual complexity.

# 17. Context-Adaptive Pairing

| **Context**    | **Pairing bias**                                                     |
|----------------|----------------------------------------------------------------------|
| Boardroom      | Lower pattern noise, controlled contrast, refined materials          |
| Summer wedding | Breathable materials, celebratory color, elegant lightness           |
| Beach/resort   | Natural texture, lighter palette, soft contrast, relaxed footwear    |
| Evening dinner | Deeper values, richer texture, sharper contrast possible             |
| Festive event  | More color/texture permitted; cultural context matters               |
| Travel         | Versatile neutrals, repeatable combinations, wrinkle-aware materials |
| Creative event | Higher novelty and pattern freedom while maintaining hierarchy       |

# 18. Safe / Elevated / Statement Recommendation Modes

| **Mode**  | **Behavior**                                                         |
|-----------|----------------------------------------------------------------------|
| Safe      | Highly compatible, familiar, low styling risk                        |
| Elevated  | More nuanced color/texture relationship; premium default             |
| Statement | Distinctive contrast, pattern or silhouette while remaining coherent |

The AI should ideally offer all three when appropriate. This gives the
customer choice without forcing them to understand technical color
theory.

# 19. Compatibility Scoring

| **Component**                 | **Example weight logic**                 |
|-------------------------------|------------------------------------------|
| Context compatibility         | High                                     |
| Color harmony                 | High                                     |
| Value/contrast balance        | High                                     |
| Material/season compatibility | High                                     |
| Pattern compatibility         | Medium–high when patterns exist          |
| Texture balance               | Medium                                   |
| Formality consistency         | High                                     |
| Aesthetic alignment           | High                                     |
| Novelty                       | Variable; never override appropriateness |
| Wardrobe usability            | Medium for purchase recommendations      |

Weights are dynamic. A black-tie-adjacent event raises formality weight;
a resort look raises climate, texture and relaxed-material
compatibility.

# 20. Pairing Conflict Rules

| **Conflict**                                     | **Resolution**                                                           |
|--------------------------------------------------|--------------------------------------------------------------------------|
| Two loud patterns                                | Reduce one pattern's scale/contrast or replace with solid                |
| Strong color + strong pattern                    | Make one the hero and mute supporting pieces                             |
| Very textured jacket + textured trouser          | Introduce a cleaner bridge piece or reduce one texture                   |
| Formal garment + casual footwear                 | Only allow if aesthetic/context intentionally supports high-low dressing |
| Warm earthy palette + stark cool white           | Test intentional contrast; often soften to ecru/cream                    |
| Uploaded fabric clashes with requested companion | Explain conflict and offer nearest successful alternative                |
| Reference look uses unavailable exact color      | Match relationship—value, temperature, contrast—not merely nearest RGB   |

# 21. Fabric Upload → Complete Outfit Algorithm

- 1\. Analyze uploaded fabric: likely family, color, undertone, pattern,
  texture, drape and confidence.

- 2\. Read context package: occasion, venue, climate, time, formality
  and aesthetic.

- 3\. Decide the fabric's garment role and whether it should be the
  visual hero.

- 4\. Generate candidate palettes using color/value/temperature
  relationships.

- 5\. Filter candidates by material, season, formality and pattern
  compatibility.

- 6\. Build full garment combinations using the Garment Design System.

- 7\. Add footwear/accessories only after the core garments are
  coherent.

- 8\. Score and diversify candidates into Safe, Elevated and Statement
  directions.

- 9\. Explain the top directions and expose controlled refinements.

- 10\. Pass the selected specification—not a vague text prompt—to
  visualization.

# 22. AI Color Extraction From Photos

- Estimate dominant, secondary and accent colors rather than a single
  average color.

- Detect highlights/shadows separately so folds do not become false
  color categories.

- Use perceptual clustering and report confidence.

- Allow the customer to tap/confirm the real fabric color when the photo
  is unreliable.

- Future premium capture flow can include a neutral reference/card or
  guided lighting instructions.

- Never claim exact colorimetry from an uncontrolled phone photograph.

# 23. Pattern Recognition From Fabric Photos

- Detect pattern family, repeat direction, approximate repeat size,
  dominant colors and contrast.

- Separate woven texture from printed motif where confidence permits.

- Estimate motif scale only when the image contains a usable
  physical/body reference.

- Store the original fabric image for visualization so the generated
  garment can preserve actual motif identity.

- Flag uncertain classifications for user correction rather than forcing
  a label.

# 24. Visualization Preservation Rules

- Preserve the uploaded fabric's recognizable color relationship,
  texture and motif.

- Map pattern according to garment panels, seams and orientation.

- Do not enlarge or shrink motifs arbitrarily to make the image
  aesthetically easier.

- Respect plausible fabric drape and thickness.

- Keep lighting changes from materially changing the perceived fabric
  color.

- Generate consistent front, side, back and detail views from the same
  design specification when catalogue visualization is requested.

# 25. Developer Data Model

{  
"anchor_fabric_id": "FAB-...",  
"observed_color": {  
"family": "blue",  
"value": "light",  
"saturation": "muted",  
"undertone": "cool_neutral",  
"confidence": 0.82  
},  
"pattern": {  
"family": "solid",  
"scale": null,  
"contrast": "low"  
},  
"surface": \["matte", "natural", "slub"\],  
"pairing_request": {  
"garment_role": "shirt",  
"mode": "elevated"  
},  
"candidate": {  
"trouser": {"color_family": "stone", "material_family":
"cotton_linen"},  
"jacket": null,  
"footwear": {"family": "suede_loafer", "color_family": "brown"}  
},  
"scores": {  
"context": 0.94,  
"color": 0.91,  
"material": 0.90,  
"formality": 0.93,  
"aesthetic": 0.95  
},  
"rationale": \[\],  
"warnings": \[\]  
}

# 26. Pairing Knowledge Graph

Do not store the system as a giant list of fixed outfits. Represent
relationships between colors, fabrics, patterns, garment roles,
aesthetics and contexts. Edges should carry compatibility strength,
conditions, exceptions, evidence/source and version. This allows the
system to construct new combinations instead of retrieving only
memorized looks.

# 27. Training / Reference Data Strategy

- Separate owned, licensed, public-domain and external-reference assets.

- Do not assume arbitrary web imagery is licensed for model training or
  commercial reuse.

- Use external references for research/retrieval only where rights
  permit; build the core visual dataset from controlled or licensed
  sources.

- Annotate reference outfits at attribute level: garment, color,
  pattern, texture, formality, context and aesthetic.

- Capture negative examples and the reason they fail; these are valuable
  for ranking and quality control.

# 28. Quality-Control Tests

| **Test**           | **Pass condition**                                             |
|--------------------|----------------------------------------------------------------|
| Color consistency  | Recommendation uses intended color relationships across views  |
| Pattern scale      | Motif size remains physically plausible                        |
| Context fit        | Outfit satisfies event/venue constraints                       |
| Material coherence | Layer weights and seasonal logic make sense                    |
| Hierarchy          | One clear visual focus unless intentionally editorial          |
| Formality          | Shoes/accessories do not accidentally downgrade/overdress look |
| Diversity          | Safe/Elevated/Statement outputs are materially different       |
| Explainability     | Every major recommendation can state why it works              |

# 29. Connection to the Fashion Brain

Inputs: Garment Design System + Fabric Intelligence +
Occasion/Destination/Context System. Outputs: ranked
color/material/pattern combinations that can be consumed by
Style/Aesthetic Intelligence and the AI Designer Decision Engine.

# 30. Next Specification

Next: Style & Aesthetic Intelligence System. It will turn broad labels
such as quiet luxury, Italian tailoring, modern classic, resort luxury,
contemporary Indian, heritage and editorial into explicit rules for
silhouette, proportions, garment details, colors, textures, styling and
controlled trend adoption.
