**LLINEN EARTH**

**Occasion, Destination & Aesthetic Intelligence System**

*Fashion Brain Specification — v1.0*

A structured decision system that teaches the LLinen Earth AI Designer
to understand not only what a customer is wearing, but where, when, why,
and how the finished look should feel.

**Core decision equation**

**FABRIC + PERSON + OCCASION + DESTINATION + TIME + CLIMATE +
FORMALITY + AESTHETIC + PREFERENCE → DESIGN DIRECTION**

# 1. Purpose

This system is the context layer between fabric intelligence and the
future AI Designer. Its job is to prevent generic recommendations. Two
customers can upload the same linen, yet require completely different
designs because one is attending a beach wedding at sunset and the other
is dressing for a humid weekday office.

- Translate real-world context into design constraints and
  opportunities.

- Rank outfit directions instead of producing one arbitrary answer.

- Explain why a recommendation works for the specific setting.

- Control formality, silhouette, layering, color intensity, texture and
  styling.

- Preserve premium LLinen Earth taste while allowing multiple
  aesthetics.

# 2. Context Intake Model

The AI should ask progressively, not present a long form. Ask only
questions that materially change the recommendation.

| **Dimension**       | **Examples**                                                    | **Why it matters**                        |
|---------------------|-----------------------------------------------------------------|-------------------------------------------|
| Purpose             | Buy fabric, design garment, complete outfit, redesign reference | Defines output scope                      |
| Occasion            | Office, wedding, dinner, festive event, travel, casual          | Controls dress expectations               |
| Destination / venue | Beach, lawn, hotel, restaurant, office, yacht, city             | Controls practicality and visual language |
| Time                | Morning, daytime, sunset, evening, late night                   | Changes palette, sheen and layering       |
| Environment         | Indoor, outdoor, mixed                                          | Changes breathability and structure       |
| Climate             | Hot-humid, hot-dry, mild, cool, cold                            | Controls fabric/lining/layers             |
| Dress code          | Relaxed to ceremonial                                           | Controls tailoring/formality              |
| Desired impression  | Elegant, powerful, relaxed, youthful, creative                  | Controls styling personality              |
| Fit preference      | Relaxed, regular, tailored, slim                                | Controls silhouette                       |
| Cultural preference | Western, Indian, Indo-western, flexible                         | Controls garment vocabulary               |
| Existing pieces     | Shoes, trousers, jacket, accessories                            | Allows wardrobe compatibility             |
| Comfort priorities  | Breathability, movement, wrinkle tolerance                      | Prevents impractical designs              |

# 3. Occasion Taxonomy

| **Occasion family** | **Typical sub-contexts**                              | **Default design direction**                        |
|---------------------|-------------------------------------------------------|-----------------------------------------------------|
| Business            | Daily office, client meeting, boardroom, conference   | Controlled, credible, low-noise                     |
| Business social     | Networking, business dinner, launch                   | Polished with more personality                      |
| Wedding             | Guest, family, reception, destination wedding         | Celebratory; venue and role dependent               |
| Festive / cultural  | Diwali, Ganesh festival, family celebration           | Rich texture/color with cultural sensitivity        |
| Formal evening      | Black-tie adjacent, gala, luxury dinner               | Sharper silhouette, deeper palette, refined surface |
| Social evening      | Dinner, party, rooftop, lounge                        | More expressive and relaxed than formal evening     |
| Resort / leisure    | Resort, beach club, poolside, holiday                 | Airy, tactile, relaxed luxury                       |
| Travel              | Airport, road trip, sightseeing, business travel      | Comfort, recovery, versatility                      |
| Casual              | Weekend, cafe, shopping, day out                      | Effortless but intentional                          |
| Date / intimate     | Lunch date, dinner date, celebration                  | Approachable, flattering, polished                  |
| Creative / fashion  | Fashion event, shoot, art event                       | Higher novelty and styling freedom                  |
| Ceremonial          | Religious, institutional, high-formality family event | Respectful, restrained, context-first               |

# 4. Destination & Venue Taxonomy

| **Venue**               | **Design implications**                                                              |
|-------------------------|--------------------------------------------------------------------------------------|
| Beach / coast           | Breathability, lighter structure, wind-aware hems, natural texture, lighter footwear |
| Pool / beach club       | Relaxed luxury; avoid business stiffness; easy layering                              |
| Lawn / garden           | Movement, daylight-friendly color, practical hem/footwear                            |
| Luxury hotel            | Refinement can increase; polished tailoring and elevated texture work well           |
| Restaurant              | Consider lighting, seating comfort, temperature and formality                        |
| Yacht / marina          | Wind, movement, non-fussy layers, nautical restraint rather than costume             |
| Urban city              | Sharper styling; adapt to walking, transport and local climate                       |
| Office / boardroom      | Credibility, controlled contrast, repeatability, low distraction                     |
| Airport / travel        | Comfort, wrinkle management, pockets, layering                                       |
| Desert / hot-dry        | Sun protection, breathable construction, light-to-mid palette                        |
| Mountain / hill station | Layering, thermal comfort, texture and footwear integration                          |

# 5. Time-of-Day Engine

| **Time**       | **Typical adjustment**                                         |
|----------------|----------------------------------------------------------------|
| Morning        | Fresh, lower visual heaviness, breathable layering             |
| Daytime        | Natural-light performance; avoid unnecessary sheen             |
| Late afternoon | Can introduce richer tones and stronger contrast               |
| Sunset         | Warm, tactile, photogenic palettes; transition-ready layers    |
| Evening        | Deeper colors, sharper contrast, richer texture                |
| Late night     | More dramatic palette/finish permitted if occasion supports it |

# 6. Indoor / Outdoor Logic

- Outdoor recommendations prioritize climate, movement, sunlight, wind
  and practical footwear.

- Indoor recommendations can tolerate more structure and layering, but
  air-conditioning should be considered.

- Mixed environments require removable layers and a base outfit that
  still looks complete without the jacket.

- Never use venue prestige as an excuse to ignore physical comfort.

# 7. Formality Scale

| **Level** | **Meaning**                 | **Typical output**                                   |
|-----------|-----------------------------|------------------------------------------------------|
| F0        | Ultra-relaxed               | Resort separates, casual linen, drawstring tailoring |
| F1        | Smart casual                | Structured casual shirt/trouser combinations         |
| F2        | Elevated casual             | Premium separates, loafers, refined texture          |
| F3        | Business / semi-formal      | Tailored trousers, dress shirt, optional jacket      |
| F4        | Formal                      | Suiting, disciplined shirt/collar/shoe choices       |
| F5        | Ceremonial / evening formal | Highest restraint, finish and dress-code compliance  |

# 8. Aesthetic Vocabulary

| **Aesthetic**       | **Design language**                                                        |
|---------------------|----------------------------------------------------------------------------|
| Quiet luxury        | Excellent material, subtle palette, precise fit, minimal visible novelty   |
| Modern classic      | Traditional menswear grammar with cleaner contemporary proportions         |
| Italian-inspired    | Soft tailoring, ease, elegant drape, expressive but controlled color       |
| British-inspired    | Sharper structure, stronger tailoring language, heritage influence         |
| Resort luxury       | Breathable materials, relaxed silhouettes, tactile sophistication          |
| Contemporary Indian | Indian context and proportion interpreted with modern restraint            |
| Minimal             | Reduced details, disciplined palette, clean silhouette                     |
| Heritage            | Classic patterns, textures and traditional menswear references             |
| Bold luxury         | Controlled statement color, pattern or silhouette with premium execution   |
| Editorial           | High-concept, directional, visually distinctive; lower everyday constraint |
| Artisanal           | Texture, craft, natural irregularity and material story are central        |

# 9. Desired Impression Mapping

| **Desired impression** | **AI translation**                                                   |
|------------------------|----------------------------------------------------------------------|
| Elegant                | Balanced proportions, restrained palette, refined finishing          |
| Powerful               | Sharper lines, stronger shoulders/contrast, disciplined accessories  |
| Relaxed                | Softer construction, easier silhouette, tactile fabric               |
| Youthful               | Contemporary proportions, lighter styling, controlled trend adoption |
| Mature / refined       | Timeless proportions, nuanced color, quality-first detailing         |
| Creative               | Unexpected but coherent combinations, distinctive detail             |
| Approachable           | Softer contrast, comfortable fit, less severe structure              |

# 10. Destination-Specific Intelligence Examples

| **Context**            | **Recommended bias**                                                                       |
|------------------------|--------------------------------------------------------------------------------------------|
| Goa / tropical resort  | Linen and breathable blends, open texture, relaxed tailoring, light/earth/coastal palette  |
| Mumbai / humid city    | Breathability, reduced lining, sweat-aware color choices, practical layering               |
| Rajasthan / dry heat   | Sun-aware palette, breathable coverage, natural fibers, texture without excessive layering |
| Hill station           | Layering, flannel/wool/knit compatibility, richer texture                                  |
| Luxury hotel event     | Higher polish, tailored silhouette, refined shoes/accessories                              |
| Beach wedding          | Celebratory but breathable; soft tailoring, elegant light/mid tones, venue-safe footwear   |
| European summer travel | Versatile separates, linen/cotton, walkability, repeatable capsule logic                   |

# 11. Context Conflict Rules

The AI must resolve conflicts explicitly instead of blindly obeying one
signal.

| **Conflict**                          | **Resolution rule**                                                                  |
|---------------------------------------|--------------------------------------------------------------------------------------|
| Hot climate + formal event            | Retain formal silhouette; reduce weight/lining and choose breathable construction    |
| Beach + high formality                | Use refined soft tailoring rather than casual beachwear or rigid city suiting        |
| Heavy fabric + hot destination        | Warn user; propose alternate garment/use or reduce layering                          |
| Bold fabric + conservative event      | Simplify silhouette and supporting colors                                            |
| Relaxed fabric + boardroom            | Increase structure through garment choice and styling, or recommend another fabric   |
| Trend request + poor body/context fit | Offer trend-inspired adaptation rather than literal copying                          |
| Reference image + unsuitable fabric   | Preserve design intent while modifying construction/proportion for the actual fabric |

# 12. Context Scoring Model

Each proposed look receives normalized scores. Weights change by
scenario; for example, climate fit carries more weight for an outdoor
tropical event than an air-conditioned evening dinner.

| **Score**        | **Question**                                                   |
|------------------|----------------------------------------------------------------|
| Fabric fit       | Does the design exploit the uploaded fabric correctly?         |
| Climate fit      | Will it function in expected temperature/humidity?             |
| Occasion fit     | Is it socially appropriate?                                    |
| Venue fit        | Does it make sense physically and visually at the destination? |
| Time fit         | Does palette/finish suit the time of day?                      |
| Aesthetic fit    | Does it match the requested style language?                    |
| Personal fit     | Does it respect fit, comfort and cultural preferences?         |
| Compatibility    | Does the full outfit work together?                            |
| Novelty          | Is it distinctive without becoming costume-like?               |
| LLinen Earth fit | Does it meet the brand's premium design standard?              |

# 13. Recommendation Behavior

- Apply hard constraints first: dress code, climate extremes, cultural
  restrictions and fabric limitations.

- Apply user preferences second: fit, desired impression, aesthetic and
  existing wardrobe.

- Generate 3–5 genuinely different design directions, not superficial
  color variants.

- Rank directions using context scores and explain the top
  recommendation in concise designer language.

- Allow controlled refinement: more formal, more relaxed, younger,
  quieter, bolder, cooler, more traditional, etc.

- Only then send a selected concept to visualization.

# 14. Progressive Questioning

The interface should begin with information already available from the
uploaded fabric and user action. It should then ask the smallest number
of high-information questions. Example: if the user says 'beach wedding
in Goa at sunset,' the system should not separately ask whether the
event is outdoor unless uncertainty remains.

- Stage 1: What are we designing and for what event?

- Stage 2: Where and when will it be worn?

- Stage 3: What level of formality or dress code applies?

- Stage 4: What should the wearer feel/look like?

- Stage 5: Ask fit, comfort or wardrobe questions only if they affect
  ranking.

# 15. Example Designer Flow

Input: customer uploads a pale blue medium-light linen. Context:
destination wedding, Goa, sunset ceremony, outdoor lawn near the coast,
elevated but not black tie, wants quiet luxury.

- Fabric engine identifies linen-like visual cues and estimates
  light-to-medium structure, while marking unverified technical
  properties as uncertain.

- Context engine prioritizes humidity, outdoor movement, sunset light,
  wedding-level polish and quiet-luxury restraint.

- Designer engine proposes soft tailoring rather than rigid business
  suiting.

- Top direction might pair a softly constructed jacket or refined shirt
  with tailored trousers in a compatible neutral, avoiding excessive
  sheen and heavy lining.

- The explanation states why each choice suits the fabric, venue,
  climate and desired impression.

- Visualization is generated only after the user selects/refines the
  direction.

# 16. Reusable Context Profiles

Users may save non-sensitive style/context preferences such as preferred
fit, typical formality, favorite aesthetics, wrinkle tolerance and
common climate. Event-specific context should remain separate so a
one-time wedding does not permanently distort future recommendations.

# 17. Aesthetic Combination Rules

- Allow compatible blends such as quiet luxury + resort, modern
  classic + Italian-inspired, or contemporary Indian + artisanal.

- Avoid stacking too many aesthetics; default maximum is two primary
  aesthetics plus one subtle influence.

- When aesthetics conflict, identify a dominant aesthetic and use the
  second only as an accent.

- Never interpret 'luxury' as automatic shine, logos, ornamentation or
  excessive detail.

- Never interpret 'minimal' as generic; proportion, material and
  construction must carry the design.

# 18. Developer-Ready Context Object

{  
"occasion": {"family": "wedding", "role": "guest", "formality": 3},  
"destination": {"type": "coastal_lawn", "region": "Goa"},  
"time": {"period": "sunset"},  
"environment": {"indoor_outdoor": "outdoor"},  
"climate": {"profile": "hot_humid"},  
"aesthetic": {"primary": "quiet_luxury", "secondary":
"resort_luxury"},  
"desired_impression": \["elegant", "relaxed"\],  
"fit_preference": "tailored_relaxed",  
"cultural_mode": "western",  
"comfort_priorities": \["breathability", "movement"\],  
"hard_constraints": \[\],  
"existing_items": \[\],  
"confidence": {},  
"source": {}  
}

# 19. Decision Output Contract

| **Output field**       | **Required content**                                    |
|------------------------|---------------------------------------------------------|
| Context summary        | One concise interpretation of the event and environment |
| Hard constraints       | Non-negotiable rules                                    |
| Design directions      | 3–5 materially distinct options                         |
| Rank / confidence      | Context-based score and uncertainty                     |
| Garment specification  | Garment IDs + compositional attributes                  |
| Color/material pairing | Recommended supporting pieces                           |
| Why it works           | Designer rationale                                      |
| Risks / cautions       | Climate, fabric, dress-code or styling conflicts        |
| Visualization brief    | Structured prompt passed to image system                |

# 20. Quality & Safety Rules for Fashion Recommendations

- Do not pretend a fabric property is known when it cannot be reliably
  inferred from an image.

- Do not force a named trend where timeless tailoring is more
  appropriate.

- Do not copy a designer look exactly when a reference is supplied;
  extract design attributes and create an original interpretation.

- Treat cultural and ceremonial dress codes as context requiring
  respect, not as visual costumes.

- Keep recommendations explainable and editable by the user.

- Maintain consistent terminology and stable IDs so recommendations can
  be reproduced by developers and downstream AI systems.

# 21. Connection to the Full LLinen Earth Fashion Brain

This document receives structured fabric information from the Fabric
Intelligence System and garment vocabulary from the Garment Design
System. Its output becomes a context package for the next layers:
Color/Pattern/Material Pairing, Style/Aesthetic Intelligence, the AI
Designer Decision Engine, and finally the visualization system.

# 22. Next Specification

Next: Color, Pattern & Material Pairing System. This will define color
harmony, undertones, contrast, pattern scale, texture compatibility,
shirt–trouser–jacket coordination, footwear/accessory integration, and
rules for turning one uploaded fabric into a complete premium outfit.
