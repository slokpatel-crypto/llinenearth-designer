**LLINEN EARTH**

**FABRIC INTELLIGENCE SYSTEM**

Master Specification v1.0 — Foundation for the future Fabric → Designer
AI

**FIBER • CONSTRUCTION • WEIGHT • DRAPE • TEXTURE • COLOR • CLIMATE •
OCCASION • DESIGN SUITABILITY**

# 1. Purpose

This document defines how LLinen Earth should understand fabric before
recommending or generating a garment. The goal is to move from a simple
image-recognition system (“this is blue linen”) to a design-intelligence
system (“this is a lightweight, matte, visibly slubbed linen with soft
drape that is highly suitable for relaxed resort shirts, summer trousers
and selected unstructured jackets”).

The system must separate what can be visually observed from what must be
confirmed by the user, supplier or physical test. AI should use
confidence levels and should never pretend that a photograph can
reliably reveal every technical property.

## 2. Fabric intelligence philosophy

- Fabric is not only fiber. Two linen fabrics can behave very
  differently because of weave, weight, finishing and yarn construction.

- Color alone must never determine garment design.

- Drape, weight and surface are among the most important
  visual-to-design bridges.

- Use AI vision for estimates; use user/supplier inputs for technical
  facts when accuracy matters.

- Store uncertainty explicitly: high / medium / low confidence.

- Fabric suitability should be scored against the intended garment and
  context, not declared universally.

# 3. Fabric data model

| **Layer**         | **Attributes**                                            | **Examples**                        |
|-------------------|-----------------------------------------------------------|-------------------------------------|
| Fiber             | Primary fiber, secondary fiber, blend ratio if known      | 100% linen; linen/cotton; wool/silk |
| Yarn              | Yarn size/type, twist, count if known                     | Fine, medium, coarse; high twist    |
| Weave             | Plain, twill, satin, basket, dobby, jacquard etc.         | Plain weave                         |
| Weight            | GSM or estimated light/medium/heavy                       | 120 GSM / lightweight               |
| Structure         | Density, openness, compactness                            | Open airy weave                     |
| Drape             | Crisp, moderate, soft, fluid, structured                  | Soft/moderate                       |
| Hand              | Dry, crisp, smooth, soft, brushed, cool                   | Dry/cool hand                       |
| Surface           | Slub, nubby, smooth, brushed, raised, textured            | Visible slub                        |
| Sheen             | Matte, low, medium, high                                  | Matte                               |
| Stretch           | None, mechanical, elastane                                | None                                |
| Opacity           | Opaque, semi-sheer, sheer                                 | Semi-sheer                          |
| Wrinkle           | Low, moderate, high                                       | High                                |
| Recovery          | Low, medium, high                                         | Medium                              |
| Breathability     | Low, medium, high                                         | High                                |
| Insulation        | Low, medium, high                                         | Low                                 |
| Moisture behavior | Absorption/wicking estimate if known                      | Absorbent                           |
| Finish            | Washed, mercerized, brushed, coated etc.                  | Garment-washed                      |
| Pattern           | Solid, stripe, check, plaid, jacquard etc.                | Micro-check                         |
| Color             | Name, digital approximation, undertone, value, saturation | Warm ivory                          |
| Transparency      | Visual estimate                                           | Low                                 |
| Care              | Machine, hand, dry clean, unknown                         | Dry clean                           |
| Origin/source     | Supplier, collection, reference                           | LLinen Earth supplier               |
| Rights            | Owned/licensed/reference                                  | Owned                               |
| Confidence        | High/medium/low                                           | Medium                              |

# 4. Visual analysis from a fabric photograph

The first AI pass should produce an analysis report, not immediately
generate an outfit.

| **Vision output** | **How it should be described**           | **Reliability from photo**          |
|-------------------|------------------------------------------|-------------------------------------|
| Color             | Dominant color + undertone + variation   | High if lighting is neutral         |
| Pattern           | Solid/stripe/check/etc. and repeat scale | High–medium                         |
| Texture           | Smooth/slub/nubby/brushed/raised         | Medium                              |
| Surface sheen     | Matte/low/high                           | Medium                              |
| Weave openness    | Open/compact visual structure            | Medium                              |
| Drape clue        | Soft/crisp/heavy/light based on folds    | Low–medium                          |
| Weight            | Light/medium/heavy estimate              | Low unless scale/reference provided |
| Stretch           | Only infer if visual evidence exists     | Low                                 |
| Fiber             | Probable family only                     | Low–medium                          |
| Exact composition | Do not claim from photo alone            | Low                                 |

# 5. Required upload experience

1.  Ask the user to upload the best available fabric photo.

2.  If possible, ask for a second photo under neutral daylight.

3.  Ask for a close-up showing weave/texture.

4.  Optional: ask for fabric width, GSM, composition, supplier
    description and intended use.

5.  Show the AI analysis with confidence labels.

6.  Let the user correct any property.

7.  Lock corrected properties into the design brief.

8.  Only then move to garment recommendations.

# 6. Fabric family catalogue

| **Family**      | **Identity**                                                    | **LLinen Earth relevance**                                |
|-----------------|-----------------------------------------------------------------|-----------------------------------------------------------|
| Linen           | Flax fiber; breathable, textured, often high wrinkle character. | Shirts, trousers, resort tailoring, unstructured jackets. |
| Cotton          | Broad family; behavior varies strongly by weave and finish.     | Shirts, chinos, casual jackets, trousers.                 |
| Wool            | Tailoring family with wide range of weights and finishes.       | Suits, trousers, blazers, coats.                          |
| Silk            | Smooth/lustrous to textured depending on construction.          | Evening, luxury shirts, accents, blends.                  |
| Cashmere        | Soft luxury animal fiber; warmth and softness.                  | Winter knitwear and luxury layers.                        |
| Mohair          | Crisp, lustrous, resilient tailoring fiber.                     | Summer tailoring, evening/statement suiting.              |
| Alpaca          | Warm, soft, often used in blends.                               | Cold-weather tailoring/layers.                            |
| Hemp            | Bast fiber with natural texture; often blended.                 | Casual/resort garments.                                   |
| Ramie           | Bast fiber with crisp, lustrous character.                      | Summer shirts/blends.                                     |
| Tencel/Lyocell  | Cellulosic fiber with soft drape.                               | Relaxed shirts, trousers, contemporary garments.          |
| Viscose/Rayon   | Soft drape; performance depends on construction.                | Fluid shirts/trousers, blends.                            |
| Polyester       | Synthetic family; properties depend on yarn/weave/finish.       | Performance, travel, blends; evaluate context.            |
| Nylon/Polyamide | Strong, lightweight synthetic family.                           | Technical/outdoor/travel applications.                    |
| Denim           | Fabric category typically cotton twill; weight and wash vary.   | Jeans, shirts, jackets.                                   |
| Velvet          | Pile fabric with directional surface.                           | Evening, jackets, statement pieces.                       |
| Corduroy        | Cut-pile wale texture.                                          | Trousers, jackets, overshirts.                            |
| Seersucker      | Typically puckered construction; airy summer character.         | Summer shirts and suits.                                  |
| Flannel         | Brushed/warm fabric family, commonly cotton or wool.            | Shirts, trousers, winter tailoring.                       |

# 7. Weave and construction library

| **Construction** | **Visual/physical tendency**                     | **Typical design implications**                    |
|------------------|--------------------------------------------------|----------------------------------------------------|
| Plain weave      | Stable, simple, can be crisp or soft.            | Shirts, lightweight tailoring, dresses; broad use. |
| Basket weave     | More open/visible structure.                     | Relaxed shirts, summer tailoring.                  |
| Twill            | Diagonal structure; often durable and drapey.    | Trousers, chinos, jackets, suits.                  |
| Satin            | Smooth surface with sheen.                       | Evening/luxury; lighting-sensitive.                |
| Dobby            | Small woven texture/pattern.                     | Shirts and subtle statement fabrics.               |
| Jacquard         | Woven pattern created structurally.              | Statement jackets, luxury pieces.                  |
| Herringbone      | Directional V/zigzag structure.                  | Tailoring, trousers, coats.                        |
| Pinstripe        | Fine vertical stripe pattern.                    | Business/formal tailoring.                         |
| Windowpane       | Large open check.                                | Contemporary tailoring.                            |
| Oxford weave     | Basket-like shirt cloth structure.               | Oxford shirts, casual-smart.                       |
| Piqué            | Textured knit/woven family depending on context. | Polos/formal textures.                             |
| Knit             | Looped construction; stretch/drape vary widely.  | Casual/athleisure/knit tailoring.                  |

# 8. Weight / GSM system

If GSM is supplied, store the actual number. Do not replace it with a
vague label. If GSM is unknown, use a category plus confidence.

| **Class**    | **Indicative design interpretation**                         | **Caution**                                |
|--------------|--------------------------------------------------------------|--------------------------------------------|
| Ultra-light  | Very airy, potentially sheer/fragile.                        | May need lining or restricted garment use. |
| Light        | Summer/resort-friendly.                                      | Check opacity and structure.               |
| Light-medium | Versatile shirts/light trousers/jackets depending on fabric. | Evaluate drape.                            |
| Medium       | Broad smart-casual/tailoring range.                          | Context dependent.                         |
| Medium-heavy | Structured trousers/jackets/suits.                           | Less suitable for hot humid settings.      |
| Heavy        | Cold-weather or highly structured applications.              | Avoid forcing into warm-climate concepts.  |

Exact GSM thresholds should be configurable by fabric family because 180
GSM linen and 180 GSM wool do not behave identically.

# 9. Drape intelligence

| **Drape class** | **Description**                               | **Good candidate garments**                            |
|-----------------|-----------------------------------------------|--------------------------------------------------------|
| Crisp           | Holds shape, sharper folds.                   | Structured shirts, crisp trousers, some jackets.       |
| Moderate        | Balances body and movement.                   | Most tailored shirts/trousers/blazers.                 |
| Soft            | Falls close to body and creates softer folds. | Relaxed shirts, wide trousers, unstructured jackets.   |
| Fluid           | Moves strongly and creates flowing folds.     | Fluid shirts/trousers and fashion-led pieces.          |
| Structured      | Maintains architectural shape.                | Tailored jackets, structured trousers, formal suiting. |

The AI should evaluate drape against silhouette. A very fluid fabric
plus a rigid structured silhouette is not automatically wrong, but it
should be treated as a deliberate design choice.

# 10. Texture intelligence

- Fine smooth → supports clean minimal and formal designs.

- Visible slub → supports natural, relaxed, artisanal and resort
  aesthetics.

- Nubby → creates tactile casual/luxury character.

- Brushed → suggests warmth and softness; often seasonal.

- Raised pile → dramatic surface; useful for evening/statement garments.

- Directional texture → affects pattern placement and cutting decisions.

- High visual texture + complex pattern → may create excessive visual
  noise; simplify silhouette where appropriate.

# 11. Color intelligence

| **Color variable** | **Store**                       | **Why**                       |
|--------------------|---------------------------------|-------------------------------|
| Color name         | Human-readable name             | UI and designer communication |
| HEX/RGB            | Digital approximation           | Rendering/UI                  |
| Undertone          | Warm/cool/neutral + confidence  | Pairing                       |
| Value              | Light ↔ dark                    | Contrast                      |
| Saturation         | Muted ↔ vivid                   | Aesthetic/formality           |
| Variation          | Solid/uniform/marbled/heathered | Generation realism            |
| Pattern contrast   | Low/medium/high                 | Outfit balance                |
| Light response     | Matte/lustrous/translucent      | Rendering                     |

# 12. Fabric-to-garment suitability matrix

| **Garment**         | **Strong fabric candidates**                                | **Potential conflict to flag**                                       |
|---------------------|-------------------------------------------------------------|----------------------------------------------------------------------|
| Dress shirt         | Poplin, fine cotton, linen, Oxford, twill, fine wool blends | Very heavy/unstable fabrics.                                         |
| Resort shirt        | Linen, cotton-linen, rayon/lyocell, silk blends             | Heavy rigid suiting cloth.                                           |
| Tailored trouser    | Wool, linen, cotton twill, blends, corduroy by season       | Very sheer/fragile fabrics unless intentionally designed.            |
| Chino               | Cotton twill, cotton blends                                 | Very fluid fabrics.                                                  |
| Blazer              | Wool, linen, cotton, wool-silk, textured blends             | Extremely soft/unstable fabric for structured construction.          |
| Unstructured jacket | Linen, cotton, soft wool, blends                            | Very stiff fabrics may defeat concept.                               |
| Suit                | Wool, tropical wool, wool blends, selected linen/blends     | Highly casual/unstable fabric for conventional formal suit.          |
| Tuxedo              | Formal wool/barathea/appropriate evening fabrics            | Very rustic/highly textured fabric unless intentionally fashion-led. |

# 13. Climate engine

| **Climate** | **Priorities**                                         | **Typical LLinen Earth direction**                            |
|-------------|--------------------------------------------------------|---------------------------------------------------------------|
| Hot + humid | Breathability, light weight, moisture comfort, airflow | Linen, cotton-linen, open constructions, relaxed silhouettes. |
| Hot + dry   | Breathability + sun coverage                           | Linen/cotton, long sleeves, airy tailoring.                   |
| Mild        | Balance weight and layering                            | Cotton, linen blends, light wool.                             |
| Cool        | Moderate/heavy weight, insulation                      | Wool, flannel, heavier cotton, layering.                      |
| Cold        | Insulation + layering + structure                      | Wool, cashmere, heavier blends.                               |
| Rain/wet    | Drying behavior, protection, resilience                | Technical/synthetic or treated fabrics where appropriate.     |

# 14. Occasion engine

| **Occasion**        | **Fabric direction**                                       | **Design direction**                       |
|---------------------|------------------------------------------------------------|--------------------------------------------|
| Office              | Controlled texture, stable construction                    | Tailored, clean, restrained.               |
| Boardroom           | Fine wool, refined cotton, conservative textures           | Structured tailoring.                      |
| Day wedding         | Linen, tropical wool, cotton/silk blends depending climate | Polished but breathable.                   |
| Evening wedding     | Wool, refined blends, formal textures                      | More structure and depth.                  |
| Beach               | Light, breathable, airy                                    | Linen/resort silhouettes.                  |
| Pool                | Lightweight, quick-dry or easy-care where relevant         | Relaxed resort.                            |
| Luxury hotel dinner | Refined linen, wool, silk blends, textured tailoring       | Relaxed luxury or sophisticated tailoring. |
| Lawn event          | Breathable + polished                                      | Summer tailoring, linen/cotton.            |
| Travel              | Wrinkle tolerance, comfort, resilience                     | Relaxed tailoring and smart separates.     |
| Black tie           | Formal evening fabrics                                     | Tuxedo-specific construction.              |

# 15. Aesthetic engine

| **Aesthetic**       | **Fabric signals**                                   | **Silhouette signals**                               |
|---------------------|------------------------------------------------------|------------------------------------------------------|
| Quiet luxury        | Fine natural materials, subtle texture, low branding | Clean tailoring, restrained contrast.                |
| Italian tailoring   | Soft structure, fine wool/linen, textured luxury     | Natural shoulder, elegant waist, fluid trousers.     |
| British tailoring   | Crisper cloth, structured wool, heritage patterns    | Defined shoulder, controlled silhouette.             |
| Resort luxury       | Linen, silk blends, cotton, breathable textures      | Relaxed, open collars, wide/straight trousers.       |
| Contemporary Indian | Natural textures, refined color, tailored fusion     | Band collars, modern proportions, subtle craft cues. |
| Heritage            | Tweed, corduroy, flannel, textured cottons           | Classic proportions and utility/heritage details.    |
| Modern minimal      | Matte, clean surfaces, controlled colors             | Simple construction and strong proportions.          |
| Bold luxury         | Distinct texture, sheen or color                     | Statement silhouette with controlled styling.        |

# 16. Fabric analysis output shown to user

The analysis UI should look like a professional design consultation
rather than a computer-vision report.

| **Section**        | **Example output**                                             |
|--------------------|----------------------------------------------------------------|
| Detected           | Warm ivory / lightweight appearance / visible slub             |
| Likely family      | Linen or linen-blend — medium confidence                       |
| Drape              | Soft-to-moderate — low/medium confidence                       |
| Surface            | Matte, natural texture                                         |
| Best climate       | Warm / hot                                                     |
| Best uses          | Relaxed shirt, summer trouser, unstructured jacket             |
| Avoid / caution    | Very rigid formal construction unless intentionally structured |
| Designer direction | Quiet resort luxury / contemporary minimal                     |
| Need confirmation  | Composition, GSM, stretch, care                                |

# 17. Designer recommendation algorithm

9.  Filter garment candidates by fabric suitability.

10. Filter by climate.

11. Filter by requested formality.

12. Filter by occasion and destination.

13. Apply aesthetic preference.

14. Score silhouette–drape compatibility.

15. Score color/pattern complexity.

16. Score garment-to-garment compatibility.

17. Generate 3–5 distinct concepts rather than 10 nearly identical
    concepts.

18. Explain the key design decision for each concept.

19. Let the user select one direction and refine individual attributes.

# 18. Design concept output format

| **Field**        | **Example**                                                          |
|------------------|----------------------------------------------------------------------|
| Concept name     | Mediterranean Evening                                                |
| Garment          | Relaxed long-sleeve camp-collar shirt                                |
| Construction     | Open camp collar, French placket, no chest pocket                    |
| Fit              | Relaxed tailored                                                     |
| Fabric treatment | Use fabric naturally; preserve slub and matte character              |
| Color handling   | Use original fabric color; no artificial recoloring unless requested |
| Pairing          | Cream high-rise pleated trousers                                     |
| Footwear         | Dark brown suede loafers                                             |
| Context          | Luxury hotel dinner, warm evening                                    |
| Why              | Balances relaxed fabric character with tailored proportion.          |
| Variations       | 1\) cleaner collar 2) more structured fit 3) bolder trouser contrast |

# 19. Fabric preservation rules for image generation

- Do not replace the uploaded fabric with generic AI texture.

- Preserve dominant color and undertone.

- Preserve visible weave/slub/pattern scale where possible.

- Do not invent large logos, prints or motifs not present in the fabric.

- Respect stripe/check direction and repeat when known.

- Keep fabric weight and drape visually consistent with the
  specification.

- If the image does not provide enough evidence, label the generated
  result as a concept visualization rather than a technical
  representation.

# 20. Fabric-to-outfit compatibility graph

The database should eventually represent relationships such as:

- Fabric → suitable garments

- Fabric → unsuitable garments

- Fabric → climate

- Fabric → occasion

- Fabric → aesthetic

- Fabric → colors

- Fabric → compatible shirt collars/cuffs

- Fabric → compatible trouser silhouettes

- Fabric → compatible jacket structures

- Fabric → compatible footwear/accessories

- Fabric → generation constraints

# 21. User correction loop

The user should be able to correct the AI directly: “It is not linen, it
is cotton-linen,” “The fabric is heavier than you think,” “The color is
more olive,” “I want a sharper fit.” These corrections must update the
current design brief and, when explicitly approved, can become verified
catalogue knowledge.

| **User correction**    | **System behavior**                          |
|------------------------|----------------------------------------------|
| Composition correction | Replace inferred fiber; lower old inference. |
| Color correction       | Update digital color target and regenerate.  |
| Weight correction      | Re-score garment suitability.                |
| Drape correction       | Re-score silhouettes.                        |
| Occasion correction    | Re-run context scoring.                      |
| Aesthetic correction   | Change concept direction, not fabric facts.  |

# 22. Data provenance and rights

- Every physical fabric record should have a supplier/source reference
  when available.

- Store whether the fabric image is LLinen Earth-owned,
  customer-uploaded, licensed or external reference.

- Customer-uploaded images should not automatically become training
  data.

- Separate reference imagery from commercially usable
  generation/training data.

- Maintain a source and permission ledger.

# 23. Developer-ready fabric object

| **Field**              | **Example**                         |
|------------------------|-------------------------------------|
| id                     | FAB-LINEN-0001                      |
| name                   | Warm Ivory Slub Linen               |
| fiber_primary          | linen                               |
| fiber_secondary        | unknown                             |
| composition_confidence | medium                              |
| weight_class           | light                               |
| gsm                    | unknown                             |
| drape                  | soft-moderate                       |
| texture                | slub                                |
| sheen                  | matte                               |
| stretch                | none                                |
| opacity                | medium                              |
| wrinkle                | high                                |
| color_name             | warm ivory                          |
| color_hex              | approximate                         |
| undertone              | warm                                |
| climate_tags           | hot, humid, warm                    |
| occasion_tags          | resort, summer wedding, dinner      |
| aesthetic_tags         | quiet luxury, resort, minimal       |
| garment_candidates     | shirt, trouser, unstructured blazer |
| avoid_tags             | heavy formal winter tailoring       |
| confidence             | medium                              |
| source                 | LLinen Earth fabric archive         |
| rights                 | owned                               |
| version                | 1.0                                 |

# 24. What this enables later

- Fabric upload and automatic analysis.

- AI-generated garment recommendations.

- Fabric-specific prompt generation.

- Color and styling recommendations.

- Personalized outfit combinations.

- Search: “show me lightweight fabrics suitable for a summer wedding.”

- Search: “which of my fabrics can become a relaxed luxury shirt?”

- Internal designer tool for converting fabric inventory into design
  concepts.

- Future product matching: connect generated designs to actual LLinen
  Earth fabric inventory.

# 25. Recommended next module

After this fabric system, the next knowledge layer should be the
OCCASION + DESTINATION + AESTHETIC DESIGN SYSTEM. That layer will tell
the AI what the user is actually trying to achieve, while the garment
and fabric systems tell it what can physically and visually work.

Then we should build the COLOR + PATTERN + MATERIAL PAIRING SYSTEM. Once
those are complete, we will have enough of the design brain to begin
specifying the actual AI Designer interface and the first Claude-built
website prototype.
