**LLINEN EARTH**

**AI Designer Logic & Decision Engine**

*Designer Brain Specification — Part 6, v1.0*

The orchestration layer that converts fabric, context, garment
knowledge, aesthetics, pairing intelligence, user preferences and
references into ranked, explainable, designer-level outfit concepts.

**INPUTS -\> CONSTRAINTS -\> DESIGN HYPOTHESES -\> CANDIDATES -\>
SCORING -\> DIVERSIFICATION -\> EXPLANATION -\> REFINEMENT -\> FINAL
DESIGN SPEC**

# 1. Purpose

Parts 1-5 define what LLinen Earth knows about garments, fabrics,
contexts, pairing and aesthetics. Part 6 defines how that knowledge is
used to make actual design decisions. The engine should behave like a
disciplined designer: interpret the brief, identify constraints,
generate multiple valid directions, compare them, select the strongest,
explain its choices and refine intelligently when the customer reacts.

- Prevent generic 'AI outfit' outputs by grounding every choice in
  structured fashion knowledge.

- Separate hard constraints from stylistic preferences.

- Generate materially different concepts rather than cosmetic variants.

- Rank candidates with transparent scores and confidence.

- Preserve a consistent design specification for downstream image
  generation.

- Learn from user corrections and preferences without allowing
  short-term feedback to corrupt core design rules.

# 2. Inputs to the Designer Engine

| **Input source**      | **Examples**                                                                     | **Engine use**                                        |
|-----------------------|----------------------------------------------------------------------------------|-------------------------------------------------------|
| Fabric Intelligence   | Fiber estimate, color, pattern, drape, weight, texture, confidence               | Material feasibility and garment suitability          |
| Garment Design System | Stable garment IDs and compositional attributes                                  | Constructs actual shirts, trousers, jackets and suits |
| Context System        | Occasion, venue, time, climate, formality                                        | Defines social and physical constraints               |
| Pairing System        | Color, pattern, material, footwear and accessory compatibility                   | Builds coherent full looks                            |
| Aesthetic System      | Quiet luxury, Italian-inspired, modern classic, etc.                             | Controls silhouette and visual language               |
| User preferences      | Fit, colors, desired impression, dislikes, wardrobe pieces                       | Personal adaptation                                   |
| Reference images      | Silhouette/details/color relationships                                           | Attribute inspiration, not literal copying            |
| Business rules        | LLinen Earth brand direction, inventory, available fabrics, tailoring capability | Commercial and production fit                         |

# 3. Modes of Use

| **Mode**               | **User starts with**                  | **Primary output**                                    |
|------------------------|---------------------------------------|-------------------------------------------------------|
| Fabric-first design    | Fabric photo/swatches                 | Garment and complete outfit concepts                  |
| Occasion-first design  | Event/destination                     | Recommended fabric + garment + styling direction      |
| Reference-first design | Inspiration image                     | Original design derived from selected attributes      |
| Garment-first design   | Known shirt/trouser/jacket type       | Compatible fabric and full-look recommendations       |
| Wardrobe completion    | Existing garment/shoe                 | Best complementary pieces                             |
| Explore / surprise me  | Minimal brief                         | Controlled discovery across compatible aesthetics     |
| Tailoring consultation | Body/fit preferences + fabric/context | Construction and proportion brief for tailor workflow |

# 4. High-Level Decision Pipeline

1.  Parse all user inputs and extract known facts, preferences,
    references and uncertainty.

2.  Merge these with structured outputs from Fabric, Context, Pairing
    and Aesthetic systems.

3.  Identify hard constraints and reject impossible/inappropriate
    options early.

4.  Determine the design objective and which garment should act as the
    visual anchor.

5.  Generate several design hypotheses before generating detailed
    outfits.

6.  Construct candidate outfits using stable garment attributes and
    compatibility rules.

7.  Score candidates across functional, aesthetic and personal
    dimensions.

8.  Apply diversity logic so top results represent genuinely different
    directions.

9.  Generate concise designer rationale and warnings.

10. Present 3-5 directions; allow controlled natural-language
    refinement.

11. Lock the selected design into a structured specification.

12. Pass that immutable/traceable specification to the visualization
    engine.

# 5. Brief Parser

The first stage converts conversational language into structured
variables. It must distinguish facts, preferences, soft requests and
uncertain assumptions.

| **Statement**                      | **Interpretation**                                                     |
|------------------------------------|------------------------------------------------------------------------|
| 'Beach wedding in Goa at sunset'   | Occasion=wedding; venue=coastal/outdoor; time=sunset; likely hot-humid |
| 'I want it premium but not flashy' | Aesthetic preference=quiet/elevated; high ornamentation penalty        |
| 'Use this fabric for a blazer'     | Garment role is user-fixed unless fabric feasibility is very poor      |
| 'Something like this photo'        | Extract attributes; do not treat image as an exact-copy instruction    |
| 'I hate skinny trousers'           | Persistent negative preference for candidate generation                |
| 'Make it younger'                  | Refinement delta, not a complete restart                               |

# 6. Hard Constraints vs Soft Preferences

| **Hard constraint**                      | **Soft preference**                  |
|------------------------------------------|--------------------------------------|
| Dress-code requirement                   | Favorite aesthetic                   |
| Unsafe/impractical fabric use            | Preferred color family               |
| Extreme climate incompatibility          | Fit preference within feasible range |
| Explicit cultural/ceremonial requirement | Desired level of novelty             |
| Garment production limitation            | Brand/style inspiration              |
| User-fixed garment role where feasible   | Accessory preference                 |

Hard constraints are applied before creative generation. Soft
preferences influence scoring and ranking. When a soft preference
conflicts with a hard constraint, the engine should explain the conflict
and propose the closest viable interpretation.

# 7. Uncertainty & Confidence Layer

- Every inferred property should carry confidence: high, medium, low or
  a 0-1 score.

- Do not treat visually estimated fiber content, GSM or stretch as
  verified facts.

- Ask a follow-up question only when the missing information is likely
  to change the top design decision.

- If uncertainty does not materially affect the result, proceed and
  state the assumption subtly.

- When two interpretations are plausible, generate branches instead of
  forcing one interpretation.

# 8. Information-Gain Questioning

The AI should not interview the customer unnecessarily. A question is
worth asking when its answer could reorder the top candidate set.

| **Question type**      | **Ask when**                             | **Example**                                                   |
|------------------------|------------------------------------------|---------------------------------------------------------------|
| Occasion clarification | Formality range is ambiguous             | 'Is this for the ceremony or the reception?'                  |
| Venue clarification    | Climate/styling may change               | 'Will most of the event be outdoors?'                         |
| Fabric confirmation    | Material assumption affects construction | 'Is this pure linen or a linen blend?'                        |
| Fit clarification      | Two silhouette families are close        | 'Do you prefer tailored or visibly relaxed trousers?'         |
| Color clarification    | Photo white balance is unreliable        | 'Does the fabric look more blue-grey or warm blue in person?' |

# 9. Design Objective Selection

Before generating garments, define the design objective. The same inputs
can produce different valid designs depending on whether the goal is
versatility, distinction, formal authority, resort ease, trend relevance
or maximum fabric expression.

| **Objective**     | **Optimization bias**                                |
|-------------------|------------------------------------------------------|
| Versatile premium | Rewearability, compatibility, timelessness           |
| Event impact      | Context fit + controlled distinctiveness             |
| Fabric showcase   | Let texture/color/pattern remain the hero            |
| Modern tailoring  | Contemporary proportion without short-lived extremes |
| Quiet luxury      | Material/fit/detail precision; lower visual noise    |
| Statement fashion | Higher novelty within practical/context bounds       |

# 10. Anchor Selection

- If the user uploads a fabric and says its intended garment, that piece
  normally becomes the anchor.

- If a bold patterned fabric is used, supporting pieces should normally
  become quieter.

- If the user already owns a jacket or shoe, that item can become the
  anchor for wardrobe completion.

- The anchor is not always the loudest piece; it is the piece around
  which the remaining outfit is optimized.

- The engine should explicitly record anchor type and anchor priority.

# 11. Design Hypothesis Generation

Generate broad concepts before detailed outfits. This encourages real
creative diversity instead of changing only color.

| **Hypothesis type** | **Example**                                                            |
|---------------------|------------------------------------------------------------------------|
| Soft tailored       | Unstructured jacket + high-rise straight trouser + refined shirt       |
| Minimal separates   | Hero shirt + clean trouser + no jacket                                 |
| Formal structured   | Defined suit/jacket + crisp shirt + formal footwear                    |
| Resort elevated     | Open-collar shirt + relaxed tailored trouser + suede loafer            |
| Contemporary Indian | Modern culturally appropriate silhouette + restrained textile emphasis |
| Editorial direction | Directional proportions/details while keeping fabric realistic         |

# 12. Candidate Construction

Each hypothesis is expanded into a complete candidate using
compositional garment attributes rather than a single named style.

- Select garment family and stable garment ID.

- Assign silhouette, rise, pleats, waistband, pockets, hem and break for
  trousers.

- Assign collar, cuff, placket, yoke, back, hem and fit for shirts.

- Assign lapel, shoulder, closure, button stance, pockets, vents,
  canvas/lining and length for jackets.

- Assign suit relationship when jacket/trouser are intended as a set.

- Assign colors, patterns, textures, materials, footwear and
  accessories.

- Attach intended aesthetic and context rationale to each attribute
  group.

# 13. Candidate Feasibility Filters

| **Filter**                      | **Reject / penalize when**                                    |
|---------------------------------|---------------------------------------------------------------|
| Fabric-construction feasibility | Fabric cannot plausibly support the proposed structure/drape  |
| Climate feasibility             | Weight/layers are impractical for environment                 |
| Dress-code feasibility          | Look underdresses or overdresses the event materially         |
| Pattern feasibility             | Pattern scale/orientation is incompatible with garment panels |
| Layering feasibility            | Thickness/volume makes the stack unrealistic                  |
| Production feasibility          | LLinen Earth/tailor cannot execute required construction      |
| Reference originality           | Candidate copies a reference too literally                    |

# 14. Multi-Dimensional Scoring

Scores are normalized and weighted dynamically. No single aesthetic
score should rescue a design that fails functional or contextual
requirements.

| **Score dimension**              | **Purpose**                                         |
|----------------------------------|-----------------------------------------------------|
| Fabric suitability               | Does material support the garment and construction? |
| Context fit                      | Does it suit occasion, venue, time and climate?     |
| Formality fit                    | Is dress level appropriate?                         |
| Color/pattern/material coherence | Does the complete outfit work visually?             |
| Aesthetic fidelity               | Does it genuinely express the chosen aesthetic?     |
| Proportion/silhouette coherence  | Do all garment volumes work together?               |
| Personal preference              | Fit, colors, dislikes, desired impression           |
| Comfort/practicality             | Movement, heat, wrinkle tolerance, travel needs     |
| Originality                      | Distinctive without novelty for novelty's sake      |
| Versatility                      | Rewear and wardrobe integration where relevant      |
| LLinen Earth brand fit           | Premium, refined, intentional                       |
| Confidence                       | Penalty when critical inputs are uncertain          |

# 15. Dynamic Weighting

| **Scenario**           | **Weights that increase**                                  |
|------------------------|------------------------------------------------------------|
| Outdoor summer wedding | Climate, fabric, venue, movement                           |
| Boardroom              | Formality, credibility, proportion, restraint              |
| Resort holiday         | Climate, texture, comfort, relaxed aesthetic               |
| Fashion event          | Originality, aesthetic fidelity, silhouette                |
| Travel capsule         | Versatility, wrinkle behavior, compatibility               |
| Fabric showcase        | Fabric preservation, garment suitability, visual hierarchy |

# 16. Diversity / Anti-Duplicate Logic

The top 3-5 concepts should not be the same outfit in different colors.
After scoring, the engine applies a similarity penalty.

- Compare silhouette families.

- Compare garment composition: shirt-only vs jacketed vs suit/separates.

- Compare formality level.

- Compare aesthetic profile.

- Compare color/value strategy.

- Compare detail/construction strategy.

- Require a minimum design-distance threshold between surfaced
  candidates.

# 17. Safe / Elevated / Statement Portfolio

| **Direction** | **Behavior**                                                                 |
|---------------|------------------------------------------------------------------------------|
| Safe          | Highest conventional compatibility and broad wearability                     |
| Elevated      | Premium default: nuanced proportion/material/color with moderate distinction |
| Statement     | More directional silhouette/color/detail while respecting hard constraints   |

For most customers, the engine should bias the first recommendation
toward Elevated rather than Safe. The goal is to provide genuine
designer value without making every answer theatrical.

# 18. Designer Rationale Generator

Explanations should sound like a concise designer consultation, not
reveal internal chain-of-thought. They should state observable reasons
and tradeoffs.

| **Explain**              | **Example**                                                                                                             |
|--------------------------|-------------------------------------------------------------------------------------------------------------------------|
| Fabric -\> garment       | 'The softer linen is better used in an unstructured jacket than a rigid formal blazer.'                                 |
| Color -\> pairing        | 'Stone trousers keep the pale blue fabric as the focus while maintaining low-contrast summer elegance.'                 |
| Context -\> construction | 'Reduced lining keeps the look appropriate for a humid outdoor event.'                                                  |
| Aesthetic -\> proportion | 'A slightly higher rise and straighter leg create the relaxed refinement of the selected Italian-influenced direction.' |
| Warning                  | 'A fully structured three-piece version would look polished but will be less comfortable in this climate.'              |

# 19. Reference-Image Engine

13. Identify garments visible in the reference.

14. Extract attributes: silhouette, proportions, collar/lapel, pockets,
    closures, color relationships, material cues, styling.

15. Separate garment design from photography, pose, body and
    environment.

16. Ask which reference attributes matter only if multiple
    interpretations would lead to different designs.

17. Map selected attributes into LLinen Earth garment ontology.

18. Adapt them to the user's real fabric, context and preferences.

19. Generate an original candidate; record provenance of
    reference-derived attributes.

# 20. Controlled Refinement Engine

Refinement should modify the existing selected concept instead of
regenerating randomly. Each user instruction becomes a design delta.

| **User refinement** | **Typical controlled changes**                                                          |
|---------------------|-----------------------------------------------------------------------------------------|
| More formal         | Increase structure/formality; refine footwear; reduce casual styling                    |
| More relaxed        | Reduce structure; increase ease; simplify accessories                                   |
| More premium        | Improve material hierarchy, construction detail, restraint; not automatic ornamentation |
| Younger             | Update proportion/styling; avoid arbitrary bright colors                                |
| More classic        | Reduce trend signals; normalize proportions/details                                     |
| More Italian        | Softer structure, elegant drape, refined ease                                           |
| More British        | Increase tailoring definition and heritage vocabulary                                   |
| More Indian         | Shift garment vocabulary/context sensitivity, not merely add motifs                     |
| Less common         | Increase controlled novelty while preserving fit/context                                |
| Use less fabric     | Optimize garment choice/construction where technically sensible                         |

# 21. Refinement State Management

- Maintain a versioned design state: v1, v2, v3, etc.

- Record which attributes changed and why.

- Do not silently change unrelated components after a narrow refinement
  request.

- Allow undo/compare between design versions.

- When a requested delta breaks a hard constraint, explain and propose
  the nearest viable change.

# 22. User Preference Memory Model

Preference learning should be explicit and confidence-weighted. A single
choice should not become a permanent rule.

| **Preference type**  | **Examples**               | **Learning behavior**                               |
|----------------------|----------------------------|-----------------------------------------------------|
| Stable preference    | Dislikes skinny trousers   | Increase weight after repeated/explicit signals     |
| Aesthetic preference | Often chooses quiet luxury | Gradually bias ranking, not generation availability |
| Color preference     | Prefers navy/earth tones   | Use as soft prior                                   |
| Fit preference       | Tailored-relaxed           | Strong prior where context permits                  |
| Temporary request    | Wants pink for one wedding | Do not convert to permanent preference              |

# 23. Negative Feedback Handling

- If user says 'I don't like it,' ask one focused reason only when
  necessary.

- Offer quick refinement dimensions: silhouette, color, formality,
  detailing, aesthetic.

- Avoid regenerating from scratch before learning what failed.

- Store rejection reason at attribute level when the user makes it
  clear.

- Repeated rejection of the same signal should reduce its future ranking
  weight.

# 24. Commercial / Inventory Awareness

The designer should have a clean separation between ideal design logic
and commercial availability. First determine what is
aesthetically/technically right; then map to LLinen Earth inventory or
tailoring options.

- Never recommend an inferior combination solely because it is in stock
  without marking the compromise.

- Rank exact-match inventory first when it satisfies the design brief.

- Offer near alternatives with clear differences.

- Future system can distinguish 'design ideal', 'available now', and
  'made-to-order'.

# 25. Brand Guardrails

- Premium does not equal more decoration.

- Luxury does not equal visible logos.

- Trend does not override proportion, fabric or context.

- The uploaded fabric should not be visually altered merely to make
  generation easier.

- Avoid generic catalogue styling when the context calls for a
  distinctive designer response.

- Maintain refined menswear credibility even in statement mode.

- Originality must come from combination, proportion, construction and
  material intelligence.

# 26. Failure & Fallback Logic

| **Failure state**                      | **System behavior**                                                       |
|----------------------------------------|---------------------------------------------------------------------------|
| Fabric photo too poor                  | Ask for one clearer image or proceed with color-only confidence           |
| Unknown fabric composition             | Use visual properties only; mark construction recommendations conditional |
| Conflicting user requirements          | Identify conflict and present 2 compromise routes                         |
| No candidate clears threshold          | Explain why and request the single highest-information clarification      |
| Image generator cannot preserve design | Return to structured spec; do not weaken design rules silently            |
| Inventory unavailable                  | Offer made-to-order or nearest design-equivalent substitute               |

# 27. Minimum Candidate Thresholds

Before presenting a recommendation, critical scores must exceed minimum
thresholds. Thresholds are scenario-specific. For example, a visually
strong outfit with poor climate suitability should not be surfaced as
the primary recommendation for a tropical outdoor event.

- Critical hard-constraint checks: pass/fail.

- Context fit: minimum threshold.

- Fabric feasibility: minimum threshold.

- Formality compliance: minimum threshold when dress code is explicit.

- Overall score: minimum quality threshold.

- Confidence: warn when critical uncertainty is above tolerance.

# 28. Output to the User

A premium user-facing recommendation should be compact, visual and
comparable.

| **Output block** | **Content**                                        |
|------------------|----------------------------------------------------|
| Direction name   | Short designer-style name                          |
| One-line concept | What the look is trying to achieve                 |
| Garments         | Structured shirt/trouser/jacket/suit specification |
| Palette/material | Key colors and fabric relationships                |
| Why it works     | 2-4 concise reasons                                |
| Best for         | Occasion/time/venue emphasis                       |
| Tradeoff         | One useful caution if relevant                     |
| Actions          | Visualize, refine, compare, save                   |

# 29. Final Design Lock

Once the user selects a concept, the system creates a locked design
specification. This becomes the single source of truth for all generated
views and future edits.

- Garment IDs and every compositional attribute.

- Fabric IDs and fabric-to-garment mapping.

- Exact palette role definitions.

- Pattern scale/orientation rules.

- Silhouette and proportion profile.

- Construction notes.

- Styling and accessory instructions.

- Context/aesthetic intent.

- Reference-derived attributes and provenance.

- Version ID and parent design ID.

# 30. Visualization Handoff Contract

| **Field**                   | **Why required**                               |
|-----------------------------|------------------------------------------------|
| Design version ID           | Keeps all views tied to the same design        |
| Model/mannequin ID          | Maintains body consistency                     |
| Garment spec                | Prevents front/back/detail inconsistencies     |
| Fabric asset + mapping      | Preserves texture/pattern/color                |
| Fit/proportion values       | Maintains silhouette                           |
| View definition             | Front, side, back, detail                      |
| Pose rules                  | Avoid pose changing garment interpretation     |
| Lighting/background profile | Keeps catalogue consistency                    |
| Negative constraints        | Details the image model must not invent/change |

# 31. Developer-Ready Designer Request Object

{  
"request_id": "REQ-...",  
"mode": "fabric_first",  
"anchor": {  
"type": "fabric",  
"fabric_id": "FAB-...",  
"intended_garment": "shirt"  
},  
"context_id": "CTX-...",  
"aesthetic": {  
"primary": "quiet_luxury",  
"secondary": "resort_luxury"  
},  
"user_preferences": {  
"fit": "tailored_relaxed",  
"avoid": \["skinny_trouser", "high_shine"\],  
"desired_impression": \["elegant", "relaxed"\]  
},  
"references": \[\],  
"hard_constraints": \[\],  
"generation_policy": {  
"candidate_count": 8,  
"surface_count": 3,  
"portfolio": \["safe", "elevated", "statement"\]  
}  
}

# 32. Developer-Ready Candidate Object

{  
"candidate_id": "DES-...",  
"hypothesis": "soft_tailored",  
"portfolio_mode": "elevated",  
"anchor_priority": 1.0,  
"garments": \[  
{  
"garment_id": "SHIRT-...",  
"fabric_id": "FAB-...",  
"attributes": {}  
},  
{  
"garment_id": "TROUSER-...",  
"fabric_id": "FAB-...",  
"attributes": {}  
}  
\],  
"pairing": {},  
"aesthetic_profile": {},  
"scores": {  
"fabric": 0.94,  
"context": 0.96,  
"formality": 0.91,  
"pairing": 0.93,  
"aesthetic": 0.95,  
"proportion": 0.92,  
"personal": 0.90,  
"originality": 0.82,  
"brand_fit": 0.96,  
"overall": 0.93  
},  
"confidence": 0.90,  
"rationale": \[\],  
"warnings": \[\],  
"visualization_spec_id": null  
}

# 33. Decision Trace for Internal QA

The production system should store a concise machine-readable decision
trace for debugging and quality control, without exposing hidden
chain-of-thought. Store inputs, rule hits, score components, rejected
candidate reasons, confidence values and final selected attributes.

- Useful for debugging inconsistent recommendations.

- Allows designers to audit why a candidate ranked highly.

- Supports A/B testing of scoring weights.

- Provides evidence for regression tests after model or rule updates.

# 34. Human Designer Override

- A LLinen Earth designer should be able to pin/lock attributes.

- Human edits should remain visible as overrides in the design state.

- The AI can re-optimize unlocked fields around human choices.

- Designer-approved concepts can become high-quality retrieval examples
  after rights/provenance review.

- Human override data is especially valuable for refining scoring
  weights and exception rules.

# 35. Evaluation Framework

| **Evaluation**        | **Question**                                                         |
|-----------------------|----------------------------------------------------------------------|
| Expert quality        | Would an experienced menswear designer consider the output coherent? |
| Context accuracy      | Does it truly fit the event and destination?                         |
| Fabric realism        | Could the proposed fabric behave this way?                           |
| Design diversity      | Are top candidates meaningfully different?                           |
| Personalization       | Does the output reflect stated preferences?                          |
| Explainability        | Are recommendations justified in useful language?                    |
| Refinement stability  | Does a small edit preserve unrelated choices?                        |
| Visual consistency    | Do generated views match the locked specification?                   |
| Conversion usefulness | Can a customer confidently choose or discuss the design?             |

# 36. Test Scenarios

- Pale linen uploaded for a humid sunset beach wedding.

- Dark wool fabric uploaded for a daytime summer outdoor event: engine
  should challenge the brief.

- Bold check fabric requested for a conservative boardroom suit.

- Reference image shows a structured winter blazer but user's fabric is
  lightweight linen.

- User asks for 'quiet luxury' but repeatedly requests multiple loud
  accessories.

- User selects elevated concept, then asks only for a more relaxed
  trouser: jacket/shirt should stay stable.

- User rejects three slim silhouettes: future candidates should move
  away from slim without losing formality.

- Same fabric tested in Safe, Elevated and Statement portfolios.

# 37. System Architecture Position

The Designer Engine should orchestrate specialized services rather than
place every rule inside one giant prompt. Fabric analysis, garment
ontology, context interpretation, pairing, aesthetic profiling, ranking,
retrieval and visualization can evolve independently while communicating
through stable schemas.

# 38. Recommended First Implementation

20. Build deterministic garment/context/fabric schemas first.

21. Use a retrieval + rules + LLM orchestration layer for concept
    generation and explanation.

22. Implement candidate scoring as explicit code/configuration so
    weights are testable.

23. Use a curated reference database for retrieval; do not depend on
    arbitrary live-web images for core behavior.

24. Keep image generation downstream from a locked structured design
    object.

25. Add human designer review tools before attempting autonomous
    learning from every interaction.

# 39. MVP vs Premium Version

| **MVP**                    | **Premium evolution**                          |
|----------------------------|------------------------------------------------|
| 1 fabric upload            | Multi-fabric comparison and wardrobe inputs    |
| Basic context form         | Progressive conversational intake              |
| 3 outfit directions        | Adaptive portfolio + deeper diversification    |
| Rule-weighted scoring      | Learned ranker constrained by rules            |
| Single visualization       | Consistent front/side/back/detail set          |
| Manual refinement controls | Natural-language delta editing                 |
| Generic model              | Persistent customer mannequin/profile          |
| Static reference library   | Curated retrieval + designer-approved examples |

# 40. Part 6 Completion Criteria

- The system can transform an uploaded fabric and context into at least
  three coherent, distinct outfit concepts.

- Each concept is built from structured garment attributes.

- Hard constraints can reject invalid concepts before presentation.

- Scoring is explicit, dynamic and testable.

- The user can refine one dimension without random changes elsewhere.

- The selected design is frozen into a complete visualization-ready
  specification.

- All major recommendations can be explained without exposing hidden
  reasoning.

# 41. Next Specification

Next: Part 7 - AI Image & Model Generation Specification. It will define
how the locked design is visualized on a consistent model/mannequin, how
uploaded fabric is preserved, how front/side/back/detail views stay
identical, how fit and garment construction remain accurate, and which
generation/editing architecture is best suited for a premium commercial
experience.
