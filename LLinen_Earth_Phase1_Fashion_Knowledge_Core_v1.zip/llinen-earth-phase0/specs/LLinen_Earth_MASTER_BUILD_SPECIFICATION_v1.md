**LLINEN EARTH**

**MASTER BUILD SPECIFICATION**

*Coding-Agent Handoff & Product Source of Truth — v1.0*

Primary implementation brief for building the LLinen Earth AI fashion
designer platform from the nine detailed system specifications.

**HUMANS DEFINE PRODUCT & QUALITY -\> AGENTS IMPLEMENT IN GATED PHASES
-\> TEST -\> REVIEW -\> PROCEED**

# 1. Purpose of This Master Specification

This is the first document a coding agent should read. It does not
replace Parts 1-9; it tells the agent how those specifications fit
together, which documents are authoritative for each subsystem, what to
build first, what must remain structured, and what acceptance gate must
pass before proceeding.

- Do not attempt the full platform in one uncontrolled implementation
  pass.

- Treat the detailed Part documents as product requirements, not
  optional inspiration.

- Raise conflicts between specifications instead of silently inventing
  behavior.

- Preserve stable domain schemas and versioning.

- Optimize for a credible working vertical slice before breadth.

# 2. Product Definition

LLinen Earth is a premium menswear/fabric experience whose central
product is an AI Designer. A customer can begin with fabric, an
occasion, a reference or exploration. The system understands material
and context, creates multiple designer-level outfit directions, explains
them, supports controlled refinement, locks the selected design, and
produces consistent garment visualizations. The digital experience
should also connect naturally to LLinen Earth's physical
fabric/tailoring business.

# 3. Source-of-Truth Documents

| **Part** | **Document**                                                 | **Authority**                                                    |
|----------|--------------------------------------------------------------|------------------------------------------------------------------|
| 1        | Fashion Design System Master Spec                            | Garment ontology: trousers, shirts, jackets/blazers, suits       |
| 2        | Fabric Intelligence System                                   | Fabric properties, visual analysis, suitability                  |
| 3        | Occasion / Destination / Aesthetic Context System            | Occasion, venue, time, climate, formality/context                |
| 4        | Color / Pattern / Material Pairing System                    | Outfit compatibility and pairing graph                           |
| 5        | Style & Aesthetic Intelligence System                        | Aesthetic DNA, proportion, blending, trend modifiers             |
| 6        | AI Designer Logic & Decision Engine                          | Candidate generation, constraints, scoring, refinement           |
| 7        | AI Image & Model Generation Specification                    | Fabric/model/garment consistency and render QA                   |
| 8        | Website UX/UI & Premium Experience                           | Customer journey, pages, components and brand experience         |
| 9        | Technical Architecture, Database, APIs & Implementation Plan | Software architecture, data, APIs, security, testing, deployment |

# 4. Precedence Rules

1\. Safety, privacy, rights and security requirements override creative
behavior.

2\. Locked structured design data overrides generated prose or
image-model improvisation.

3\. Part 1-5 domain definitions override ad-hoc fashion assumptions in
prompts.

4\. Part 6 governs design decision behavior.

5\. Part 7 governs visualization behavior after a design is locked.

6\. Part 8 governs user-facing interaction unless it conflicts with
data/security requirements in Part 9.

7\. When specifications genuinely conflict, stop that implementation
decision and document the conflict for product review.

# 5. Non-Negotiable Architecture Principles

- The application is not a chatbot wrapper.

- The Fashion Brain exists as structured schemas, rules, relationships
  and curated knowledge.

- The Designer Engine generates structured candidates before user-facing
  prose.

- Scoring and hard constraints are explicit and testable.

- Design refinements create versioned deltas; unrelated locked fields
  remain unchanged.

- Image generation consumes a locked design specification; it does not
  redesign the outfit.

- AI/model providers are replaceable behind adapters.

- User assets and reference rights/provenance are first-class data.

- Expensive AI/image work runs asynchronously.

- Human fashion experts can override, audit and improve the system.

# 6. Recommended Repository Contract

/apps  
/web  
/worker  
/packages  
/domain  
/fashion-rules  
/designer-engine  
/ai-gateway  
/db  
/schemas  
/ui  
/testing  
/specs  
/01-garments  
/02-fabrics  
/03-context  
/04-pairing  
/05-aesthetics  
/06-designer  
/07-visualization  
/08-ux  
/09-architecture  
MASTER_BUILD_SPEC.md  
/docs  
ARCHITECTURE_DECISIONS.md  
IMPLEMENTATION_STATUS.md

# 7. Agent Working Rules

- Read this Master Spec and the relevant Part specification before
  changing a subsystem.

- Work one phase/issue at a time.

- Before coding, state the files/modules to be changed and acceptance
  tests to be satisfied.

- Do not invent new taxonomy values when an existing structured value is
  appropriate.

- Any necessary schema extension must be documented and migrated.

- Do not remove validation merely to make an AI response pass.

- Use mocks/fixtures for costly providers in automated tests.

- Do not commit secrets, user uploads or unlicensed reference assets.

- Update IMPLEMENTATION_STATUS.md after each accepted milestone.

- Create small reviewable commits/pull requests rather than one massive
  rewrite.

# 8. Definition of Done for Any Feature

| **Area**      | **Done means**                                   |
|---------------|--------------------------------------------------|
| Functionality | Acceptance behavior works end-to-end             |
| Types/schemas | Inputs and outputs validated                     |
| Tests         | Relevant unit/integration/E2E tests pass         |
| Error states  | Failure path is handled                          |
| Security      | Authorization/input validation considered        |
| Observability | Meaningful failures are traceable                |
| UX            | Loading, empty and error states exist            |
| Documentation | Any architecture/schema change recorded          |
| Regression    | Existing critical Fashion Brain tests still pass |

# 9. Phase 0 — Foundation

Goal: create a production-quality skeleton without implementing AI
fashion logic.

- Next.js + TypeScript web application.

- LLinen Earth design tokens and responsive application shell.

- Black -\> logo -\> navy brand intro with reduced-motion behavior.

- PostgreSQL connection, migration system and typed DB layer.

- Authentication foundation and roles.

- S3-compatible private asset abstraction.

- Worker/job abstraction.

- Environment/secret configuration.

- CI checks: types, lint, tests, build.

- Basic error monitoring hooks.

## Phase 0 Acceptance Gate

- App runs locally from documented setup.

- Production build succeeds.

- DB migration creates baseline schema.

- Private upload flow works with authorization.

- No secret exists in client bundle/repository.

- Brand intro works desktop/mobile and respects reduced motion.

- CI passes.

# 10. Phase 1 — Fashion Knowledge Core

Goal: convert Parts 1-5 from documents into queryable structured seed
data.

- Implement stable IDs and schemas for garments, fabrics, contexts,
  aesthetics and pairing edges.

- Seed a high-quality subset first; do not rush to hundreds of weak
  records.

- Build read APIs and internal validation.

- Implement knowledge versioning/provenance.

- Create initial Admin/Knowledge Studio or seed-data workflow.

- Add search/filter support.

## Phase 1 Acceptance Gate

- At least representative trousers, shirts, jackets and suits can be
  queried by structured attributes.

- Fabric profiles expose confidence/provenance.

- Context and aesthetic profiles are machine-readable.

- Pairing relationships can be queried with conditions.

- Invalid taxonomy values fail validation.

- Seed data is version-controlled and tested.

# 11. Phase 2 — Fabric Upload & Analysis

Goal: let a customer upload a fabric and obtain an editable structured
profile.

- Fabric upload UI and asset persistence.

- Vision-analysis adapter returning structured observations.

- Color/pattern/texture/fabric-family estimates with confidence.

- Original asset remains immutable.

- Correction UI for user-confirmable properties.

- Analysis cache by asset checksum/version.

- Rights/source metadata.

## Phase 2 Acceptance Gate

- Upload -\> analysis -\> saved fabric profile works end-to-end.

- Low-confidence technical facts are not presented as verified.

- User corrections persist without overwriting original observations.

- Provider failure leaves the session recoverable.

- Private fabric URLs are not publicly enumerable.

# 12. Phase 3 — Context Consultation

Goal: gather only the information that materially affects design.

- Fabric-first, occasion-first and reference-first entry paths.

- Progressive context questions.

- Structured occasion, venue, time, climate, formality, desired
  impression and fit preferences.

- Editable assumption summary.

- Information-gain logic for follow-up questions.

- Session persistence/resume.

## Phase 3 Acceptance Gate

- User reaches a complete design brief without a long static form.

- Known details are not asked repeatedly.

- Important assumptions can be corrected.

- The resulting context object validates against Part 3 schema.

- Session survives refresh/login continuation.

# 13. Phase 4 — Designer Engine MVP

Goal: prove the central value proposition before premium image
generation.

1\. Load fabric/context/preferences.

2\. Apply hard constraints.

3\. Retrieve relevant Fashion Brain knowledge.

4\. Generate multiple design hypotheses.

5\. Construct structured garment candidates.

6\. Score candidates explicitly.

7\. Apply diversity penalty.

8\. Surface Safe, Elevated and Statement directions.

9\. Generate concise rationale from the structured result.

## Phase 4 Acceptance Gate

- Three surfaced candidates are materially different, not recolors.

- Each garment uses valid Part 1 attributes.

- A deliberately unsuitable fabric/context test is rejected or warned
  correctly.

- Score components are persisted.

- Elevated recommendation is not simply the safest or loudest option.

- Rationale references real candidate attributes without exposing hidden
  reasoning.

# 14. Phase 5 — Compare, Refine & Version

Goal: make design interaction controlled and trustworthy.

- Side-by-side concept comparison.

- Pin/lock garment or attribute.

- Natural-language and quick-control refinement.

- Change-delta computation.

- Immutable design versions with parent lineage.

- Undo/compare versions.

- Final design lock.

## Phase 5 Acceptance Gate

- 'Change trousers only' leaves shirt/jacket unchanged.

- 'More formal' changes relevant attributes coherently.

- Undo restores exact prior design version.

- Locked fields cannot be silently modified.

- Finalized design produces a stable hash/version ID.

# 15. Phase 6 — Visualization MVP

Goal: visualize the locked design without allowing the image model to
redesign it.

- Provider-neutral image adapter.

- Standard model/mannequin profile.

- Visualization compiler from locked design object.

- Front, back and detail views for MVP.

- Fabric/reference conditioning where supported.

- Validation metadata.

- Targeted repair path.

- Preview vs premium-final generation tiers.

## Phase 6 Acceptance Gate

- Front/back correspond to the same design version.

- Core collar/lapel/pleat/pocket/vent attributes remain consistent.

- Fabric color/pattern remains recognizably tied to upload.

- Same model/mannequin identity persists.

- A local defect can be repaired without intentionally changing
  unrelated approved regions.

- Failed validation is not labeled premium final.

# 16. Phase 7 — Premium Product UX

Goal: complete the Part 8 customer experience around the proven vertical
slice.

- Homepage and premium brand storytelling.

- Designer entry and progress states.

- Safe/Elevated/Statement result cards.

- Compare/refine experience.

- Garment/fabric explorers.

- Final multi-view presentation.

- Saved designs.

- Responsive mobile experience.

- Accessibility and performance pass.

## Phase 7 Acceptance Gate

- First-time user can complete the core flow without tailoring
  knowledge.

- Mobile fabric upload is usable.

- AI uncertainty is visible and editable.

- Design state is never lost during visual transitions.

- Core pages meet accessibility/performance targets agreed for launch.

# 17. Phase 8 — Store / Human Designer Handoff

- Consultation request tied to design_version_id.

- Staff/designer role view.

- Human pin/override workflow creating new versions.

- Optional inventory mapping: ideal vs available vs substitute.

- Customer-controlled sharing of private design data.

## Phase 8 Acceptance Gate

- Staff can open exactly the design the customer approved.

- Human edits do not mutate customer history.

- Inventory limitations are shown as substitutions, not disguised as
  ideal recommendations.

- Permissions prevent unrelated staff/customer access.

# 18. Phase 9 — Quality, Scale & Learning

- Admin Knowledge Studio.

- Golden fashion benchmark suite.

- Automated render consistency checks.

- Provider/model A/B evaluation.

- Cost and quality dashboards.

- Structured feedback/rejection labels.

- Preference-learning layer with confidence.

- Scale workers/retrieval only when measurements justify it.

## Phase 9 Acceptance Gate

- Model/provider change can be evaluated against fixed benchmarks.

- Quality regressions are visible before production rollout.

- User feedback changes ranking gradually rather than rewriting core
  rules.

- Cost per finalized design is measurable.

- Fashion expert overrides can feed curated improvement data.

# 19. First Vertical Slice to Build

Before attempting the entire roadmap, the coding agent should prove one
end-to-end path:

1\. Customer uploads a fabric.

2\. System extracts a structured fabric profile.

3\. Customer answers a short wedding/event context flow.

4\. Designer Engine produces 3 structured directions.

5\. Customer selects Elevated.

6\. Customer changes one trouser attribute.

7\. A new version is created without changing unrelated fields.

8\. System renders front/back/detail on one standard model.

9\. Customer saves the design and requests a consultation.

This vertical slice is the first meaningful product milestone.
Everything else expands breadth or quality.

# 20. Initial Scope Recommendation

| **Include first**                                | **Delay**                           |
|--------------------------------------------------|-------------------------------------|
| Shirts, trousers, jackets/suits                  | Huge garment catalogue              |
| Core linen/cotton/wool profiles                  | Rare material edge cases            |
| Wedding, business, resort, smart casual contexts | Every global dress-code niche       |
| 5-7 primary aesthetics                           | Dozens of aesthetic labels          |
| Solid/simple stripe/check fabrics                | Complex large motifs initially      |
| One neutral model/mannequin                      | Large model library                 |
| Front/back/detail views                          | Full turntable/3D                   |
| Human-reviewed rules                             | Autonomous learning from all clicks |

# 21. Minimum Seed Dataset

Quality is more important than count. A small curated dataset should be
used to establish correctness.

| **Dataset**         | **Launch-development target**                                                        |
|---------------------|--------------------------------------------------------------------------------------|
| Garment definitions | Representative families + key construction attributes                                |
| Fabric profiles     | Priority linen/cotton/wool and common blends/weaves                                  |
| Contexts            | Core wedding, business, resort, casual, evening cases                                |
| Aesthetics          | Quiet luxury, modern classic, Italian, British, resort, contemporary Indian, minimal |
| Pairing rules       | High-confidence color/material/pattern relationships                                 |
| Expert scenarios    | At least 20-50 reviewed design briefs                                                |
| Visual references   | Small owned/licensed annotated set                                                   |
| Render benchmarks   | Known garments with difficult details/patterns                                       |

# 22. AI Prompting Policy

- Prompts are implementation artifacts generated from structured state.

- Never encode the only copy of a business rule inside a prompt.

- Ask models for schema-constrained outputs.

- Provide retrieved relevant knowledge, not all nine specifications on
  every request.

- Store prompt/compiler version for reproducibility.

- Separate user-facing rationale generation from candidate scoring.

- Do not expose hidden chain-of-thought; expose concise reasons and
  tradeoffs.

# 23. Model Selection Policy

Do not select one permanent model/vendor in this master specification.
At implementation time, benchmark current providers against the task.

| **Task**             | **Selection criterion**                          |
|----------------------|--------------------------------------------------|
| Fabric vision        | Structured visual accuracy + confidence behavior |
| Brief interpretation | Schema adherence and context extraction          |
| Designer synthesis   | Fashion quality + structured output reliability  |
| Embeddings/retrieval | Relevant retrieval quality and cost              |
| Preview image        | Speed/cost with acceptable concept fidelity      |
| Final image          | Garment/fabric/reference fidelity                |
| Repair/edit          | Localized edit fidelity and preservation         |
| Moderation           | Appropriate safety coverage for user inputs      |

# 24. Human-in-the-Loop Policy

- Human review is required for initial seed knowledge.

- Human fashion experts approve golden test scenarios.

- Premium final visualization may include review during early launch.

- Designer overrides are recorded, not hidden.

- Do not automatically train on all user interactions.

- Only curated, rights-cleared examples enter improvement/training
  datasets.

# 25. Data & Rights Gate

- Every reference asset has rights_class and provenance.

- External web references are not automatically training assets.

- Customer uploads remain scoped to the customer's workflow unless
  product terms/consent explicitly support more.

- Original fabric uploads are immutable.

- Public catalogue assets and private customer assets use separate
  access controls.

- Before any custom-model training, perform a dedicated dataset-rights
  review.

# 26. Security Gate

- Server-side secrets only.

- Role-based authorization on private designs/assets.

- Signed/expiring private asset access.

- Upload type/size validation.

- Rate limits on AI/image endpoints.

- No raw private image logging by default.

- Deletion/retention workflows implemented before broad public launch.

- Dependencies and migrations reviewed in CI.

# 27. Performance & Cost Gate

- Do not block the entire UI on premium renders.

- Cache immutable knowledge and repeated analysis safely.

- Use preview generation before premium final.

- Set generation budgets/quotas appropriate to product stage.

- Measure latency per pipeline stage.

- Measure AI/image cost per completed design session and finalized
  design.

- Local repair preferred over complete regeneration where quality
  permits.

# 28. Fashion Quality Gate

| **Question**                  | **Required behavior**                                  |
|-------------------------------|--------------------------------------------------------|
| Is the garment constructible? | Fabric + construction pass feasibility rules           |
| Does it fit context?          | Occasion/climate/formality above threshold             |
| Is it coherent?               | Color/material/pattern/proportion scores pass          |
| Is it distinctive?            | Top candidates satisfy design-distance threshold       |
| Is it premium?                | Restraint/material/proportion/brand-fit standards pass |
| Can it be explained?          | Observable concise rationale exists                    |
| Can it be refined?            | Design deltas remain stable                            |
| Can it be visualized?         | Locked spec contains required render fields            |

# 29. Coding Agent — Required First Response

When this project is first handed to a coding agent, the agent should
not immediately generate the entire application. Its first task is to
audit the specification package and propose the Phase 0 implementation
plan.

You are implementing LLinen Earth.  
  
First:  
1. Read MASTER_BUILD_SPECIFICATION and Parts 1-9.  
2. Inspect the repository.  
3. Produce a concise architecture/implementation plan for Phase 0
only.  
4. Identify specification conflicts or missing blockers.  
5. List the exact files/modules you will create.  
6. List Phase 0 tests and acceptance checks.  
7. Do not implement later phases yet.  
  
After approval, implement Phase 0, run all tests/build checks,  
summarize changes, and stop for review.

# 30. Coding Agent — Phase Task Template

TASK: Implement Phase \<N\> — \<name\>.  
  
AUTHORITATIVE SPECS:  
- MASTER_BUILD_SPECIFICATION  
- Part \<relevant numbers\>  
  
CONSTRAINTS:  
- Do not implement future phases.  
- Preserve existing schemas unless migration is documented.  
- Do not replace deterministic rules with prompt-only logic.  
- Add tests for every acceptance criterion.  
- Use provider mocks in CI where external calls are
costly/non-deterministic.  
  
DELIVER:  
- implementation  
- migrations  
- tests  
- documentation updates  
- acceptance checklist  
- known limitations  
  
STOP when the phase gate passes. Do not proceed automatically.

# 31. Architecture Decision Records

Material deviations from Part 9 should be recorded in
ARCHITECTURE_DECISIONS.md or individual ADR files.

- Decision and date.

- Problem/context.

- Options considered.

- Chosen approach.

- Why it was chosen.

- Consequences/tradeoffs.

- Which specification sections are affected.

# 32. Implementation Status File

| **Field**              | **Example**                    |
|------------------------|--------------------------------|
| Current phase          | Phase 3 - Context Consultation |
| Status                 | in_progress                    |
| Completed gates        | 0, 1, 2                        |
| Open blockers          | None / listed                  |
| Schema version         | v0.4                           |
| Knowledge version      | KB-2026-09-01                  |
| Active providers       | Development configuration      |
| Last regression result | pass/fail + date               |

# 33. Release Strategy

1\. Internal prototype using curated test fabrics.

2\. Staff/design-team alpha.

3\. Small invited customer beta.

4\. Measure recommendation quality, refinement stability and render
consistency.

5\. Fix failure clusters before expanding garment/aesthetic breadth.

6\. Public MVP with constrained feature set.

7\. Expand only from measured demand and quality data.

# 34. Success Metrics

| **Category**  | **Metrics**                                                               |
|---------------|---------------------------------------------------------------------------|
| Product       | Designer starts, context completion, design selection, save rate          |
| Quality       | Expert approval, constraint pass, refinement stability                    |
| Visualization | First-pass acceptance, cross-view consistency, fabric fidelity            |
| Business      | Consultation requests, in-store continuation, fabric/tailoring conversion |
| Efficiency    | Time to first direction, time to final design, cost/finalized design      |
| Trust         | Correction rate, regenerate/reject reasons, support issues                |

# 35. What the Agent Must Never Do

- Build the entire roadmap in one unreviewed pass.

- Use generated image output as the canonical design record.

- Guess technical fabric facts with false certainty.

- Copy a reference design literally when the system should abstract
  attributes.

- Silently change unrelated garments during refinement.

- Store private uploads as public assets.

- Scrape arbitrary web imagery into a training dataset without rights
  review.

- Hard-code the entire system to one AI vendor.

- Hide failing tests or validation to make a milestone appear complete.

- Add complexity such as microservices or custom model training without
  a measured need.

# 36. Handoff Package Checklist

- MASTER_BUILD_SPECIFICATION_v1.docx or converted Markdown copy in
  /specs.

- All nine Part documents.

- Approved LLinen Earth logo/brand assets.

- Initial owned/licensed fashion/fabric references.

- Seed-data files derived from Parts 1-5.

- Golden test scenarios.

- Environment-variable template without secrets.

- Repository README.

- Architecture decisions/status files once implementation begins.

# 37. Recommended Immediate Action After This Document

Do not start by asking an agent to 'build LLinen Earth completely.'
Create the repository, place the specification package inside /specs,
and issue the Phase 0 audit task from Section 29. Once Phase 0 passes,
move through the gates sequentially. This keeps the project
understandable, testable and recoverable even when different coding
agents are used.

# 38. Final Product Principle

The competitive asset is not merely the website or the image model. It
is the combination of structured fashion knowledge, designer decision
logic, controlled visualization, premium interaction design and the
feedback/quality system around them. Implementation choices may evolve;
that product intelligence should remain portable.
