**LLINEN EARTH**

**Style & Aesthetic Intelligence System**

*Fashion Brain Specification — v1.0*

A rule-based aesthetic language that converts vague style labels into
measurable garment, proportion, color, material and styling decisions.

# 1. Purpose

This system gives the future LLinen Earth AI Designer taste and
consistency. It prevents labels such as 'quiet luxury' or 'Italian' from
becoming empty prompt words. Each aesthetic is represented as a weighted
profile of silhouette, structure, proportion, fabric, color, pattern,
detail, footwear and styling behavior.

- Treat aesthetics as design systems, not costumes.

- Allow controlled blending of compatible aesthetics.

- Adapt aesthetics to the wearer, fabric, occasion, climate and
  destination.

- Separate enduring style language from short-lived trends.

- Explain which attributes create the requested aesthetic.

# 2. Aesthetic Representation Model

| **Dimension**     | **What is encoded**                                                    |
|-------------------|------------------------------------------------------------------------|
| Silhouette        | Slim, tailored, straight, relaxed, oversized; upper/lower-body balance |
| Structure         | Soft, natural, moderate, architectural                                 |
| Proportion        | Jacket length, rise, trouser width, shirt volume, lapel scale          |
| Color behavior    | Tonal, neutral, earthy, saturated, high/low contrast                   |
| Material behavior | Matte/lustrous, refined/rustic, light/heavy, smooth/textured           |
| Pattern behavior  | Pattern families, scale, density and permitted mixing                  |
| Detail density    | Minimal, classic, expressive                                           |
| Formality range   | Contexts in which the aesthetic remains credible                       |
| Styling           | Tuck, roll, layering, footwear, accessories                            |
| Trend sensitivity | Timeless, adaptive, directional/editorial                              |

# 3. Core LLinen Earth Aesthetic Library

| **Aesthetic**       | **Core identity**                                      | **Typical signals**                                                     |
|---------------------|--------------------------------------------------------|-------------------------------------------------------------------------|
| Quiet luxury        | Material and fit lead; restrained visibility           | Tonal/neutral palette, excellent drape, low detail noise                |
| Modern classic      | Classic menswear corrected for contemporary proportion | Balanced tailoring, versatile neutrals, subtle updates                  |
| Italian-inspired    | Ease, softness and elegant nonchalance                 | Soft shoulder, fluid trouser, refined texture, expressive restraint     |
| British-inspired    | Structure, heritage and authority                      | Defined tailoring, heritage cloth/pattern, disciplined proportions      |
| Resort luxury       | Relaxed sophistication for warm leisure settings       | Linen, open texture, soft tailoring, light/earth palettes               |
| Contemporary Indian | Modern premium dressing informed by Indian context     | Climate-aware textiles, modern proportions, culturally suitable details |
| Minimal             | Reduction with precision                               | Clean lines, few colors, controlled details                             |
| Heritage            | Historic menswear vocabulary used intelligently        | Tweed/flannel/corduroy, checks, classic construction                    |
| Bold luxury         | One or two deliberate high-impact choices              | Rich color/pattern/scale balanced by premium restraint                  |
| Editorial           | Directional image-first fashion language               | Unusual proportion, styling or material relationships                   |
| Artisanal           | Craft, texture and material character                  | Natural irregularity, tactile surfaces, craft-led details               |

# 4. Quiet Luxury Profile

- Silhouette: tailored-relaxed; never visibly strained.

- Palette: cream, ecru, stone, navy, charcoal, tobacco, muted earths and
  sophisticated low-chroma color.

- Fabric: quality and tactile depth are central; matte or restrained
  sheen preferred.

- Pattern: solids, subtle stripes/checks, texture-as-pattern.

- Details: minimal visible branding; clean finishing; deliberate
  buttons, seams and proportions.

- Footwear: refined leather/suede, loafers or minimal footwear
  appropriate to context.

- Failure mode: simply making everything beige or expensive-looking.

# 5. Modern Classic Profile

- Use recognizable menswear forms with contemporary fit and proportion.

- Moderate lapels, clean collars, tailored trousers, restrained pattern.

- Avoid both extreme skinny-era proportions and trend-driven oversizing
  by default.

- Best as the baseline aesthetic when the user wants timeless
  versatility.

- Modernity can enter through trouser rise/width, softer construction,
  texture and color rather than novelty details.

# 6. Italian-Inspired Tailoring Profile

- Bias toward soft/natural shoulders and reduced visual stiffness.

- Allow higher-rise trousers with elegant drape and controlled fullness.

- Favor tactile, breathable materials and sophisticated color
  relationships.

- Styling may feel effortless, but construction and proportion remain
  precise.

- Avoid caricatures: excessively short jackets, extreme tightness or
  theatrical sprezzatura are not defaults.

# 7. British-Inspired Tailoring Profile

- More defined shoulder and architectural jacket line than the Italian
  profile.

- Heritage cloths, flannel, tweed, herringbone, checks and deeper
  seasonal palettes may increase.

- Trousers remain proportionally balanced with the jacket rather than
  excessively narrow.

- Best for authority, cool-weather tailoring and heritage-oriented
  contexts.

- Avoid turning heritage references into period costume.

# 8. Resort Luxury Profile

- Climate and movement are primary constraints.

- Use linen, cotton, open-weave tailoring and relaxed construction.

- Palette can include cream, sand, tobacco, muted blue, olive and
  selected coastal colors.

- Shirts can become softer and more open; jackets should remain
  believable without heavy business structure.

- Luxury comes from fabric, fit and restraint—not resort clichés.

# 9. Contemporary Indian Profile

- Start with climate, event and cultural setting rather than decorative
  motifs.

- Allow Indian and Indo-western garment vocabulary to coexist with
  modern tailoring.

- Use linen and other breathable natural-texture fabrics where
  appropriate.

- Color can be richer for festive contexts while retaining hierarchy.

- Avoid generic 'ethnic' styling; region, ceremony and user preference
  should guide the design.

# 10. Minimal / Heritage / Bold / Editorial / Artisanal

| **Profile** | **Rule**                                                                            |
|-------------|-------------------------------------------------------------------------------------|
| Minimal     | Reduce components but increase precision of proportion, fit and material.           |
| Heritage    | Use historical menswear cues selectively and modernize fit/context.                 |
| Bold luxury | One dominant statement; supporting pieces become quieter.                           |
| Editorial   | Permit higher novelty and lower everyday practicality only when explicitly desired. |
| Artisanal   | Surface, weave, irregularity and craft story become intentional design features.    |

# 11. Silhouette Intelligence

| **Silhouette** | **Aesthetic effect**                         | **Controls**                               |
|----------------|----------------------------------------------|--------------------------------------------|
| Slim           | Sharp/contemporary but can date quickly      | Ease, thigh/knee/hem, jacket suppression   |
| Tailored       | Balanced premium default                     | Controlled ease and clean line             |
| Straight       | Classic/modern depending proportion          | Consistent line, medium ease               |
| Relaxed        | Modern, resort, artisanal or fashion-forward | Drape, rise, width, shoulder ease          |
| Oversized      | Editorial/directional                        | Requires deliberate scale and body balance |

The AI must distinguish 'relaxed' from simply choosing a larger size.
Silhouette is constructed through proportion and ease.

# 12. Proportion Engine

| **Variable**         | **Why it matters**                                   |
|----------------------|------------------------------------------------------|
| Trouser rise         | Changes perceived leg length and tailoring character |
| Trouser width/hem    | Controls visual weight and shoe relationship         |
| Jacket length        | Balances torso/leg proportions                       |
| Lapel width          | Must relate to chest, shoulder and jacket language   |
| Button stance        | Changes torso proportions and formality              |
| Shirt volume         | Controls relaxed vs sharp appearance                 |
| Collar scale         | Must relate to face/neck, jacket lapel and aesthetic |
| Sleeve/cuff exposure | Small but important tailoring signal                 |

# 13. Styling Grammar

- Styling is stored separately from garment construction so one garment
  can support multiple looks.

- Examples: tucked vs untucked, sleeves rolled, jacket open/closed,
  trouser break, sock/no-show strategy, belt/no belt,
  scarf/pocket-square usage.

- The AI should never use styling tricks to hide an incoherent garment
  combination.

- Styling must remain plausible for the venue and climate.

# 14. Aesthetic Blending

| **Blend**                          | **Result**                                             |
|------------------------------------|--------------------------------------------------------|
| Quiet luxury + resort              | Natural textures, tonal palette, relaxed precision     |
| Modern classic + Italian           | Classic base with softer tailoring and richer texture  |
| Modern classic + British           | Structured timeless tailoring with controlled heritage |
| Contemporary Indian + artisanal    | Craft/material story with modern proportion            |
| Quiet luxury + contemporary Indian | Restrained premium festive/cultural dressing           |
| Minimal + editorial                | Reduced palette with directional silhouette            |

Default rule: one primary aesthetic, one secondary influence. A third
influence should be subtle and only added when it improves coherence.

# 15. Incompatible / High-Risk Blends

- British architectural tailoring + extreme resort looseness: choose a
  dominant structure.

- Quiet luxury + multiple loud logos/patterns: conflicts with the
  aesthetic definition.

- Minimal + high accessory density: reduce accessories or change
  aesthetic.

- Heritage + futuristic editorial: possible only as a deliberate
  concept, not an automatic blend.

- Ceremonial cultural context + arbitrary editorial experimentation:
  context constraints win.

# 16. Trend Intelligence

Trend data should modify an enduring aesthetic model, not replace it.
Store trends as time-stamped signals with region, category, adoption
stage and confidence.

| **Trend stage** | **AI behavior**                                            |
|-----------------|------------------------------------------------------------|
| Emerging        | Offer selectively in Statement/Editorial mode              |
| Growing         | Allow as an optional contemporary direction                |
| Mainstream      | Can influence Elevated mode                                |
| Mature          | Treat as established vocabulary                            |
| Declining       | Use only if personally suitable or intentionally nostalgic |
| Archive/revival | Interpret rather than copy literally                       |

# 17. Trend Adoption Filter

- Does the trend suit the user's requested aesthetic?

- Does it work with the actual fabric and garment category?

- Does it suit occasion and destination?

- Can it be adapted rather than copied literally?

- Will it still look intentional if the trend cools quickly?

- Is it regionally relevant to the customer/context?

# 18. Body & Fit Adaptation

Aesthetic identity should survive adaptation. The system changes
proportion and ease rather than declaring that a body 'cannot wear' a
style.

- Preserve the defining aesthetic signals while adjusting lengths,
  widths, rise and visual balance.

- Avoid rigid body-type stereotypes.

- Prioritize garment measurements and user fit preferences when
  available.

- For visualization, distinguish model/mannequin representation from
  actual made-to-measure fitting.

# 19. Age & Lifestyle Adaptation

Do not reduce style to age rules. Use the desired impression, lifestyle,
occasion and comfort level. 'Youthful' can mean cleaner proportions and
lighter styling; 'mature/refined' can mean nuanced color and
material—not simply darker or more conservative clothes.

# 20. Aesthetic Scoring

| **Score**                | **Question**                                              |
|--------------------------|-----------------------------------------------------------|
| Identity fidelity        | Does the design genuinely express the selected aesthetic? |
| Context fit              | Is the aesthetic adapted correctly to event/place/time?   |
| Fabric fit               | Does the material support the aesthetic?                  |
| Proportion coherence     | Do garment dimensions work together?                      |
| Color/material coherence | Does pairing reinforce the aesthetic?                     |
| Personal alignment       | Does it match desired impression/fit?                     |
| Originality              | Is it distinctive without losing identity?                |
| Brand fit                | Does it meet LLinen Earth premium standards?              |

# 21. Designer Direction Output

Each direction should be expressed as a structured design brief, not
only a mood-board sentence.

| **Field**  | **Example content**                                               |
|------------|-------------------------------------------------------------------|
| Aesthetic  | Quiet luxury + resort influence                                   |
| Silhouette | Tailored-relaxed                                                  |
| Structure  | Soft                                                              |
| Proportion | Higher-rise straight trouser; natural jacket length               |
| Palette    | Ecru, pale blue, tobacco                                          |
| Material   | Linen anchor + refined complementary texture                      |
| Pattern    | Solid/textural                                                    |
| Styling    | Open collar, minimal accessories, suede loafer                    |
| Reasoning  | Climate, wedding context and fabric all support relaxed precision |

# 22. Reference-Image Interpretation

- Extract attributes: silhouette, proportion, lapel/collar, pockets,
  closures, color relationships, pattern, texture and styling.

- Do not reduce a reference to a brand/designer name.

- Do not reproduce a protected designer look stitch-for-stitch; create
  an original design using abstracted attributes.

- Separate construction inspiration from pose, lighting and photography
  style.

- Store which attributes came from the reference and which were
  generated by the LLinen Earth system.

# 23. Aesthetic Visual Dataset

- For every aesthetic, curate owned/licensed examples across garments,
  seasons, formalities and body presentations.

- Include positive and negative examples with annotations explaining why
  they fit or fail the aesthetic.

- Use consistent front/side/back/detail reference views where the goal
  is garment understanding.

- Separate runway/editorial imagery from commercially wearable examples.

- Version the aesthetic labels because fashion language evolves.

# 24. Developer-Ready Aesthetic Object

{  
"primary": "quiet_luxury",  
"secondary": "resort_luxury",  
"weights": {"primary": 0.75, "secondary": 0.25},  
"silhouette": "tailored_relaxed",  
"structure": "soft",  
"proportion_profile": {  
"trouser_rise": "mid_high",  
"trouser_width": "straight_relaxed",  
"jacket_length": "classic",  
"lapel_scale": "medium"  
},  
"color_behavior": {"contrast": "low_medium", "saturation": "muted"},  
"material_behavior": \["natural", "matte", "textural"\],  
"pattern_behavior": {"density": "low", "scale": "subtle"},  
"detail_density": "low",  
"trend_tolerance": "adaptive",  
"styling_signals": \["open_collar", "minimal_accessories"\],  
"confidence": 0.93  
}

# 25. Aesthetic Knowledge Graph

Represent aesthetics as weighted relationships rather than fixed
templates. Nodes include garment attributes, colors, fabrics, contexts,
styling signals and trend signals. Edges encode strength, conditions,
conflicts, region, season and time validity. This lets the AI reason
about new combinations.

# 26. Quality-Control Checklist

| **Test**               | **Pass condition**                                      |
|------------------------|---------------------------------------------------------|
| Label integrity        | The output visibly matches the aesthetic definition     |
| No stereotype shortcut | Aesthetic is not reduced to one color/material cliché   |
| Proportion             | All garment dimensions form a coherent silhouette       |
| Context adaptation     | Aesthetic remains appropriate for venue/occasion        |
| Material realism       | Fabric supports proposed construction and drape         |
| Originality            | Reference inspiration is transformed, not copied        |
| Trend discipline       | Trend elements do not overwhelm long-term style         |
| Explainability         | System can identify the signals producing the aesthetic |

# 27. Connection to the Full System

This specification consumes garment, fabric, context and pairing data.
Its structured aesthetic profile becomes one of the main inputs to the
AI Designer Decision Engine, where all Fashion Brain layers will finally
be combined into ranked complete designs.

# 28. Next Specification

Next: AI Designer Logic & Decision Engine. This is the central
intelligence layer. It will define exactly how LLinen Earth combines
fabric analysis, garment construction, occasion, destination,
color/material pairing, aesthetics, user preferences and references to
produce, rank, explain and refine designer-level outfit concepts.
