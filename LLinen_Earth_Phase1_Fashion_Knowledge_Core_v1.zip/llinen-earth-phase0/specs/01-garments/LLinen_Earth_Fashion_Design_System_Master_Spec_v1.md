**LLINEN EARTH**

**FASHION DESIGN SYSTEM**

Master Design & AI Reference Specification — v1.0

**PANTS • SHIRTS • BLAZERS / JACKETS • SUITS**

Purpose: establish the structured fashion vocabulary that will later
power the LLinen Earth digital atelier, garment library, styling engine
and fabric-to-outfit AI.

# 1. Executive Direction

This document is the design foundation for the future LLinen Earth
website and AI designer. It is intentionally more detailed than a normal
fashion catalogue. The goal is to convert menswear knowledge into a
structured system that a designer, developer, 3D artist,
image-generation system or AI stylist can understand consistently.

The correct strategy is NOT to create four giant lists of garment names
and stop there. A professional system separates a garment into:
archetype + construction + silhouette + components + material + color +
proportion + occasion + climate + styling context + visual references.
This lets the future AI create new combinations rather than only
retrieve fixed outfits.

## The core principle

| **Wrong approach**                             | **LLinen Earth approach**                                                                                           |
|------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| “Linen shirt” is one product/style.            | Linen is a material attribute; shirt archetype and construction are separate attributes.                            |
| One front image per garment.                   | Standardized front, 45°, side, back and construction-detail views.                                                  |
| AI copies a reference image.                   | AI reads structured garment DNA and produces a controlled design.                                                   |
| Pants/shirts/suits are isolated.               | Every garment is connected through a compatibility and styling graph.                                               |
| Downloaded web images become the training set. | Use owned/licensed references for training; use web images primarily as inspiration/reference with rights recorded. |

## Target outcome

- Premium editorial fashion library.

- Searchable garment taxonomy.

- Visual comparison engine showing why two garments differ.

- Fabric analysis → garment recommendation → outfit generation.

- Occasion / destination / time / climate-aware styling.

- Human designer review and approval loop.

- Reusable data structure that a web developer can turn directly into
  database records and UI components.

# 2. LLinen Earth Fashion Intelligence Architecture

The future system should be designed as a layered knowledge graph. Do
not hard-code every possible outfit. Store the components and
relationships so the system can generate combinations.

| **Layer**         | **What it contains**                                                          | **Future use**               |
|-------------------|-------------------------------------------------------------------------------|------------------------------|
| Garment archetype | Oxford shirt, camp shirt, pleated trouser, blazer, tuxedo, etc.               | Primary catalogue and search |
| Construction      | Collar, cuff, placket, lapel, vent, waistband, pleat, pocket, yoke, hem, etc. | AI design control            |
| Fit / silhouette  | Slim, regular, relaxed, straight, tapered, wide, cropped, high-rise, etc.     | Proportion and visualization |
| Material          | Linen, wool, cotton, silk, blends, denim, etc.                                | Fabric suitability           |
| Color / pattern   | Hue, value, saturation, weave/pattern, contrast.                              | Color pairing and rendering  |
| Context           | Occasion, time, climate, destination, formality.                              | Styling decisions            |
| Aesthetic         | British, Italian, resort, contemporary Indian, heritage, minimalist, etc.     | Creative direction           |
| Visual evidence   | Front/side/back/detail references and metadata.                               | AI/3D/image reference        |
| Compatibility     | Garment-to-garment pairing scores/rules.                                      | Outfit recommendation        |
| Generation recipe | Prompt + constraints + negative constraints + seed/reference IDs.             | Consistent image generation  |

# 3. Universal Visual Reference Protocol

Every approved garment reference should be captured or selected under a
standardized protocol. Consistency is more valuable than having hundreds
of random fashion photographs.

## Required views

- Front full-body: neutral stance, garment unobstructed.

- Front 45°: shows depth, lapel/collar, pocket projection and drape.

- True side: shows rise, seat, jacket length, sleeve and leg profile.

- Back: shows yoke, vents, seat, pleats and rear construction.

- Construction detail 1: primary identity feature.

- Construction detail 2: secondary feature.

- Fabric macro: weave, texture, sheen and drape.

- Optional movement view: useful for linen, pleats, wide legs and
  relaxed silhouettes.

## Reference-image metadata

| **Field**       | **Required value**                                             |
|-----------------|----------------------------------------------------------------|
| Reference ID    | Unique stable ID, e.g. SH-CAMP-001                             |
| Garment family  | Shirt / Trouser / Jacket / Suit                                |
| Archetype       | Controlled vocabulary                                          |
| View            | Front / 45 / Side / Back / Detail / Macro                      |
| Source          | Owned / Licensed / Public-domain / Editorial reference         |
| Usage rights    | Internal reference / commercial / training permitted / unknown |
| Model/mannequin | Body specification and size if known                           |
| Camera          | Focal length, height, distance if known                        |
| Lighting        | Softbox / daylight / studio etc.                               |
| Background      | Neutral and standardized where possible                        |
| Confidence      | Verified / probable / uncertain                                |
| Notes           | Why this image is useful                                       |

## Mannequin/model standard

For the first catalogue, use one consistent neutral male mannequin or
digital model. Lock height, shoulder width, chest, waist, hip, inseam
and pose. The purpose is not to make every garment look like a fashion
campaign; it is to make construction differences visually comparable.

# 4. Universal Attribute Dictionary

| **Attribute** | **Controlled values / examples**                                                | **Why it matters**                   |
|---------------|---------------------------------------------------------------------------------|--------------------------------------|
| Formality     | Casual / smart-casual / business / formal / black tie / ceremonial              | Controls styling and recommendations |
| Fit           | Skinny / slim / tailored / regular / relaxed / oversized                        | Controls silhouette                  |
| Rise          | Low / mid / high / very high                                                    | Controls body proportion             |
| Length        | Cropped / ankle / regular / long                                                | Controls visual proportion           |
| Structure     | Soft / natural / structured / architectural                                     | Controls tailoring character         |
| Drape         | Crisp / moderate / soft / fluid                                                 | Critical for fabric suitability      |
| Weight        | Light / medium / heavy                                                          | Climate and silhouette               |
| Stretch       | None / low / medium / high                                                      | Comfort and construction             |
| Surface       | Matte / dry / brushed / lustrous / textured                                     | Visual material identity             |
| Season        | Spring / summer / autumn / winter / all-season                                  | Context                              |
| Climate       | Hot-humid / hot-dry / mild / cold / wet                                         | Fabric and styling                   |
| Occasion      | Office / wedding / resort / dinner / travel / party etc.                        | Recommendation engine                |
| Time          | Morning / afternoon / sunset / evening / night                                  | Color/material/formality             |
| Destination   | Beach / pool / lawn / hotel / restaurant / office / city / ceremony             | Contextual styling                   |
| Aesthetic     | Quiet luxury / Italian / British / resort / heritage / contemporary Indian etc. | Creative direction                   |
| Color         | Named color + RGB/HEX + HSL/OKLCH if available                                  | Generation consistency               |
| Pattern       | Solid / stripe / check / plaid / windowpane / pinstripe etc.                    | Pairing and generation               |

# 5. PANTS / TROUSERS — MASTER DESIGN SYSTEM

The pants catalogue should use archetypes plus construction attributes.
The 50-archetype list created earlier is the initial catalogue layer;
the system below is the deeper design specification.

## 5.1 Trouser archetype families

| **Family**         | **Archetypes**                                                                                                                                                                   |
|--------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Tailored / dress   | Flat-front, single-pleat, double-pleat, forward-pleat, reverse-pleat, high-waisted, Hollywood-waist, side-tab, cuffed, plain-hem, tapered, straight, wide-leg, pleated wide-leg. |
| Smart casual       | Chinos, khaki trousers, five-pocket trousers, corduroy trousers, linen trousers, drawstring tailored, elastic-waist tailored.                                                    |
| Denim              | Straight, slim, skinny, slim-taper, relaxed, loose/baggy, wide-leg, bootcut, flared.                                                                                             |
| Utility / workwear | Cargo, parachute, carpenter, painter, fatigue, hunting.                                                                                                                          |
| Athleisure         | Track pants, joggers, sweatpants.                                                                                                                                                |
| Heritage / global  | Gurkha, harem, dhoti-style, jodhpuri/breeches-style, churidar/sherwani trouser, sarouel/drop-crotch.                                                                             |

## 5.2 Trouser construction anatomy

- Waistband: width, construction, extension, curtain, internal waistband
  treatment.

- Waist adjustment: belt loops, side tabs, back adjuster, buckle,
  elastic, drawstring.

- Rise: low, mid, high, very high; record front rise and back rise when
  technical measurements are available.

- Front: flat, single pleat, double pleat, forward pleat, reverse pleat.

- Fly: zipper fly, button fly, concealed fly, extended closure.

- Front pockets: slant/slash, straight, frog-mouth, coin pocket, welt.

- Back pockets: welt, flap, buttoned, patch, none.

- Seat: close, regular, relaxed; note fullness and drape.

- Leg shape: straight, tapered, strong taper, wide, flared, carrot.

- Knee: straight, shaped, articulated, relaxed.

- Hem: plain, cuff/turn-up, raw, cropped, split hem.

- Break: no break, slight, medium, full; record relative to shoe.

- Pressing: center crease, double crease, no crease.

- Construction details: belt-loop placement, stitching, bar tacks,
  pocket bags, internal finish.

## 5.3 Trouser Design DNA

| **Dimension**       | **Example scale**                         |
|---------------------|-------------------------------------------|
| Formality           | 1 casual → 10 formal                      |
| Relaxation          | 1 fitted → 10 extremely relaxed           |
| Structure           | 1 fluid → 10 highly structured            |
| Volume              | 1 narrow → 10 very wide                   |
| Waist emphasis      | 1 low → 10 very high                      |
| Taper               | 1 none → 10 extreme                       |
| Heritage            | 1 contemporary → 10 heritage              |
| Resort suitability  | 1 low → 10 high                           |
| Climate suitability | record per climate, not a universal score |

## 5.4 Trouser AI decision rules

- High-temperature + breathable fabric → prioritize linen/cotton/light
  wool silhouettes and avoid unnecessary heavy construction.

- Very soft/fluid fabric + very slim silhouette → flag as a potential
  drape conflict unless intentionally designed.

- Wide-leg trouser → evaluate rise, hem width and footwear together; do
  not recommend footwear independently.

- Pleated trouser → assess waistband, rise and upper-thigh volume as one
  system.

- Formal trouser → preserve cleaner pocketing, controlled break and
  appropriate waistband finish.

- Resort trouser → allow relaxed waist treatments, lighter materials and
  more movement while preserving intentional proportion.

# 6. SHIRTS — MASTER DESIGN SYSTEM

## 6.1 Shirt archetype families

| **Family**             | **Archetypes**                                                                                                  |
|------------------------|-----------------------------------------------------------------------------------------------------------------|
| Formal                 | Dress shirt, tuxedo shirt, banker shirt, bib/pleated-front formal shirt, wing-collar formal shirt.              |
| Classic / smart        | Oxford button-down, point-collar shirt, spread-collar shirt, poplin shirt, twill shirt, classic button-up.      |
| Casual / resort        | Camp-collar, Cuban-collar, resort shirt, bowling shirt, Hawaiian shirt, open-collar shirt, short-sleeve casual. |
| Heritage / work        | Western shirt, work shirt, chore shirt, safari shirt, utility shirt, military-inspired shirt.                   |
| Relaxed / contemporary | Overshirt, shacket, popover, band-collar, grandad shirt, tunic-inspired shirt.                                  |
| Fabric-led             | Linen shirt, chambray, denim, flannel, seersucker, corduroy, silk/blend, brushed cotton.                        |

## 6.2 Collar taxonomy

| **Collar**                       | **Design notes**                                                                                   |
|----------------------------------|----------------------------------------------------------------------------------------------------|
| Point                            | Narrow/medium point; classic dress character; works with tie or without depending on stand/length. |
| Semi-spread                      | Balanced, versatile; useful bridge between classic and contemporary.                               |
| Spread                           | Wider points; works well with ties and structured tailoring.                                       |
| Wide / cutaway                   | Strong horizontal line; useful with larger knots and modern tailoring.                             |
| Button-down                      | Points secured by buttons; casual-to-smart depending on construction.                              |
| Hidden button-down               | Button support hidden; cleaner than visible button-down.                                           |
| Tab                              | Tab draws points together; tailored, vintage and tie-friendly.                                     |
| Pin                              | Pin holds collar points; formal/heritage character.                                                |
| Club                             | Rounded points; retro identity.                                                                    |
| Band / grandad                   | Minimal collar; modern/relaxed and visually clean.                                                 |
| Mandarin / Nehru                 | Standing collar; strong Indian and contemporary formal applications.                               |
| Camp / Cuban                     | Open, soft collar with short points; resort identity.                                              |
| Wing                             | Formal black-tie collar.                                                                           |
| One-piece / collar-attached body | Integrated collar construction; soft Italian-inspired character.                                   |

## 6.3 Cuff taxonomy

| **Cuff**                     | **Design notes**                                               |
|------------------------------|----------------------------------------------------------------|
| Single-button barrel         | Universal everyday cuff.                                       |
| Two-button barrel            | More adjustability and visual detail.                          |
| Three-button                 | Less common; deliberate styling statement.                     |
| Rounded barrel               | Softer classic finish.                                         |
| Angled barrel                | Sharper tailoring character.                                   |
| French cuff                  | Formal; requires cufflinks.                                    |
| Convertible                  | Can be worn with button or cufflink depending on construction. |
| Turnback / cocktail-inspired | Fashion-forward formal/cocktail detail.                        |

## 6.4 Placket taxonomy

- Standard front placket

- French placket / clean front

- Fly-front / concealed buttons

- Half placket / popover

- Continuous sleeve-style placket

- Covered placket

- Buttonless/open placket

- Decorative or contrast placket

## 6.5 Shirt body, yoke, back and pocket

| **Component** | **Variations**                                                                |
|---------------|-------------------------------------------------------------------------------|
| Yoke          | Single, split, western, shaped, extended, integrated/alternative construction |
| Back          | Plain, center box pleat, side pleats, darts, gathers, western detailing       |
| Pocket        | None, patch, flap, buttoned, pleated, utility, double chest                   |
| Hem           | Straight/box, curved shirttail, split hem, high-low                           |
| Sleeve        | Long, short, rolled, tabbed, 3/4, cuffed                                      |
| Side seam     | Straight, shaped, gusseted, vented                                            |
| Body fit      | Slim, tailored, regular, relaxed, oversized                                   |

## 6.6 Shirt proportion controls

- Collar size and point length should scale with body and jacket lapel;
  avoid visually tiny collars under broad lapels.

- Shirt length must work both tucked and untucked depending on
  archetype.

- Shoulder seam position strongly changes perceived fit.

- Sleeve width and cuff circumference determine whether the shirt reads
  formal, relaxed or fashion-forward.

- Pocket scale should be proportional to chest and shirt volume.

- Open-collar shirts need controlled collar spread and stand so the
  collar does not collapse unpredictably in generation.

- Short-sleeve shirts require sleeve length and opening width to be
  encoded because they dramatically affect the silhouette.

# 7. BLAZERS / JACKETS — MASTER DESIGN SYSTEM

## 7.1 Jacket archetype families

| **Family**             | **Archetypes**                                                                             |
|------------------------|--------------------------------------------------------------------------------------------|
| Tailored               | Single-breasted blazer, double-breasted blazer, sport coat, dinner jacket, smoking jacket. |
| Formal / evening       | Tuxedo jacket, shawl-collar dinner jacket, peak-lapel dinner jacket.                       |
| Heritage / utility     | Safari jacket, field jacket, chore jacket, military-inspired jacket, utility jacket.       |
| Contemporary casual    | Harrington, bomber, overshirt jacket, shacket, work jacket.                                |
| Indian / modern formal | Nehru/Bandhgala-inspired jacket, contemporary structured ethnic-fusion jacket.             |

## 7.2 Lapel taxonomy

| **Lapel** | **Visual character**                                             | **Typical use**                                |
|-----------|------------------------------------------------------------------|------------------------------------------------|
| Notch     | Versatile; notch creates a broken V at collar/lapel junction.    | Business, blazer, sport coat                   |
| Peak      | Sharp upward points; stronger and more formal.                   | Formal tailoring, evening, statement tailoring |
| Shawl     | Continuous curved lapel.                                         | Tuxedo/dinner, evening                         |
| Gorge     | The collar/lapel junction position and angle; encode separately. | Changes perceived proportions and era.         |

## 7.3 Jacket construction controls

- Button stance: one-button, two-button, three-button, three-roll-two,
  double-breasted configurations.

- Breast pocket: welt, patch, none/hidden.

- Front pockets: flap, patch, jetted, slanted, ticket pocket.

- Vent: no vent, center vent, double vents.

- Shoulder: natural, soft, structured, roped, extended.

- Chest: clean, draped, shaped, full, suppressed.

- Waist suppression: none, mild, medium, strong.

- Jacket length: cropped, modern, classic, long; encode against body
  proportions.

- Sleeve head: natural, roped, structured.

- Sleeve cuff: surgeon cuff, faux button, kissing buttons, working cuff.

- Canvas/interlining: fused, half canvas, full canvas where verified; do
  not infer construction from appearance with high confidence.

- Lining: full, half, unlined; material and color.

- Back: vent configuration, shaping, action pleats where relevant.

## 7.4 Jacket visual hierarchy

When the AI generates a jacket, the priority order should normally be:
silhouette → lapel → shoulder → button stance → length → pocket
arrangement → vent → fabric → small details. This prevents decorative
details from overpowering the garment's fundamental identity.

# 8. SUITS — MASTER DESIGN SYSTEM

## 8.1 Suit archetypes

| **Archetype**                         | **Definition**                                                                                         |
|---------------------------------------|--------------------------------------------------------------------------------------------------------|
| Two-piece                             | Jacket + trouser; broadest category.                                                                   |
| Three-piece                           | Jacket + waistcoat/vest + trouser.                                                                     |
| Single-breasted suit                  | One column of buttons; notch/peak lapel options.                                                       |
| Double-breasted suit                  | Overlapping fronts; multiple button configurations.                                                    |
| Business suit                         | Conservative tailoring, controlled pattern and formality.                                              |
| Lounge suit                           | General tailored suit category; can range from formal to smart.                                        |
| Dinner suit / tuxedo                  | Evening formal; shawl/notch/peak lapel and formal detailing.                                           |
| Summer suit                           | Lightweight construction/materials; linen, cotton, tropical wool, blends.                              |
| Travel suit                           | Comfort, resilience and movement are prioritized.                                                      |
| Wedding / ceremonial suit             | More expressive fabric, color, texture and accessories while maintaining formal proportion.            |
| Bandhgala / Nehru-inspired formal set | Indian formal direction; treat as a distinct jacket system rather than simply renaming a Western suit. |

## 8.2 Suit system: jacket + trouser compatibility

A suit must be stored as a coordinated system. The trouser cannot be
generated as a random trouser simply because the jacket looks correct.
The database should record whether the trouser is the matching garment,
a coordinating separate, or a stylistic substitute.

| **Relationship**    | **Example**                                                                | **AI rule**                                      |
|---------------------|----------------------------------------------------------------------------|--------------------------------------------------|
| Matching suit       | Same cloth, same dye lot/approved digital color, coordinated construction. | Highest compatibility.                           |
| Tonally coordinated | Different garment but controlled color/value/texture relationship.         | Allowed when user requests separates.            |
| Contrast tailoring  | Intentional contrast jacket/trouser.                                       | Require stronger styling confidence.             |
| Formal substitution | Suit jacket paired with another formal trouser.                            | Only when silhouette/formality remains coherent. |

## 8.3 Three-piece suit details

- Waistcoat: single-breasted or double-breasted.

- Waistcoat neckline: V depth, lapel/no lapel, shawl/peak/notch where
  applicable.

- Waistcoat length: should cover trouser waistband in a traditional
  formal configuration.

- Waistcoat pockets: welt, jetted, flap variations.

- Back: matching fabric or lining depending on construction.

- Trousers: record whether they use belt loops, side tabs, braces
  buttons, pleats, cuffs and rise.

# 9. FIT, PROPORTION & SILHOUETTE ENGINE

The future AI must not treat fit words as interchangeable. 'Slim',
'tailored', 'regular' and 'relaxed' describe relationships between
garment and body, while 'wide-leg', 'tapered' and 'straight' describe
shape through a garment section.

| **Term**  | **System meaning**                                     |
|-----------|--------------------------------------------------------|
| Slim      | Close body relationship; reduced ease.                 |
| Tailored  | Intentional shaping, not necessarily tight.            |
| Regular   | Balanced ease and conventional proportions.            |
| Relaxed   | More ease through one or more body zones.              |
| Oversized | Deliberately exceeds conventional ease and proportion. |
| Straight  | Leg/body section has relatively consistent width.      |
| Tapered   | Narrows toward hem/wrist.                              |
| Wide-leg  | Leg opening and lower leg have high volume.            |
| Cropped   | Length is intentionally shortened.                     |
| High-rise | Waist sits higher on torso.                            |
| Low-rise  | Waist sits lower on torso.                             |

## Proportion checks

- Head-to-body scale must remain consistent across generated looks.

- Jacket length and trouser rise jointly determine perceived leg length.

- Lapel width should be proportionally compatible with shoulder/chest
  scale.

- Trouser width should be evaluated with shoe volume.

- Shirt collar and jacket lapel should form a deliberate visual
  relationship.

- Very relaxed shirt + very slim trouser should only be generated when
  the contrast is intentional.

- Wide trouser + cropped jacket can be a deliberate fashion proportion;
  it should not be treated as an error automatically.

# 10. FABRIC INTELLIGENCE LAYER

The fabric-upload feature should eventually classify material properties
rather than relying only on color.

| **Fabric property** | **What the AI should estimate**                  | **Design impact**                |
|---------------------|--------------------------------------------------|----------------------------------|
| Fiber family        | Linen / cotton / wool / silk / synthetic / blend | Breathability, hand, drape, care |
| Weight              | Light / medium / heavy                           | Silhouette and climate           |
| Drape               | Crisp / soft / fluid / structured                | Fit and garment archetype        |
| Texture             | Smooth / slub / brushed / crisp / nubby          | Visual identity                  |
| Sheen               | Matte / low / medium / high                      | Formality and lighting           |
| Stretch             | None / low / medium / high                       | Fit and comfort                  |
| Opacity             | Opaque / semi-sheer / sheer                      | Shirt and lining decisions       |
| Wrinkle behavior    | Low / moderate / high                            | Travel/resort suitability        |
| Pattern             | Solid / stripe / check / plaid / jacquard etc.   | Scale and pairing                |
| Color               | Primary + secondary undertone                    | Styling                          |

## Fabric-to-garment decision sequence

1.  Detect visible color and undertone.

2.  Estimate material family and confidence.

3.  Estimate weight, texture and drape.

4.  Determine climate suitability.

5.  Generate a shortlist of suitable garment archetypes.

6.  Reject technically/visually incompatible archetypes.

7.  Ask occasion/context questions.

8.  Generate 3–5 design directions.

9.  Allow user to select or edit one direction.

10. Generate model/mannequin visualization.

11. Offer compatible trousers/shirts/jackets/accessories.

12. Store the final approved design as a reusable LLinen Earth design
    record.

# 11. OCCASION / TIME / DESTINATION ENGINE

| **Context**      | **Examples**                                                         | **What it changes**             |
|------------------|----------------------------------------------------------------------|---------------------------------|
| Occasion         | Office, boardroom, wedding, reception, dinner, resort, party, travel | Formality, silhouette, fabric   |
| Time             | Morning, afternoon, golden hour, evening, night                      | Color, sheen, layering          |
| Destination      | Beach, pool, lawn, hotel, restaurant, city, mountain                 | Material, footwear, layers      |
| Climate          | Hot-humid, hot-dry, mild, cold, wet                                  | Weight, breathability, layering |
| Dress code       | Casual, smart-casual, business, cocktail, formal, black tie          | Garment boundaries              |
| Movement         | Standing, walking, travel, seated, active                            | Ease and construction           |
| Cultural context | Indian wedding, western formal, destination resort, etc.             | Appropriateness and styling     |

## Questionnaire design

Do not interrogate the user with 15 questions before producing anything.
Ask the minimum questions needed, infer the rest with transparent
assumptions, and let the user edit them.

Recommended first screen: What are you making? Where will you wear it?
When? What kind of mood? Optional: body/fit preference, budget/quality
level, and whether the user wants classic or experimental.

## Example

User: “I uploaded a beige linen. Make me something for a hotel dinner in
Goa.”

System interpretation: warm climate + evening + luxury hospitality +
relaxed but polished + natural texture + destination context. Candidate
directions could include a camp-collar shirt, relaxed tailored shirt or
lightweight blazer depending on the requested formality.

# 12. AI DESIGNER — FUTURE PRODUCT SPECIFICATION

## 12.1 End-to-end workflow

13. Upload: User uploads one or more fabric images.

14. Vision analysis: Detect color, texture, weave, weight/drape clues,
    pattern and confidence.

15. Clarification: Ask only high-value questions: garment, occasion,
    time, destination, formality, aesthetic.

16. Design synthesis: Select compatible archetype + construction
    attributes.

17. Styling: Select complementary garments using compatibility rules.

18. Visual generation: Generate consistent mannequin/model with exact
    garment specification.

19. Critique: AI explains the design and identifies trade-offs.

20. Variations: Generate controlled variations: collar, fit, trouser,
    color contrast, formality.

21. Approval: User chooses final direction.

22. Record: Save fabric ID + design DNA + prompt + references + output +
    user edits.

## 12.2 Generation prompt structure

The eventual image-generation prompt should be assembled from structured
fields rather than handwritten each time.

| **Prompt block**     | **Example**                                                                               |
|----------------------|-------------------------------------------------------------------------------------------|
| Subject              | Adult male fashion mannequin, neutral pose                                                |
| Garment              | Relaxed long-sleeve linen camp-collar shirt                                               |
| Construction         | Open camp collar, French placket, rounded cuffs, no chest pocket, curved hem              |
| Fit                  | Relaxed tailored fit, moderate ease                                                       |
| Material             | Lightweight natural linen, visible slub, matte surface                                    |
| Color                | Muted olive green, warm undertone                                                         |
| Pairing              | Cream high-rise double-pleat wide-leg trousers, side tabs                                 |
| Context              | Luxury hotel dinner, warm evening                                                         |
| Photography          | Editorial menswear studio photography, neutral full-body view                             |
| Consistency          | Same mannequin proportions as reference set                                               |
| Negative constraints | No extra pockets, no tie, no denim, no logos, no distorted hands, no inconsistent buttons |

## 12.3 Human designer layer

For premium results, the AI should be positioned as an assistant to a
design system, not as an uncontrolled autonomous designer. A human can
approve archetypes, construction combinations, fabric suitability rules
and brand aesthetics. This creates LLinen Earth's own design language
over time.

# 13. DATABASE / DATA MODEL FOR THE DEVELOPER

This section is deliberately technical because it should later become
the handoff document for the web developer.

| **Entity**            | **Important fields**                                                                                    |
|-----------------------|---------------------------------------------------------------------------------------------------------|
| Garment               | id, family, archetype, description, formality, fit, season, climate, aesthetic_tags                     |
| ConstructionComponent | id, category, name, description, compatible_families, image_refs                                        |
| GarmentConstruction   | garment_id, collar_id, cuff_id, placket_id, pocket_id, yoke_id, vent_id, lapel_id, waistband_id, hem_id |
| Material              | id, fiber, blend, weight, drape, texture, sheen, stretch, opacity, climate_tags                         |
| Color                 | id, name, hex, RGB, undertone, value, saturation, season_tags                                           |
| Context               | occasion, time, destination, climate, dress_code, movement                                              |
| ReferenceImage        | id, garment_id, view, url/source, rights, photographer, license, metadata                               |
| Design                | id, user_id, fabric_id, garment_spec, context, prompt_version, output_refs, approval_state              |
| CompatibilityRule     | from_component, to_component, score, reason, constraints                                                |
| GenerationRecipe      | version, model, prompt_template, negative_prompt, parameters, reference_ids                             |
| Feedback              | design_id, rating, edits, accepted/rejected, reason                                                     |

## Stable IDs

Use stable IDs from the beginning. Examples: PNT-WIDE-001, SH-CAMP-001,
SH-COLLAR-SPREAD-001, JKT-SB-001, LAPEL-PEAK-001, SUIT-3PC-001. Names
can change in the UI; IDs should not.

## Versioning

Every AI generation should store the taxonomy version, prompt version
and model/version used. Otherwise, when the system improves, you will
not know why an old design looked different from a new one.

# 14. RECOMMENDATION / COMPATIBILITY ENGINE

Use a hybrid system: hard rules for obvious incompatibilities and
weighted scoring for style preference.

| **Score factor**        | **Suggested weight** | **Example**                                                                                          |
|-------------------------|----------------------|------------------------------------------------------------------------------------------------------|
| Formality compatibility | 20%                  | Black-tie tuxedo should not pair with casual cargo trousers.                                         |
| Silhouette/proportion   | 20%                  | Wide trouser + relaxed shirt needs controlled overall volume.                                        |
| Color harmony           | 20%                  | Value and undertone compatibility.                                                                   |
| Material harmony        | 15%                  | Linen with lightweight cotton/wool can work; heavy winter flannel with beach linen usually does not. |
| Context suitability     | 15%                  | Beach vs boardroom.                                                                                  |
| Aesthetic coherence     | 10%                  | British tailoring vs resort minimalism.                                                              |

These weights are starting points, not permanent truths. Store them as
configurable rules so the LLinen Earth team can tune the system from
user feedback.

# 15. “WHY IS THIS GARMENT DIFFERENT?” COMPARISON MODE

This feature should be a core part of the library because it teaches the
customer and simultaneously creates training data for the future AI.

| **Comparison dimension** | **Example explanation**                                                              |
|--------------------------|--------------------------------------------------------------------------------------|
| Rise                     | Pant A sits higher on the natural waist than Pant B.                                 |
| Front                    | Pant A has two forward pleats; Pant B is flat-front.                                 |
| Leg                      | Pant A remains wide through the ankle; Pant B tapers.                                |
| Waist                    | Pant A uses side tabs; Pant B uses belt loops.                                       |
| Hem                      | Pant A has a turn-up; Pant B has a plain hem.                                        |
| Drape                    | Fabric A creates softer vertical folds; Fabric B holds a crisper crease.             |
| Formality                | The combination of clean waistband, crease and controlled break makes A more formal. |

The UI can show the two garments side-by-side with highlighted callouts.
Each callout should map to a database attribute.

# 16. IMAGE RIGHTS & REFERENCE POLICY

For a commercial LLinen Earth product, visual reference management must
be treated as a first-class system.

- Maintain source URL and rights status for every reference.

- Separate inspiration/reference images from images licensed for
  commercial use.

- Do not assume that an image being publicly visible means it is free to
  train on or redistribute.

- For model training/fine-tuning, prioritize LLinen Earth-owned or
  appropriately licensed data.

- For the public website, use owned/licensed/generated imagery unless
  the license clearly permits the intended use.

- Keep a takedown/replacement process and source ledger.

# 17. QUALITY CONTROL / APPROVAL CHECKLIST

| **Check**         | **Pass condition**                                                |
|-------------------|-------------------------------------------------------------------|
| Taxonomy          | Garment has a stable archetype and attributes.                    |
| Construction      | All visible defining components are tagged.                       |
| Visual references | Front/45/side/back/detail available or explicitly marked missing. |
| Rights            | Source and usage status recorded.                                 |
| Fit               | Fit and silhouette terms are not contradictory.                   |
| Fabric            | Material properties have confidence levels.                       |
| Context           | Occasion/climate suitability is documented.                       |
| Generation        | Prompt recipe produces consistent construction.                   |
| Brand fit         | Design fits LLinen Earth aesthetic.                               |
| Human approval    | Premium/brand-defining combinations reviewed by a human.          |

## Confidence levels

- High: directly verified from construction reference/specification.

- Medium: visually probable but not technically confirmed.

- Low: inferred from appearance; do not use as a hard rule.

# 18. FUTURE WEBSITE INFORMATION ARCHITECTURE

| **Page / module**  | **Purpose**                                                    |
|--------------------|----------------------------------------------------------------|
| Cinematic Entry    | Black → navy reveal → LLinen Earth identity.                   |
| Home / Atelier     | Introduce the concept and direct users into Explore or Design. |
| Explore            | Browse shirts, trousers, jackets, suits.                       |
| Garment Detail     | Views, construction, DNA, history/use, comparisons.            |
| Compare            | Compare two garments with visual callouts.                     |
| Design Studio      | Upload fabric and start AI designer.                           |
| Fabric Analysis    | Show detected properties and confidence.                       |
| Design Brief       | Occasion/time/destination/aesthetic questions.                 |
| Concept Board      | 3–5 generated design directions.                               |
| Look Generator     | Complete outfit generation.                                    |
| Saved Designs      | Store approved concepts.                                       |
| Admin / Design Lab | Manage taxonomy, references, rules and approved designs.       |

# 19. BUILD ROADMAP — RECOMMENDED

| **Phase**                         | **Work**                                                                                          |
|-----------------------------------|---------------------------------------------------------------------------------------------------|
| Phase 0 — Foundation              | Finalize taxonomy, attribute dictionary, image standard, rights policy, brand visual system.      |
| Phase 1 — Static luxury prototype | Build cinematic landing, Explore, garment detail, Compare, using curated reference data.          |
| Phase 2 — Database                | Move taxonomy into structured DB/CMS; admin interface for adding/editing garments.                |
| Phase 3 — AI styling              | Implement context questionnaire + rules + recommendations before image generation.                |
| Phase 4 — Fabric vision           | Add fabric upload and property analysis.                                                          |
| Phase 5 — Image generation        | Generate controlled garment visualizations from structured design specs.                          |
| Phase 6 — Feedback loop           | Save accepted/rejected designs and use feedback to tune compatibility rules.                      |
| Phase 7 — Commercial integration  | Connect tailoring enquiry, fabric/product inventory, customer profiles, quotation/order workflow. |

## What NOT to build first

- Do not start by training a custom AI model.

- Do not build hundreds of ecommerce product pages before the taxonomy
  works.

- Do not collect thousands of random Pinterest/Google images without
  rights metadata.

- Do not create a 3D garment simulator before you know which garment
  attributes actually matter to users.

- Do not generate every possible outfit combination; use a structured
  recommendation engine.

# 20. RECOMMENDED CLAUDE / DEVELOPMENT WORKFLOW

For the implementation stage, the best approach is to give the
developer/Claude a specification package rather than a vague instruction
such as “build a luxury fashion website.”

| **Deliverable to hand developer** | **Why**                                                           |
|-----------------------------------|-------------------------------------------------------------------|
| This master design document       | Defines fashion vocabulary and AI requirements.                   |
| Taxonomy JSON/CSV                 | Machine-readable garment records.                                 |
| Reference-image manifest          | Connects each garment to approved views and rights.               |
| Design tokens                     | Navy, ivory, typography, spacing, border/radius, animation rules. |
| Wireframes                        | Prevents design drift.                                            |
| Prompt templates                  | Makes generation repeatable.                                      |
| Compatibility rules               | Gives the recommendation engine deterministic logic.              |
| Acceptance checklist              | Defines what “premium” means technically and visually.            |

Recommended working pattern: prototype the UI quickly in Claude, then
move the approved prototype into a real GitHub codebase with a
production framework and proper database/API architecture. Keep the
fashion taxonomy independent from the UI so the website can evolve
without rewriting the design knowledge.

# 21. INITIAL SCOPE TARGETS

| **Domain**               | **Initial target** | **Notes**                                                                                         |
|--------------------------|--------------------|---------------------------------------------------------------------------------------------------|
| Pants / trousers         | 50 archetypes      | Already catalogued at v1; expand only when a new silhouette/construction is materially different. |
| Shirt archetypes         | 40–50              | Separate archetype from construction components.                                                  |
| Shirt components         | 100+               | Collars, cuffs, plackets, yokes, pockets, sleeves, hems, etc.                                     |
| Blazer/jacket archetypes | 30–40              | Tailored + utility + contemporary + Indian formal.                                                |
| Jacket components        | 80+                | Lapels, vents, pockets, shoulders, stance, cuffs, lining, canvas, etc.                            |
| Suit archetypes          | 20–30              | Use suit system + jacket/trouser construction.                                                    |
| Materials                | 50–100 families    | Prioritize fabrics relevant to LLinen Earth and Indian climate.                                   |
| Occasions                | 30–50              | Build practical context categories.                                                               |
| Aesthetics               | 20–30              | Keep controlled and distinct.                                                                     |

These are working targets, not a requirement to reach a specific number.
A taxonomy should stop growing when additional entries are only synonyms
or tiny variations.

# 22. FULL DESIGN RECORD EXAMPLES

## Example A — Resort linen shirt

| **Field** | **Value**                                  |
|-----------|--------------------------------------------|
| ID        | SH-RESORT-001                              |
| Archetype | Camp-collar resort shirt                   |
| Fabric    | Lightweight linen                          |
| Color     | Warm ivory                                 |
| Fit       | Relaxed                                    |
| Collar    | Camp/Cuban                                 |
| Placket   | Open/French                                |
| Pocket    | None                                       |
| Sleeve    | Long                                       |
| Cuff      | Rounded barrel                             |
| Back      | Plain                                      |
| Hem       | Curved                                     |
| Context   | Luxury resort dinner, warm evening         |
| Pairing   | Tobacco or olive high-rise pleated trouser |
| Aesthetic | Quiet resort luxury                        |

## Example B — Tailored trouser

| **Field** | **Value**                                             |
|-----------|-------------------------------------------------------|
| ID        | PNT-WIDE-014                                          |
| Archetype | High-rise pleated wide-leg trouser                    |
| Waist     | Side tabs                                             |
| Front     | Double pleat                                          |
| Rise      | High                                                  |
| Leg       | Wide, controlled straight                             |
| Hem       | Plain                                                 |
| Crease    | Single center crease                                  |
| Fabric    | Tropical wool / linen blend                           |
| Context   | Summer wedding / hotel dinner                         |
| Pairing   | Camp shirt, spread-collar shirt or lightweight blazer |
| Aesthetic | Modern Italian tailoring                              |

## Example C — Blazer

| **Field** | **Value**                                  |
|-----------|--------------------------------------------|
| ID        | JKT-SB-007                                 |
| Archetype | Soft single-breasted blazer                |
| Closure   | Two-button                                 |
| Lapel     | Medium-width notch                         |
| Shoulder  | Natural/soft                               |
| Pocket    | Patch                                      |
| Vent      | Double                                     |
| Canvas    | Unknown unless verified                    |
| Fit       | Tailored                                   |
| Fabric    | Textured lightweight wool                  |
| Context   | Smart-casual hotel / dinner                |
| Pairing   | White linen shirt + taupe tailored trouser |

## Example D — Suit

| **Field** | **Value**                      |
|-----------|--------------------------------|
| ID        | SUIT-3PC-003                   |
| Archetype | Three-piece tailored suit      |
| Jacket    | Single-breasted, peak lapel    |
| Waistcoat | Single-breasted V-neck         |
| Trouser   | High-rise, side-tab, plain hem |
| Fit       | Tailored                       |
| Fabric    | Midweight wool                 |
| Context   | Wedding evening                |
| Aesthetic | Modern classic                 |

# 23. FINAL DESIGN PRINCIPLES FOR LLINEN EARTH

- Build a fashion knowledge system first; build the website second.

- Separate archetype from construction components.

- Use standardized visual references so differences are obvious.

- Use stable IDs and version everything.

- Treat fabric as a set of physical/visual properties, not only a color
  photograph.

- Ask users only high-value contextual questions.

- Use hard compatibility rules plus weighted style scoring.

- Generate complete looks only after garment design is defined.

- Explain why a recommendation was made.

- Keep the AI's design vocabulary controlled by LLinen Earth's approved
  taxonomy.

- Use owned/licensed visual data for commercial AI training and
  generated/public imagery where rights are clear.

- Start with a premium digital atelier experience, not a conventional
  ecommerce template.

- Let user feedback become structured design data.

- Keep the database independent from the frontend so the system can
  later power web, mobile, internal designer tools and customer-facing
  AI.

## Definition of success

A successful LLinen Earth designer should eventually be able to take a
fabric image and a short brief such as “lightweight beige linen, luxury
hotel dinner, warm evening, understated but distinctive,” translate that
brief into a structured garment specification, justify the construction
choices, recommend a coordinated outfit, and generate a consistent
model/mannequin visualization that a human designer can refine into a
real tailoring specification.

# Appendix A — Recommended file/folder structure

- /fashion-system/taxonomy/pants.json

- /fashion-system/taxonomy/shirts.json

- /fashion-system/taxonomy/jackets.json

- /fashion-system/taxonomy/suits.json

- /fashion-system/components/collars.json

- /fashion-system/components/cuffs.json

- /fashion-system/components/lapels.json

- /fashion-system/components/pockets.json

- /fashion-system/components/plackets.json

- /fashion-system/components/waistbands.json

- /fashion-system/materials/fabrics.json

- /fashion-system/context/occasions.json

- /fashion-system/context/destinations.json

- /fashion-system/rules/compatibility.json

- /fashion-system/prompts/image-generation-v1.json

- /fashion-system/references/reference-manifest.csv

- /fashion-system/designs/approved/

# Appendix B — Minimum record template

| **Field**               | **Required?** | **Example**                         |
|-------------------------|---------------|-------------------------------------|
| ID                      | Yes           | SH-CAMP-001                         |
| Name                    | Yes           | Camp Collar Resort Shirt            |
| Family                  | Yes           | Shirt                               |
| Archetype               | Yes           | Camp collar                         |
| Construction attributes | Yes           | collar/cuff/placket/pocket/yoke/hem |
| Fit                     | Yes           | Relaxed                             |
| Material                | Yes           | Linen                               |
| Color                   | Yes           | Warm ivory                          |
| Context tags            | Yes           | Resort/evening/hot                  |
| Aesthetic tags          | Recommended   | Quiet luxury/Italian/resort         |
| Reference views         | Yes           | front/45/side/back                  |
| Rights metadata         | Yes           | Owned/licensed/reference            |
| Confidence              | Yes           | High/medium/low                     |
| AI recipe               | Later         | Prompt template + constraints       |
| Approval status         | Yes           | Draft/reviewed/approved/retired     |
