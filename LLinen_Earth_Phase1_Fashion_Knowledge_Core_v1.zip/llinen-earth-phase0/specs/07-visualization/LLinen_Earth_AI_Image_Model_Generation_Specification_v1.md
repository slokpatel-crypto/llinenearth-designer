**LLINEN EARTH**

**AI Image & Model Generation Specification**

*Designer Brain Specification — Part 7, v1.0*

A production specification for converting a locked garment design into
consistent, fabric-faithful, multi-view fashion visualization.

# 1. Objective

Part 7 is not a generic text-to-image prompt guide. It defines a
controlled visualization system whose job is to render the design
decided by Part 6 without silently redesigning it. The design object
remains the source of truth; the image model is a renderer.

- Preserve garment construction and proportions.

- Preserve uploaded fabric color, texture and pattern identity.

- Maintain the same model/mannequin across views.

- Maintain the same garment across front, side, back and detail views.

- Separate catalogue accuracy from editorial creativity.

- Detect and reject visual outputs that violate the locked design.

# 2. Fundamental Architecture

| **Layer**                | **Responsibility**                                                      |
|--------------------------|-------------------------------------------------------------------------|
| Design Engine            | Decides garment, fabric, silhouette, construction, styling              |
| Visualization Compiler   | Converts structured design into model-ready controls/prompts/references |
| Identity Controller      | Locks mannequin/model appearance and body proportions                   |
| Garment Controller       | Locks construction, fit and garment geometry                            |
| Fabric Controller        | Preserves texture, pattern, scale and color                             |
| View Controller          | Controls camera, pose, crop and view angle                              |
| Generation/Editing Model | Produces the image                                                      |
| Consistency Validator    | Compares output against locked design                                   |
| Repair Pass              | Edits only failed attributes rather than regenerating everything        |

# 3. Design Specification as Source of Truth

- Never ask the image model to invent garment details already defined in
  Part 6.

- Every render references a design_version_id.

- Any user-approved design edit creates a new version.

- Front/back/side/detail images must all resolve to the same garment
  attribute object.

- Prompt text is a compiled representation of structured data, not the
  permanent design record.

# 4. Visualization Modes

| **Mode**                | **Purpose**                                        | **Priority**                                    |
|-------------------------|----------------------------------------------------|-------------------------------------------------|
| Catalogue               | Garment understanding and comparison               | Accuracy \> drama                               |
| Customer try-on concept | Show intended look on a person/model               | Identity + fit + fabric                         |
| Designer presentation   | Premium full-look visualization                    | Accuracy + atmosphere                           |
| Construction detail     | Collar, cuff, lapel, pocket, pleat, waistband, hem | Detail fidelity                                 |
| Fabric simulation       | Show fabric mapped onto garment                    | Material fidelity                               |
| Editorial               | Marketing/inspiration after design lock            | Creative photography, but garment remains fixed |

# 5. Consistent Model / Mannequin System

A persistent model profile is required. Generating a new anonymous
person for every view will create inconsistent shoulders, torso, face,
height and garment fit.

| **Profile field**   | **Examples**                                       |
|---------------------|----------------------------------------------------|
| model_id            | MODEL-M01                                          |
| presentation        | Male mannequin / photoreal model                   |
| height class        | Short / average / tall or numeric where available  |
| body proportions    | Shoulder, chest, waist, hip, inseam relationships  |
| posture             | Neutral catalogue posture                          |
| skin/hair/face      | Fixed only when using a human model                |
| pose set            | Approved front, 45°, side, back, detail poses      |
| camera relationship | Fixed focal-length equivalent, distance and height |

For the garment reference catalogue, a neutral consistent
mannequin/model is preferable to changing fashion models because
differences between garments become easier to see.

# 6. Standard View Set

| **View**  | **Requirement**                                                       |
|-----------|-----------------------------------------------------------------------|
| Front     | Neutral stance; garment fully visible; minimal perspective distortion |
| Front 45° | Shows drape, lapel/collar depth and side silhouette                   |
| Side      | Shows jacket length, trouser line, pocket/vent relationships          |
| Back      | Shows yoke, vents, back balance, trouser seat and hem                 |
| Detail 1  | Primary construction detail                                           |
| Detail 2  | Fabric/pattern/texture or secondary construction detail               |

- Use consistent crop, camera height and lens behavior across a garment
  family.

- Do not use dramatic poses for catalogue comparison.

- Editorial poses belong to a separate generation mode.

# 7. Garment Geometry Lock

| **Garment** | **Must remain invariant across views**                                |
|-------------|-----------------------------------------------------------------------|
| Trouser     | Rise, pleats, waistband, pocket type, width, taper, hem, break        |
| Shirt       | Collar, placket, cuff, yoke, back treatment, fit, hem                 |
| Jacket      | Lapel, shoulder, button count/stance, pocket style, vents, length     |
| Suit        | Jacket/trouser fabric identity, coordinated construction, proportions |

If the back view invents a center vent when the front design specifies
side vents, the render fails validation even if the image looks
attractive.

# 8. Fabric Preservation Pipeline

1.  Ingest original fabric image at the highest practical quality.

2.  Normalize crop/orientation without destructively altering the
    source.

3.  Estimate dominant colors, pattern repeat, texture and surface cues
    with confidence.

4.  Create a fabric asset ID and retain the untouched source.

5.  Generate/use a tile or material representation only when technically
    appropriate.

6.  Map fabric onto garment panels with physically plausible orientation
    and scale.

7.  Validate rendered color, motif scale and recognizable texture
    against the source.

# 9. Pattern Scale & Orientation

- A check, stripe or motif needs a real scale estimate; arbitrary
  scaling changes the garment design.

- Vertical/horizontal orientation must follow fabric cutting logic.

- Pattern matching at pockets/plackets/seams may be specified as premium
  tailoring behavior.

- Different panels may change direction only when intentionally
  designed.

- Close-up images should confirm motif scale rather than contradict the
  full-body view.

# 10. Color Fidelity

- Use the source fabric asset, not only a text color name.

- Separate lighting effects from material color.

- Catalogue lighting should be neutral and repeatable.

- When exact color cannot be trusted from an uncontrolled upload, label
  visualization as approximate.

- Do not increase saturation/contrast merely to make the generated image
  more visually impressive.

# 11. Material Behavior

| **Property**         | **Visual implication**                                  |
|----------------------|---------------------------------------------------------|
| Drape                | How fabric hangs, folds and moves                       |
| Weight               | Fold size, silhouette stability and perceived thickness |
| Structure            | Whether lapels/collars/creases hold shape               |
| Surface              | Matte, brushed, slub, smooth, lustrous                  |
| Stretch              | Tension and fit behavior                                |
| Opacity              | Need for underlayer/lining                              |
| Wrinkle behavior     | Natural creasing appropriate to material                |
| Pattern construction | Printed vs woven appearance where known                 |

# 12. Fit Representation

The visualization should show design intent, not claim made-to-measure
accuracy unless reliable body measurements and a suitable fitting system
exist.

- Use fit classes such as slim, tailored, straight, relaxed and
  oversized as structured controls.

- Preserve ease consistently across views.

- Avoid impossible tension lines or painted-on clothing.

- Trouser rise and crotch geometry must be plausible.

- Jacket buttoning should not distort the body unrealistically.

# 13. Reference Garment Visualization

For the future garment knowledge catalogue, each reference type should
be visualized with a standardized base model and neutral fabric so the
construction difference is obvious.

- Change only the attribute being demonstrated where possible.

- Example: compare single pleat vs double pleat while holding model,
  fabric, color, camera and other trouser attributes constant.

- Use front/side/back/detail views for attributes that cannot be
  understood from the front.

- Keep labels and garment IDs linked to each rendered set.

# 14. Image Generation Strategy

Use a hybrid controlled-generation pipeline rather than relying on a
single unconstrained text-to-image call.

| **Technique**                    | **Best use**                                            |
|----------------------------------|---------------------------------------------------------|
| Reference-conditioned generation | Model identity, fabric and design reference             |
| Image editing / inpainting       | Repair a specific collar, pocket, button or fabric area |
| Pose/structure conditioning      | Maintain body and view geometry                         |
| Segmentation/masks               | Isolate garment panels and protect unaffected regions   |
| Retrieval                        | Provide approved construction/fabric visual references  |
| Multi-view generation            | Create related views from shared design/identity state  |
| Post-generation validation       | Detect deviations before user sees final set            |

# 15. Prompt Compiler

The system compiles the structured design object into a concise render
instruction. Prompting should be deterministic enough to reproduce a
garment version.

- Identity block: model/mannequin ID and body profile.

- Garment block: exact construction attributes.

- Fabric block: asset reference, material behavior, color/pattern
  constraints.

- Fit block: silhouette and proportion.

- Styling block: tuck, buttons, shoes, accessories.

- View block: camera, pose, crop.

- Environment block: catalogue or approved scene.

- Negative block: attributes that must not change or appear.

# 16. Negative Constraint Examples

- Do not add extra pockets, buttons, pleats, vents or decorative seams.

- Do not change lapel/collar type.

- Do not alter fabric color family or motif scale.

- Do not slim or widen trousers beyond specified silhouette.

- Do not add logos or branding unless explicitly included.

- Do not change footwear/accessories between related views.

- Do not change model identity, hair or body proportions in a multi-view
  set.

# 17. Multi-View Generation Workflow

8.  Generate or select the locked base identity image/state.

9.  Generate the primary front view.

10. Validate garment, fabric and identity.

11. Use the approved primary output plus structured spec as conditioning
    for additional views.

12. Generate side/back/45° with fixed view controls.

13. Run cross-view consistency checks.

14. Repair local errors through editing rather than full random
    regeneration.

15. Generate detail crops from the approved garment state where
    possible.

16. Publish the set only when required consistency thresholds pass.

# 18. Consistency Validator

| **Validation**        | **Checks**                                             |
|-----------------------|--------------------------------------------------------|
| Identity              | Same model/body/face where applicable                  |
| Silhouette            | Widths, lengths, rise and jacket proportions           |
| Construction          | Collar, lapel, pockets, vents, pleats, cuffs, closures |
| Fabric                | Color, motif, scale, texture                           |
| Styling               | Button state, tuck, shoes, accessories                 |
| View correctness      | Requested angle and crop                               |
| Physical plausibility | Folds, seams, layering and body interaction            |

# 19. Automated Comparison Signals

- Garment segmentation overlap and shape descriptors.

- Keypoint/body-proportion consistency.

- Perceptual similarity for fabric patches.

- Color-distance checks in controlled catalogue regions.

- Pattern-frequency/scale comparison.

- Attribute classifiers for collars, lapels, pleats, pockets and vents.

- Image-embedding similarity as a supporting signal, never the sole
  validator.

# 20. Repair-First Policy

When one element fails, preserve the rest of the approved image.

| **Failure**         | **Repair**                                |
|---------------------|-------------------------------------------|
| Wrong pocket        | Mask/edit pocket region                   |
| Wrong collar        | Local collar edit with garment reference  |
| Fabric drift        | Remap/repair garment region               |
| Face/identity drift | Identity-preserving edit                  |
| Wrong trouser width | Controlled garment-shape edit; revalidate |
| Wrong back vent     | Back-panel edit only                      |
| Accessory changed   | Replace/protect accessory region          |

# 21. Generation Quality Tiers

| **Tier**           | **Use**                                              |
|--------------------|------------------------------------------------------|
| Preview            | Fast concept validation; lower cost                  |
| Standard           | User comparison and refinement                       |
| Premium final      | Higher resolution, consistency checks, repair passes |
| Campaign/editorial | Final locked garment plus creative scene/lighting    |

The product should not spend premium-generation cost before the user has
selected a design direction.

# 22. Catalogue Lighting & Background Standard

- Neutral premium studio background with low visual distraction.

- Soft, even lighting that reveals texture without creating false color.

- Consistent shadow direction and exposure.

- No environmental props that obscure hems, pockets or silhouette.

- A separate branded editorial template can be used after catalogue
  views are approved.

# 23. Customer Fabric Upload Guidance

- Ask for a flat, well-lit fabric image with minimal shadow.

- For patterned fabric, include enough area to see the repeat.

- Optionally request a second draped/folded image to understand texture
  and behavior.

- Avoid requiring technical photography for initial exploration.

- For high-fidelity final visualization, offer a guided capture flow
  with neutral lighting/reference scale.

# 24. Customer Model / Try-On Considerations

If a customer later wants visualization on themselves, treat it as a
separate identity-controlled workflow. A photo-based visualization is a
styling preview, not a guarantee of physical tailoring fit.

- Use user-provided images only with explicit user action.

- Keep identity images separate from public catalogue assets.

- Do not infer exact body measurements from a casual photograph as if
  verified.

- Allow deletion/retention controls appropriate to the product's privacy
  design.

- Use a neutral mannequin option for customers who do not want to
  provide personal images.

# 25. Reference Image Rights & Provenance

- Track whether each visual asset is owned, licensed, public-domain,
  user-provided or external-reference-only.

- Do not assume arbitrary web images can be used for model training or
  commercial derivative output.

- For product-critical datasets, prioritize owned/licensed photography
  and designer-approved renders.

- Store provenance at asset level and enforce permitted uses
  programmatically.

# 26. Garment Detail Library

High-quality detail references should exist for construction elements
the image model commonly confuses.

| **Category** | **Examples**                                                                 |
|--------------|------------------------------------------------------------------------------|
| Trouser      | Single/double pleat, side adjuster, Gurkha waist, cuffs, pocket types        |
| Shirt        | Spread/cutaway/button-down collars, French/barrel cuffs, plackets, yokes     |
| Jacket       | Notch/peak/shawl lapels, patch/flap/jetted pockets, single/double vents      |
| Suit         | Single/double-breasted fronts, waistcoat relationships, trouser coordination |

# 27. Fabric Material Library

- Create controlled visual references for linen, cotton, wool, flannel,
  corduroy, denim, velvet, seersucker and other priority materials.

- Represent multiple weights, weaves and finishes within a fiber family.

- Use macro and draped views where useful.

- Do not teach 'linen' as one universal texture; construction and finish
  vary substantially.

# 28. Model Set for Product Launch

For an MVP, avoid a huge model library. Start with a small,
intentionally standardized set.

- 1 neutral male mannequin for garment taxonomy/reference pages.

- 1-3 premium photoreal male model profiles for styled recommendations.

- Fixed catalogue pose pack for each model.

- Separate editorial pose packs from catalogue poses.

- Expand representation only when the consistency pipeline is proven.

# 29. Visualization Data Object

{  
"visualization_id": "VIS-...",  
"design_version_id": "DES-V3",  
"model_id": "MODEL-M01",  
"mode": "catalogue",  
"garments": \[  
{  
"garment_id": "JACKET-...",  
"fabric_id": "FAB-...",  
"locked_attributes": {}  
}  
\],  
"fabric_controls": {  
"preserve_color": true,  
"preserve_pattern_scale": true,  
"preserve_texture": true  
},  
"fit_profile": {},  
"styling": {},  
"view": {  
"type": "front",  
"pose_id": "POSE-CAT-FRONT-01",  
"camera_profile": "CAM-CAT-01"  
},  
"negative_constraints": \[\],  
"validation_thresholds": {},  
"parent_render_id": null  
}

# 30. Render Set Object

{  
"render_set_id": "SET-...",  
"design_version_id": "DES-V3",  
"model_id": "MODEL-M01",  
"views": {  
"front": "VIS-...",  
"front_45": "VIS-...",  
"side": "VIS-...",  
"back": "VIS-...",  
"detail_1": "VIS-..."  
},  
"consistency_score": 0.94,  
"validation": {  
"identity": "pass",  
"garment": "pass",  
"fabric": "pass",  
"styling": "pass"  
},  
"status": "approved"  
}

# 31. Human QA Interface

- Overlay/compare views side-by-side.

- Pin a correct view as the reference.

- Flag specific errors: collar, lapel, pocket, vent, fabric, fit,
  identity.

- Trigger local repair rather than total regeneration.

- Approve a render set only when required views pass.

- Feed approved outputs into a curated reference library where rights
  allow.

# 32. Evaluation Dataset

- Create fixed benchmark designs covering common and difficult garment
  attributes.

- Include solids, stripes, checks and textured fabrics.

- Test both subtle and obvious construction differences.

- Include warm-weather and structured tailoring.

- Score individual attributes, not just overall image attractiveness.

- Repeat benchmarks whenever the generation model or prompt compiler
  changes.

# 33. Metrics

| **Metric**                 | **Meaning**                                                  |
|----------------------------|--------------------------------------------------------------|
| Garment attribute accuracy | Percent of locked construction attributes rendered correctly |
| Cross-view consistency     | Same design across all views                                 |
| Fabric fidelity            | Color/pattern/texture preservation                           |
| Identity consistency       | Same model/mannequin across views                            |
| Repair success             | Error fixed without damaging approved regions                |
| First-pass acceptance      | Percent of renders requiring no repair                       |
| User selection rate        | Concept visualization useful enough to choose/refine         |
| Designer approval          | Expert evaluation of realism and coherence                   |

# 34. Cost & Latency Control

- Generate low-cost previews before premium finals.

- Cache approved model identities, garment references and fabric
  preprocessing.

- Avoid regenerating unchanged views after a small edit.

- Use local repair when possible.

- Generate detail views only for relevant construction attributes.

- Queue expensive multi-view finalization after design selection.

# 35. Model/Provider Abstraction

Do not hard-code the product around one image-generation vendor. Use an
internal visualization interface so models/providers can be changed as
quality improves.

- Provider adapter accepts the same locked visualization object.

- Capabilities are declared: reference images, masks, identity
  preservation, multi-view, resolution, latency, cost.

- Route tasks to the provider best suited to each operation.

- Store provider/model/version for reproducibility and QA.

# 36. MVP Implementation

17. Use one standard mannequin/model and one catalogue camera profile.

18. Support shirt, trouser and jacket/suit visualization first.

19. Support front + back + one detail view before expanding to all
    angles.

20. Start with solid and simple patterned fabrics; add difficult repeats
    after validation.

21. Use image editing for corrections instead of repeated full
    regeneration.

22. Keep a human approval step for premium final outputs.

23. Collect structured failure labels to improve the system.

# 37. Premium Evolution

| **MVP**                      | **Premium system**                                        |
|------------------------------|-----------------------------------------------------------|
| Single standardized model    | Persistent selectable model/mannequin library             |
| Front/back/detail            | Full multi-view + turntable-like consistency              |
| Basic fabric mapping         | High-fidelity material reconstruction                     |
| Manual QA                    | Automated attribute validation + targeted repair          |
| Static poses                 | Controlled pose library + selected lifestyle scenes       |
| Single garment visualization | Full layered outfit with accessory consistency            |
| Conceptual fit               | Measurement-aware visualization with explicit limitations |

# 38. Non-Negotiable Failure Cases

- Front and back show different garment construction.

- Uploaded stripe/check changes scale between views.

- Model identity changes across the same render set.

- Fabric color changes materially without lighting justification.

- A detail view invents buttons, seams or pockets.

- Garment fit changes because pose/camera changes.

- Editorial scene hides the garment features the customer needs to
  evaluate.

# 39. Part 7 Completion Criteria

- A locked design can be rendered without redesigning it.

- Same model/mannequin persists across the required views.

- Core garment attributes remain consistent.

- Uploaded fabric remains recognizable and plausibly mapped.

- Failed attributes can be repaired locally.

- Catalogue and editorial modes are separated.

- Provider/model changes do not require redesigning the Fashion Brain
  schemas.

# 40. Next Specification

Next: Part 8 — Website UX/UI & Premium Experience. This will translate
the Fashion Brain and Designer Brain into the actual LLinen Earth
customer journey: black-to-navy branded entry, fabric upload,
progressive AI consultation, visual design directions, garment explorer,
compare/refine flow, final multi-view presentation, saved designs and
developer-ready page/component architecture.
