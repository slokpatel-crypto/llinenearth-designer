import { access } from "node:fs/promises";
import { resolve } from "node:path";

const required = [
  "apps/web/src/app/page.tsx",
  "apps/web/src/components/BrandIntro.tsx",
  "apps/web/src/app/api/health/route.ts",
  "apps/web/src/app/api/assets/upload-url/route.ts",
  "packages/db/prisma/schema.prisma",
  "packages/db/prisma/migrations/20260912164500_phase0_foundation/migration.sql",
  "packages/storage/src/index.ts",
  "packages/jobs/src/index.ts",
  "docs/ARCHITECTURE_DECISIONS.md",
  "docs/IMPLEMENTATION_STATUS.md",
  ".github/workflows/ci.yml",
  ".env.example"
];

for (const file of required) {
  await access(resolve(process.cwd(), file));
}
console.log(`Phase 0 structure check: PASS (${required.length} required artifacts)`);
