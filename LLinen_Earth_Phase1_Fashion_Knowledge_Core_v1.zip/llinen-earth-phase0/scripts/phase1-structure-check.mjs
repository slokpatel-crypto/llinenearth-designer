import { access, readFile } from "node:fs/promises";
const required = [
  "packages/domain/src/fashion.ts",
  "packages/fashion-knowledge/src/index.ts",
  "packages/fashion-knowledge/src/index.test.ts",
  "apps/web/src/app/knowledge/page.tsx",
  "apps/web/src/app/api/v1/knowledge/garments/route.ts",
  "apps/web/src/app/api/v1/knowledge/fabrics/route.ts",
  "apps/web/src/app/api/v1/knowledge/contexts/route.ts",
  "apps/web/src/app/api/v1/knowledge/aesthetics/route.ts",
  "apps/web/src/app/api/v1/knowledge/pairings/route.ts",
  "apps/web/public/brand/llinen-earth-logo-official.png",
  "packages/db/prisma/migrations/20260912175500_phase1_fashion_knowledge/migration.sql",
];
for (const path of required) await access(path);
const knowledge = await readFile("packages/fashion-knowledge/src/index.ts", "utf8");
for (const marker of ["TR-PLEATED-TAILORED-001", "FB-LINEN-PLAIN-LIGHT-001", "CTX-BEACH-WEDDING-DAY-001", "AE-QUIET-LUXURY", "REL-HOT-FLANNEL-CONFLICT"]) {
  if (!knowledge.includes(marker)) throw new Error(`Missing knowledge marker: ${marker}`);
}
console.log(`Phase 1 structure check PASS (${required.length} required files)`);
