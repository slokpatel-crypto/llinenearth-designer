import { readdir, readFile } from "node:fs/promises";
import { join, relative } from "node:path";

const root = process.cwd();
const ignored = new Set(["node_modules", ".git", ".next", "specs"]);
const forbidden = [
  /AKIA[0-9A-Z]{16}/,
  /sk-[A-Za-z0-9_-]{20,}/,
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/
];

async function walk(dir) {
  const entries = await readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    if (ignored.has(entry.name)) continue;
    const path = join(dir, entry.name);
    if (entry.isDirectory()) await walk(path);
    else if (!/\.(png|jpg|jpeg|gif|webp|docx|pdf|zip)$/i.test(entry.name)) {
      const text = await readFile(path, "utf8");
      for (const pattern of forbidden) {
        if (pattern.test(text)) throw new Error(`Potential committed secret in ${relative(root, path)}`);
      }
    }
  }
}

await walk(root);
console.log("Secret pattern scan: PASS");
